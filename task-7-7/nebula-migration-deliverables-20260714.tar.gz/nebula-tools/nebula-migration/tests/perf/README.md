# Local 50M Benchmark

`run-local-50m-benchmark.sh` starts the existing isolated source and target topology through the
functional E2E setup, so each cluster has three meta, three storage and three graphd processes.
It then creates three INT64 spaces with 99 partitions and loads 49,999,998 total vertex/edge
records through nebula-java before running a CSV/partition migration.

```bash
./tests/perf/run-local-50m-benchmark.sh
```

For harness validation without the full load, set `PERF_RECORDS_PER_SPACE=1000`. The default uses
replica factor 1 to keep source, target and export artifacts on one test host; it verifies
partition distribution across all three storage instances, not a replica-factor-3 capacity test.
The benchmark sets `PERF_EXPORT_SCAN_LIMIT=10000` by default to avoid excessive per-page executor
creation inside nebula-java 3.8's scan iterator; production defaults remain `export.scan.limit=1000`
and can be tuned at task startup. Evidence and timing are retained under
`/tmp/nebula-migration-e2e-perf50m/evidence`.

The performance import uses `PERF_IMPORT_ARTIFACT_CONCURRENCY=8` and
`PERF_CHECKPOINT_FLUSH_BATCH_INTERVAL=20`. Both can be overridden before starting the task.

Use `PERF_RECORDS_PER_SPACE=1000 PERF_EXPORT_SCAN_LIMIT=2` for the strong-pagination regression.
It exercises repeated edge pages with eight partition workers and verifies the dedicated edge scan
client leases do not stall under concurrent paging.
