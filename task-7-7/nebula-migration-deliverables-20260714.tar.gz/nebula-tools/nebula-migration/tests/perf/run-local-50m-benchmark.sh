#!/usr/bin/env bash
# Builds a reproducible ~50M point/edge migration benchmark on the same isolated 3-storage
# source/target topology used by the functional E2E test. Override PERF_RECORDS_PER_SPACE for a
# small smoke run; the default creates 49,999,998 total vertices and edges.
set -euo pipefail

TOOL_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
INSTALL_ROOT=${NEBULA_INSTALL_ROOT:-/usr/local/nebula}
E2E_ROOT=${MIGRATION_E2E_ROOT:-/tmp/nebula-migration-e2e-perf50m}
RECORDS_PER_SPACE=${PERF_RECORDS_PER_SPACE:-8333333}
BATCH_SIZE=${PERF_FIXTURE_BATCH_SIZE:-500}
WORKERS_PER_SPACE=${PERF_FIXTURE_WORKERS_PER_SPACE:-2}
EXPORT_SCAN_LIMIT=${PERF_EXPORT_SCAN_LIMIT:-10000}
IMPORT_ARTIFACT_CONCURRENCY=${PERF_IMPORT_ARTIFACT_CONCURRENCY:-8}
CHECKPOINT_FLUSH_BATCH_INTERVAL=${PERF_CHECKPOINT_FLUSH_BATCH_INTERVAL:-20}
TOTAL_RECORDS=$((RECORDS_PER_SPACE * 6))
CONSOLE_BIN="$INSTALL_ROOT/nebula-console"
JAR="$TOOL_ROOT/target/nebula-migration-0.1.0.jar"
SOURCE_GRAPH=127.10.3.1:45900
TARGET_GRAPH=127.20.3.1:55900

case "$E2E_ROOT" in
  /tmp/nebula-migration-e2e*) ;;
  *) echo "MIGRATION_E2E_ROOT must remain under /tmp/nebula-migration-e2e" >&2; exit 64 ;;
esac

ngql() {
  local endpoint=$1
  local statement=$2
  timeout 60 "$CONSOLE_BIN" -addr "${endpoint%:*}" -port "${endpoint##*:}" \
    -u root -p nebula -e "$statement"
}

log() {
  printf '%s %s\n' "$(date -Iseconds)" "$*" | tee -a "$E2E_ROOT/evidence/perf.log"
}

stop_cluster() {
  local pid_file=$1
  [[ -f "$pid_file" ]] || return 0
  while IFS= read -r pid; do
    [[ -n "$pid" ]] || continue
    local args
    args=$(ps -p "$pid" -o args= 2>/dev/null || true)
    if [[ "$args" == *"$E2E_ROOT"* ]]; then
      kill -TERM "$pid" 2>/dev/null || true
    fi
  done < "$pid_file"

  local deadline=$((SECONDS + 30))
  while [[ $SECONDS -lt $deadline ]]; do
    local live=false
    while IFS= read -r pid; do
      [[ -n "$pid" ]] || continue
      local args
      args=$(ps -p "$pid" -o args= 2>/dev/null || true)
      if [[ "$args" == *"$E2E_ROOT"* ]] && kill -0 "$pid" 2>/dev/null; then
        live=true
      fi
    done < "$pid_file"
    [[ "$live" == false ]] && return 0
    sleep 1
  done

  while IFS= read -r pid; do
    [[ -n "$pid" ]] || continue
    local args
    args=$(ps -p "$pid" -o args= 2>/dev/null || true)
    if [[ "$args" == *"$E2E_ROOT"* ]] && kill -0 "$pid" 2>/dev/null; then
      kill -KILL "$pid" 2>/dev/null || true
    fi
  done < "$pid_file"

  deadline=$((SECONDS + 10))
  while [[ $SECONDS -lt $deadline ]]; do
    local live=false
    while IFS= read -r pid; do
      [[ -n "$pid" ]] || continue
      local args
      args=$(ps -p "$pid" -o args= 2>/dev/null || true)
      if [[ "$args" == *"$E2E_ROOT"* ]] && kill -0 "$pid" 2>/dev/null; then
        live=true
      fi
    done < "$pid_file"
    [[ "$live" == false ]] && return 0
    sleep 1
  done

  echo "Benchmark-owned processes did not exit for $pid_file" >&2
  return 1
}

cleanup() {
  log "Stopping benchmark-owned clusters"
  stop_cluster "$E2E_ROOT/target.pids"
  stop_cluster "$E2E_ROOT/source.pids"
}
trap cleanup EXIT

wait_freeze_state() {
  local expected=$1
  for host in 127.10.3.1 127.10.3.2 127.10.3.3; do
    local status=""
    for _ in $(seq 1 90); do
      status=$(curl --noproxy '*' --fail --silent --show-error --max-time 2 \
        "http://$host:46900/migration_freeze_status" 2>&1 || true)
      if [[ "$status" == *"\"state\":\"$expected\""* ]]; then
        break
      fi
      sleep 1
    done
    [[ "$status" == *"\"state\":\"$expected\""* ]] || {
      log "Expected source graphd state $expected, got $status"
      exit 1
    }
  done
}

wait_spaces_absent() {
  local endpoint=$1
  for _ in $(seq 1 90); do
    local output
    output=$(ngql "$endpoint" "SHOW SPACES" 2>&1 || true)
    if [[ "$output" != *"migration_string"* ]] && [[ "$output" != *"migration_int"* ]]; then
      return 0
    fi
    sleep 1
  done
  log "Timed out waiting for E2E spaces to drop on $endpoint"
  exit 1
}

wait_user_absent() {
  local endpoint=$1
  for _ in $(seq 1 90); do
    local output
    output=$(ngql "$endpoint" "SHOW USERS" 2>&1 || true)
    if [[ "$output" != *"migration_user"* ]]; then
      return 0
    fi
    sleep 1
  done
  log "Timed out waiting for migration_user to drop on $endpoint"
  exit 1
}

run_tool() {
  local command=$1
  local properties=$2
  log "Running migration command: $command"
  java -jar "$JAR" "$command" -c "$properties" >>"$E2E_ROOT/evidence/perf.log" 2>&1
}

measure() {
  local name=$1
  shift
  local started
  started=$(date +%s)
  "$@"
  local ended
  ended=$(date +%s)
  printf '%s=%s\n' "$name" "$((ended - started))" >> "$E2E_ROOT/evidence/perf-metrics.properties"
}

ulimit -n 65536
mkdir -p "$E2E_ROOT/evidence"
log "Bootstrapping isolated source and target clusters through functional E2E"
MIGRATION_E2E_ROOT="$E2E_ROOT" "$TOOL_ROOT/tests/e2e/run-local-migration-e2e.sh" --keep

log "Resetting E2E fixture objects for benchmark load"
ngql "$SOURCE_GRAPH" "UPDATE CONFIGS graph:enable_graph_mutation=true" >>"$E2E_ROOT/evidence/perf.log" 2>&1
wait_freeze_state WRITABLE
for endpoint in "$SOURCE_GRAPH" "$TARGET_GRAPH"; do
  ngql "$endpoint" "DROP SPACE \`migration_string\`" >>"$E2E_ROOT/evidence/perf.log" 2>&1 || true
  ngql "$endpoint" "DROP SPACE \`migration_int\`" >>"$E2E_ROOT/evidence/perf.log" 2>&1 || true
done
ngql "$SOURCE_GRAPH" "DROP USER \`migration_user\`" >>"$E2E_ROOT/evidence/perf.log" 2>&1 || true
ngql "$TARGET_GRAPH" "DROP USER \`migration_user\`" >>"$E2E_ROOT/evidence/perf.log" 2>&1 || true
wait_spaces_absent "$SOURCE_GRAPH"
wait_spaces_absent "$TARGET_GRAPH"
wait_user_absent "$SOURCE_GRAPH"
wait_user_absent "$TARGET_GRAPH"

for space in perf_0 perf_1 perf_2; do
  ngql "$SOURCE_GRAPH" "CREATE SPACE \`$space\`(partition_num=99, replica_factor=1, vid_type=INT64)" \
    >>"$E2E_ROOT/evidence/perf.log" 2>&1
done
sleep 10
for space in perf_0 perf_1 perf_2; do
  ngql "$SOURCE_GRAPH" "USE \`$space\`; CREATE TAG \`load_tag\`(name string, value int, active bool, score double, created datetime)" \
    >>"$E2E_ROOT/evidence/perf.log" 2>&1
  ngql "$SOURCE_GRAPH" "USE \`$space\`; CREATE EDGE \`load_edge\`(weight double, code string)" \
    >>"$E2E_ROOT/evidence/perf.log" 2>&1
done
sleep 15

log "Loading $TOTAL_RECORDS total points and edges ($RECORDS_PER_SPACE per kind per space)"
measure fixture_load bash -c "cd '$TOOL_ROOT' && mvn -q test-compile package && java -cp 'target/test-classes:target/nebula-migration-0.1.0.jar' com.vesoft.nebula.migration.PerformanceFixtureLoader '127.10.3.1:45900,127.10.3.2:45910,127.10.3.3:45920' root nebula '$RECORDS_PER_SPACE' '$BATCH_SIZE' '$WORKERS_PER_SPACE' >> '$E2E_ROOT/evidence/perf-loader.log' 2>&1"
sleep 15

ngql "$SOURCE_GRAPH" "UPDATE CONFIGS graph:enable_graph_mutation=false" >>"$E2E_ROOT/evidence/perf.log" 2>&1
wait_freeze_state FROZEN

PROPERTIES="$E2E_ROOT/perf.properties"
cat > "$PROPERTIES" <<EOF
source.graph.addresses=127.10.3.1:45900,127.10.3.2:45910,127.10.3.3:45920
source.meta.addresses=127.10.1.1:45500,127.10.1.2:45510,127.10.1.3:45520
source.user=root
source.password=nebula
source.freeze.urls=http://127.10.3.1:46900/migration_freeze_status,http://127.10.3.2:46900/migration_freeze_status,http://127.10.3.3:46900/migration_freeze_status
target.graph.addresses=127.20.3.1:55900,127.20.3.2:55910,127.20.3.3:55920
target.meta.addresses=127.20.1.1:55500,127.20.1.2:55510,127.20.1.3:55520
target.user=root
target.password=nebula
workspace=$E2E_ROOT/work-perf
export.format=csv
export.file.layout=partition
export.scan.limit=$EXPORT_SCAN_LIMIT
export.partition.concurrency=8
export.label.concurrency=1
import.batch.size=500
import.artifact.concurrency=$IMPORT_ARTIFACT_CONCURRENCY
import.retry.times=3
import.retry.backoff.ms=1000
checkpoint.flush.batch.interval=$CHECKPOINT_FLUSH_BATCH_INTERVAL
metadata.schema.visibility.timeout.ms=60000
verify.sample.modulo=100000
verify.sample.max.records=10000
verify.full.checksum=false
EOF

measure precheck run_tool precheck "$PROPERTIES"
measure export run_tool export "$PROPERTIES"
measure import run_tool import "$PROPERTIES"
measure verify run_tool verify "$PROPERTIES"

cat "$E2E_ROOT/evidence/perf-metrics.properties" > "$E2E_ROOT/evidence/performance-summary.properties"
printf 'total.records=%s\nrecords.per.space=%s\nexport.scan.limit=%s\nimport.artifact.concurrency=%s\ncheckpoint.flush.batch.interval=%s\nlayout=partition\nformat=csv\n' \
  "$TOTAL_RECORDS" "$RECORDS_PER_SPACE" "$EXPORT_SCAN_LIMIT" "$IMPORT_ARTIFACT_CONCURRENCY" \
  "$CHECKPOINT_FLUSH_BATCH_INTERVAL" \
  >> "$E2E_ROOT/evidence/performance-summary.properties"
log "PERF PASS: $TOTAL_RECORDS total point/edge records migrated; evidence=$E2E_ROOT/evidence"
