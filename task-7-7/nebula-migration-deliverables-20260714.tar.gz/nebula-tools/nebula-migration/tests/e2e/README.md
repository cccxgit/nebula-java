# Local Integration Test

Run `./tests/e2e/run-local-migration-e2e.sh` after building the custom graphd in
`/home/sch/nebula/nebula-3.6-io/build`. The script uses isolated ports and data below
`/tmp/nebula-migration-e2e`, starts a source and target cluster with three meta, storage, and
graphd processes each, then retains command output and migration reports in that directory.

Use `--keep` only for diagnosis; it leaves the test-owned processes running and records their PIDs.
