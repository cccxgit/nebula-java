#!/usr/bin/env bash
# Runs two isolated Nebula Graph 3.6 clusters (3 meta, 3 storage and 3 graphd each)
# and exercises CSV/label plus JSON/partition migration paths. Runtime evidence is retained
# under /tmp/nebula-migration-e2e unless MIGRATION_E2E_ROOT overrides it.
set -euo pipefail

TOOL_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
SERVER_ROOT=${NEBULA_SERVER_ROOT:-/home/sch/nebula/nebula-3.6-io}
INSTALL_ROOT=${NEBULA_INSTALL_ROOT:-/usr/local/nebula}
E2E_ROOT=${MIGRATION_E2E_ROOT:-/tmp/nebula-migration-e2e}
KEEP_CLUSTER=false

for argument in "$@"; do
  case "$argument" in
    --keep) KEEP_CLUSTER=true ;;
    *) echo "Usage: $0 [--keep]" >&2; exit 64 ;;
  esac
done

case "$E2E_ROOT" in
  /tmp/nebula-migration-e2e*) ;;
  *) echo "MIGRATION_E2E_ROOT must remain under /tmp/nebula-migration-e2e" >&2; exit 64 ;;
esac

stop_stale_from_file() {
  local pid_file=$1
  [[ -f "$pid_file" ]] || return 0

  # A stale PID is safe to touch only when its command line still belongs to this E2E root.
  # Wait for socket-owning processes to leave before recreating the same port topology.
  while IFS= read -r stale_pid; do
    [[ -n "$stale_pid" ]] || continue
    stale_args=$(ps -p "$stale_pid" -o args= 2>/dev/null || true)
    if [[ "$stale_args" == *"$E2E_ROOT"* ]]; then
      kill -TERM "$stale_pid" 2>/dev/null || true
    fi
  done < "$pid_file"

  local deadline=$((SECONDS + 30))
  while [[ $SECONDS -lt $deadline ]]; do
    local live=false
    while IFS= read -r stale_pid; do
      [[ -n "$stale_pid" ]] || continue
      stale_args=$(ps -p "$stale_pid" -o args= 2>/dev/null || true)
      if [[ "$stale_args" == *"$E2E_ROOT"* ]] && kill -0 "$stale_pid" 2>/dev/null; then
        live=true
      fi
    done < "$pid_file"
    [[ "$live" == false ]] && return 0
    sleep 1
  done

  while IFS= read -r stale_pid; do
    [[ -n "$stale_pid" ]] || continue
    stale_args=$(ps -p "$stale_pid" -o args= 2>/dev/null || true)
    if [[ "$stale_args" == *"$E2E_ROOT"* ]] && kill -0 "$stale_pid" 2>/dev/null; then
      kill -KILL "$stale_pid" 2>/dev/null || true
    fi
  done < "$pid_file"

  deadline=$((SECONDS + 10))
  while [[ $SECONDS -lt $deadline ]]; do
    local live=false
    while IFS= read -r stale_pid; do
      [[ -n "$stale_pid" ]] || continue
      stale_args=$(ps -p "$stale_pid" -o args= 2>/dev/null || true)
      if [[ "$stale_args" == *"$E2E_ROOT"* ]] && kill -0 "$stale_pid" 2>/dev/null; then
        live=true
      fi
    done < "$pid_file"
    [[ "$live" == false ]] && return 0
    sleep 1
  done

  echo "Stale E2E processes did not exit for $pid_file" >&2
  return 1
}

for stale_pid_file in "$E2E_ROOT/source.pids" "$E2E_ROOT/target.pids"; do
  stop_stale_from_file "$stale_pid_file"
done
rm -rf "$E2E_ROOT"

SERVER_BIN_ROOT=${NEBULA_SERVER_BIN_ROOT:-$SERVER_ROOT/build/bin}
META_BIN="$SERVER_BIN_ROOT/nebula-metad"
STORAGE_BIN="$SERVER_BIN_ROOT/nebula-storaged"
GRAPH_BIN="$SERVER_BIN_ROOT/nebula-graphd"
CONSOLE_BIN="$INSTALL_ROOT/nebula-console"
JAR="$TOOL_ROOT/target/nebula-migration-0.1.0.jar"
SOURCE_GRAPH_ENDPOINT=127.10.3.1:45900
TARGET_GRAPH_ENDPOINT=127.20.3.1:55900

require_file() {
  if [[ ! -x "$1" ]]; then
    echo "Required executable is missing: $1" >&2
    exit 70
  fi
}

for executable in "$META_BIN" "$STORAGE_BIN" "$GRAPH_BIN" "$CONSOLE_BIN"; do
  require_file "$executable"
done

mkdir -p "$E2E_ROOT/evidence" "$E2E_ROOT/logs"
SOURCE_PIDS="$E2E_ROOT/source.pids"
TARGET_PIDS="$E2E_ROOT/target.pids"
: > "$SOURCE_PIDS"
: > "$TARGET_PIDS"

log() {
  printf '%s %s\n' "$(date -Iseconds)" "$*" | tee -a "$E2E_ROOT/evidence/e2e.log"
}

fail() {
  log "FAIL: $*"
  exit 1
}

stop_from_file() {
  local pid_file=$1
  [[ -f "$pid_file" ]] || return 0
  while IFS= read -r pid; do
    [[ -n "$pid" ]] || continue
    if kill -0 "$pid" 2>/dev/null; then
      kill -TERM "$pid" 2>/dev/null || true
    fi
  done < "$pid_file"
  local deadline=$((SECONDS + 30))
  while [[ $SECONDS -lt $deadline ]]; do
    local live=false
    while IFS= read -r pid; do
      [[ -n "$pid" ]] || continue
      if kill -0 "$pid" 2>/dev/null; then
        live=true
      fi
    done < "$pid_file"
    "$live" || break
    sleep 1
  done
  while IFS= read -r pid; do
    [[ -n "$pid" ]] || continue
    if kill -0 "$pid" 2>/dev/null; then
      kill -KILL "$pid" 2>/dev/null || true
    fi
  done < "$pid_file"
  deadline=$((SECONDS + 10))
  while [[ $SECONDS -lt $deadline ]]; do
    local live=false
    while IFS= read -r pid; do
      [[ -n "$pid" ]] || continue
      if kill -0 "$pid" 2>/dev/null; then
        live=true
      fi
    done < "$pid_file"
    "$live" || break
    sleep 1
  done
  : > "$pid_file"
}

cleanup() {
  if [[ "$KEEP_CLUSTER" == false ]]; then
    log "Stopping isolated E2E clusters"
    stop_from_file "$TARGET_PIDS"
    stop_from_file "$SOURCE_PIDS"
  else
    log "Keeping isolated E2E clusters; PID files: $SOURCE_PIDS $TARGET_PIDS"
  fi
}
trap cleanup EXIT

start_process() {
  local pid_file=$1
  local name=$2
  shift 2
  # Nebula 3.6 resolves its timezone data relative to the installation directory.
  # Keep that cwd while all data, PID and log locations remain explicit absolute paths.
  (cd "$INSTALL_ROOT" && exec "$@") >"$E2E_ROOT/logs/$name.launcher.log" 2>&1 &
  local pid=$!
  printf '%s\n' "$pid" >> "$pid_file"
  log "Started $name pid=$pid"
}

wait_http() {
  local url=$1
  local label=$2
  local output=""
  for _ in $(seq 1 60); do
    if output=$(curl --noproxy '*' --fail --silent --show-error --max-time 2 "$url/status" 2>&1); then
      log "$label is ready: $output"
      return 0
    fi
    sleep 1
  done
  fail "$label did not become ready at $url/status: $output"
}

ngql() {
  local graph_endpoint=$1
  local statement=$2
  local graph_host=${graph_endpoint%:*}
  local graph_port=${graph_endpoint##*:}
  timeout 30 "$CONSOLE_BIN" -addr "$graph_host" -port "$graph_port" -u root -p nebula -e "$statement"
}

assert_ngql_contains() {
  local graph_endpoint=$1
  local statement=$2
  local expected=$3
  local output
  set +e
  output=$(ngql "$graph_endpoint" "$statement" 2>&1)
  local status=$?
  set -e
  if [[ $status -ne 0 ]] || [[ "$output" != *"$expected"* ]]; then
    fail "Expected nGQL output to contain $expected, status=$status statement=$statement output=$output"
  fi
}

wait_graph() {
  local graph_endpoint=$1
  local label=$2
  local output=""
  for _ in $(seq 1 60); do
    if output=$(ngql "$graph_endpoint" "SHOW HOSTS" 2>&1); then
      log "$label graph service is ready"
      return 0
    fi
    sleep 1
  done
  fail "$label graph service did not become ready: $output"
}

wait_hosts_online() {
  local graph_endpoint=$1
  local label=$2
  local output=""
  for _ in $(seq 1 90); do
    if output=$(ngql "$graph_endpoint" "SHOW HOSTS" 2>&1); then
      local online
      online=$(printf '%s' "$output" | grep -o 'ONLINE' | wc -l | tr -d ' ')
      if [[ "$online" -ge 3 ]]; then
        log "$label has $online storage hosts ONLINE"
        return 0
      fi
    fi
    sleep 1
  done
  fail "$label storage hosts are not all ONLINE: $output"
}

node_host() {
  printf '%s.%d' "$1" "$(( $2 + 1 ))"
}

node_port() {
  printf '%d' "$(( $1 + ($2 * 10) ))"
}

cluster_ports() {
  local cluster=$1
  case "$cluster" in
    source)
      META_PORT=45500; STORAGE_PORT=45700; GRAPH_PORT=45900
      META_HTTP_PORT=46500; STORAGE_HTTP_PORT=46700; GRAPH_HTTP_PORT=46900
      META_NETWORK=127.10.1; STORAGE_NETWORK=127.10.2; GRAPH_NETWORK=127.10.3 ;;
    target)
      META_PORT=55500; STORAGE_PORT=55700; GRAPH_PORT=55900
      META_HTTP_PORT=56500; STORAGE_HTTP_PORT=56700; GRAPH_HTTP_PORT=56900
      META_NETWORK=127.20.1; STORAGE_NETWORK=127.20.2; GRAPH_NETWORK=127.20.3 ;;
    *) fail "Unknown cluster $cluster" ;;
  esac
  META_ADDRS="$(node_host "$META_NETWORK" 0):$(node_port "$META_PORT" 0),$(node_host "$META_NETWORK" 1):$(node_port "$META_PORT" 1),$(node_host "$META_NETWORK" 2):$(node_port "$META_PORT" 2)"
}

start_cluster() {
  local cluster=$1
  local pid_file=$2
  cluster_ports "$cluster"
  local base="$E2E_ROOT/$cluster"
  mkdir -p "$base"
  for index in 0 1 2; do
    local meta_host
    local meta_port
    meta_host=$(node_host "$META_NETWORK" "$index")
    meta_port=$(node_port "$META_PORT" "$index")
    mkdir -p "$base/meta-$index/data" "$base/meta-$index/logs"
    start_process "$pid_file" "$cluster-metad-$index" "$META_BIN" \
      --daemonize=false --pid_file="$base/meta-$index/metad.pid" \
      --log_dir="$base/meta-$index/logs" --minloglevel=1 --logbufsecs=0 \
      --meta_server_addrs="$META_ADDRS" --local_ip="$meta_host" --port="$meta_port" \
      --ws_ip="$meta_host" --ws_http_port="$META_HTTP_PORT" --data_path="$base/meta-$index/data" \
      --heartbeat_interval_secs=1 --raft_heartbeat_interval_secs=1 --num_io_threads=2 \
      --num_worker_threads=2
  done
  for index in 0 1 2; do
    wait_http "http://$(node_host "$META_NETWORK" "$index"):$META_HTTP_PORT" "$cluster metad-$index"
  done

  for index in 0 1 2; do
    local storage_host
    local storage_port
    storage_host=$(node_host "$STORAGE_NETWORK" "$index")
    storage_port=$(node_port "$STORAGE_PORT" "$index")
    mkdir -p "$base/storage-$index/data" "$base/storage-$index/logs"
    start_process "$pid_file" "$cluster-storaged-$index" "$STORAGE_BIN" \
      --daemonize=false --pid_file="$base/storage-$index/storaged.pid" \
      --log_dir="$base/storage-$index/logs" --minloglevel=1 --logbufsecs=0 \
      --meta_server_addrs="$META_ADDRS" --local_ip="$storage_host" --port="$storage_port" \
      --ws_ip="$storage_host" --ws_http_port="$STORAGE_HTTP_PORT" --data_path="$base/storage-$index/data" \
      --cluster_id_path="$base/storage-$index/cluster.id" \
      --minimum_reserved_bytes=0 --heartbeat_interval_secs=1 --raft_heartbeat_interval_secs=1 \
      --num_io_threads=2 --num_worker_threads=2 --rocksdb_block_cache=16
  done
  for index in 0 1 2; do
    local graph_host
    local graph_port
    graph_host=$(node_host "$GRAPH_NETWORK" "$index")
    graph_port=$(node_port "$GRAPH_PORT" "$index")
    mkdir -p "$base/graph-$index/logs"
    start_process "$pid_file" "$cluster-graphd-$index" "$GRAPH_BIN" --flagfile=/dev/null \
      --daemonize=false --pid_file="$base/graph-$index/graphd.pid" \
      --log_dir="$base/graph-$index/logs" --minloglevel=1 --logbufsecs=0 \
      --meta_server_addrs="$META_ADDRS" --local_ip="$graph_host" --port="$graph_port" \
      --ws_ip="$graph_host" --ws_http_port="$GRAPH_HTTP_PORT" \
      --cluster_id_path="$base/graph-$index/cluster.id" \
      --gflags_mode_json="$SERVER_ROOT/resources/gflags.json" \
      --heartbeat_interval_secs=1 --local_config=false --enable_authorize=false \
      --enable_client_white_list=false --enable_graph_mutation=true --num_netio_threads=2 \
      --num_worker_threads=2 --num_accept_threads=1
  done
  for index in 0 1 2; do
    wait_http "http://$(node_host "$GRAPH_NETWORK" "$index"):$GRAPH_HTTP_PORT" "$cluster graphd-$index"
  done
  local graph_endpoint="$(node_host "$GRAPH_NETWORK" 0):$GRAPH_PORT"
  wait_graph "$graph_endpoint" "$cluster"
  ngql "$graph_endpoint" "ADD HOSTS \"$(node_host "$STORAGE_NETWORK" 0)\":$(node_port "$STORAGE_PORT" 0),\"$(node_host "$STORAGE_NETWORK" 1)\":$(node_port "$STORAGE_PORT" 1),\"$(node_host "$STORAGE_NETWORK" 2)\":$(node_port "$STORAGE_PORT" 2)" \
    >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  for index in 0 1 2; do
    wait_http "http://$(node_host "$STORAGE_NETWORK" "$index"):$STORAGE_HTTP_PORT" "$cluster storaged-$index"
  done
  wait_hosts_online "$graph_endpoint" "$cluster"
}

write_properties() {
  local path=$1
  local workspace=$2
  local format=$3
  local layout=$4
  local full_checksum=$5
  cat > "$path" <<EOF
source.graph.addresses=127.10.3.1:45900,127.10.3.2:45910,127.10.3.3:45920
source.meta.addresses=127.10.1.1:45500,127.10.1.2:45510,127.10.1.3:45520
source.user=root
source.password=nebula
source.freeze.urls=http://127.10.3.1:46900/migration_freeze_status,http://127.10.3.2:46900/migration_freeze_status,http://127.10.3.3:46900/migration_freeze_status
target.graph.addresses=127.20.3.1:55900,127.20.3.2:55910,127.20.3.3:55920
target.meta.addresses=127.20.1.1:55500,127.20.1.2:55510,127.20.1.3:55520
target.user=root
target.password=nebula
workspace=$workspace
export.format=$format
export.file.layout=$layout
export.scan.limit=2
export.partition.concurrency=3
export.label.concurrency=1
import.batch.size=2
import.artifact.concurrency=1
import.retry.times=3
import.retry.backoff.ms=500
checkpoint.flush.batch.interval=1
metadata.schema.visibility.timeout.ms=30000
verify.sample.modulo=2
verify.full.checksum=$full_checksum
integrity.hmac.key=nebula-migration-default-hmac-key-v1
EOF
}

run_tool() {
  local command=$1
  local properties=$2
  log "Running migration command: $command"
  java -jar "$JAR" "$command" -c "$properties" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
}

interrupt_import_after_checkpoint() {
  local properties=$1
  local workspace=$2
  local checkpoint="$workspace/checkpoint.properties"
  log "Starting import process for checkpoint-resume interruption test"
  java -jar "$JAR" import -c "$properties" >>"$E2E_ROOT/evidence/e2e.log" 2>&1 &
  local pid=$!
  for _ in $(seq 1 300); do
    if [[ -s "$checkpoint" ]] && grep -q '^import\.' "$checkpoint"; then
      kill -KILL "$pid" 2>/dev/null || true
      local status
      set +e
      wait "$pid"
      status=$?
      set -e
      [[ $status -ne 0 ]] || fail "Interrupted import unexpectedly exited successfully"
      log "Import interrupted after checkpoint persistence, exit=$status"
      return 0
    fi
    if ! kill -0 "$pid" 2>/dev/null; then
      set +e
      wait "$pid"
      local status=$?
      set -e
      fail "Import exited before a checkpoint was observed, exit=$status"
    fi
    sleep 0.05
  done
  kill -KILL "$pid" 2>/dev/null || true
  set +e
  wait "$pid"
  set -e
  fail "Timed out waiting for import checkpoint"
}

expect_tool_failure() {
  local command=$1
  local properties=$2
  local required_text=$3
  local output
  set +e
  output=$(java -jar "$JAR" "$command" -c "$properties" 2>&1)
  local status=$?
  set -e
  printf '%s\n' "$output" >>"$E2E_ROOT/evidence/e2e.log"
  if [[ $status -eq 0 ]] || [[ "$output" != *"$required_text"* ]]; then
    fail "Expected $command to fail with $required_text, status=$status output=$output"
  fi
  log "Expected failure observed for $command: $required_text"
}

prepare_source_data() {
  local graph_endpoint=$SOURCE_GRAPH_ENDPOINT
  ngql "$graph_endpoint" "CREATE SPACE \`migration_string\`(partition_num=9, replica_factor=1, vid_type=FIXED_STRING(32))" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "CREATE SPACE \`migration_int\`(partition_num=9, replica_factor=1, vid_type=INT64)" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  sleep 5
  ngql "$graph_endpoint" "USE \`migration_string\`; CREATE TAG \`person\`(name string, age int, active bool, score double, born date, wake time, created datetime, expires_at timestamp, stay duration, point geography) ttl_duration=3600, ttl_col=\"expires_at\"" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; CREATE TAG \`note\`(text string)" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; CREATE EDGE \`knows\`(since datetime, weight double, stay duration)" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; CREATE EDGE \`plain\`()" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; CREATE TAG INDEX \`person_name\` ON \`person\`(name(20))" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; CREATE EDGE INDEX \`knows_since\` ON \`knows\`(since)" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_int\`; CREATE TAG \`metric\`(name string, value int, enabled bool, ratio double, event_date date, event_time time, event_at datetime, span duration)" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_int\`; CREATE EDGE \`rel\`(code string)" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  sleep 8
  ngql "$graph_endpoint" "USE \`migration_string\`; INSERT VERTEX \`person\`(name,age,active,score,born,wake,created,expires_at,stay,point) VALUES \"alice\":(\"Alice, \\\"A\\\"\\n中文\\\\path\",31,true,1.25,date(\"1993-01-02\"),time(\"08:09:10.123456\"),datetime(\"2025-01-02T03:04:05.123456\"),4102444800,duration({months:2,seconds:3,microseconds:4}),ST_GeogFromText(\"POINT(1 2)\")),\"bob\":(\"\",NULL,false,-0.5,date(\"2000-02-03\"),time(\"00:00:00\"),datetime(\"2024-02-03T04:05:06\"),4102444800,duration({months:-1,seconds:-2,microseconds:-3}),ST_GeogFromText(\"POINT(3 4)\"))" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; INSERT VERTEX \`note\`(text) VALUES \"alice\":(\"note\"),\"bob\":(\"second\")" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; INSERT EDGE \`knows\`(since,weight,stay) VALUES \"alice\"->\"bob\"@0:(datetime(\"2024-01-01T00:00:00\"),0.125,duration({months:0,seconds:9,microseconds:10})),\"alice\"->\"bob\"@7:(datetime(\"2024-01-02T00:00:00\"),-2.5,duration({months:1,seconds:0,microseconds:0}))" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_string\`; INSERT EDGE \`plain\`() VALUES \"bob\"->\"alice\"@2:()" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "USE \`migration_int\`; INSERT VERTEX \`metric\`(name,value,enabled,ratio,event_date,event_time,event_at,span) VALUES 1:(\"one\",11,true,3.5,date(\"2024-01-01\"),time(\"01:02:03\"),datetime(\"2024-01-01T01:02:03\"),duration({months:1,seconds:2,microseconds:3})),2:(\"two\",NULL,false,0.0,date(\"2024-02-02\"),time(\"02:03:04\"),datetime(\"2024-02-02T02:03:04\"),duration({months:0,seconds:-1,microseconds:0}))" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  for batch_start in $(seq 1000 100 1900); do
    local values=""
    for id in $(seq "$batch_start" "$((batch_start + 99))"); do
      [[ -z "$values" ]] || values+=","
      values+="$id:(\"resume-$id\")"
    done
    ngql "$graph_endpoint" "USE \`migration_int\`; INSERT VERTEX \`metric\`(name) VALUES $values" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  done
  ngql "$graph_endpoint" "USE \`migration_int\`; INSERT EDGE \`rel\`(code) VALUES 1->2@5:(\"r-5\")" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "CREATE USER \`migration_user\` WITH PASSWORD \"source-password\"" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  ngql "$graph_endpoint" "GRANT ROLE USER ON \`migration_string\` TO \`migration_user\`" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  sleep 8
}

freeze_source() {
  ngql "$SOURCE_GRAPH_ENDPOINT" "UPDATE CONFIGS graph:enable_graph_mutation=false" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
  for http_host in 127.10.3.1 127.10.3.2 127.10.3.3; do
    local status=""
    for _ in $(seq 1 60); do
      status=$(curl --noproxy '*' --fail --silent --show-error --max-time 2 "http://$http_host:46900/migration_freeze_status" 2>&1 || true)
      if [[ "$status" == *'"state":"FROZEN"'* ]]; then
        break
      fi
      sleep 1
    done
    [[ "$status" == *'"state":"FROZEN"'* ]] || fail "graphd HTTP freeze status not FROZEN: $status"
    printf '%s\n' "$status" > "$E2E_ROOT/evidence/source-freeze-$http_host.json"
  done
  for graph_endpoint in 127.10.3.1:45900 127.10.3.2:45910 127.10.3.3:45920; do
    local output
    set +e
    output=$(ngql "$graph_endpoint" "USE \`migration_int\`; INSERT VERTEX \`metric\`(name) VALUES 99:(\"must-fail\")" 2>&1)
    local status=$?
    set -e
    printf '%s\n' "$output" >>"$E2E_ROOT/evidence/e2e.log"
    if [[ "$output" != *"MUTATION_FROZEN"* ]]; then
      fail "Frozen graphd accepted or did not diagnose mutation: endpoint=$graph_endpoint exit=$status output=$output"
    fi
  done
  local ddl_output
  set +e
  ddl_output=$(ngql "$SOURCE_GRAPH_ENDPOINT" "USE \`migration_int\`; CREATE TAG \`must_fail_when_frozen\`(name string)" 2>&1)
  local ddl_status=$?
  set -e
  printf '%s\n' "$ddl_output" >>"$E2E_ROOT/evidence/e2e.log"
  if [[ "$ddl_output" != *"MUTATION_FROZEN"* ]]; then
    fail "Frozen graphd accepted or did not diagnose schema DDL: exit=$ddl_status output=$ddl_output"
  fi
  assert_ngql_contains "$SOURCE_GRAPH_ENDPOINT" "SHOW SPACES" "migration_int"
  log "Source cluster frozen across all graphd"
}

reset_target_cluster() {
  log "Resetting only the E2E-owned target cluster"
  stop_from_file "$TARGET_PIDS"
  rm -rf "$E2E_ROOT/target"
  : > "$TARGET_PIDS"
  start_cluster target "$TARGET_PIDS"
}

ulimit -n 65536
log "Building migration tool"
(cd "$TOOL_ROOT" && mvn -q package) >>"$E2E_ROOT/evidence/e2e.log" 2>&1

log "Starting source and target 3-storage clusters"
start_cluster source "$SOURCE_PIDS"
start_cluster target "$TARGET_PIDS"
prepare_source_data
freeze_source

LABEL_WORKSPACE="$E2E_ROOT/work-label"
LABEL_PROPERTIES="$E2E_ROOT/label.properties"
LABEL_FULL_PROPERTIES="$E2E_ROOT/label-full.properties"
LABEL_RESUME_PROPERTIES="$E2E_ROOT/label-resume.properties"
write_properties "$LABEL_PROPERTIES" "$LABEL_WORKSPACE" csv label false
write_properties "$LABEL_FULL_PROPERTIES" "$LABEL_WORKSPACE" csv label true
write_properties "$LABEL_RESUME_PROPERTIES" "$LABEL_WORKSPACE" csv label false
printf '\nimport.batch.size=1\n' >> "$LABEL_RESUME_PROPERTIES"

run_tool precheck "$LABEL_PROPERTIES"
run_tool export "$LABEL_PROPERTIES"
rg -Fq 'CREATE USER `migration_user` WITH PASSWORD "nebula"' "$LABEL_WORKSPACE/meta/metadata.nql" \
  || fail "Metadata export did not use the required default password"
rg -q '"ttlDetected":"true"' "$LABEL_WORKSPACE/reports/export-report.json" \
  || fail "TTL detection was not recorded in the export report"
rg -q '"rootUser":"root"' "$LABEL_WORKSPACE/reports/export-report.json" \
  || fail "Root audit information was not recorded in the export report"
rg -q '"extendedPrivileges":"WARNING_NOT_EXPORTED_UNSUPPORTED_EXTENSION_PRIVILEGES"' "$LABEL_WORKSPACE/reports/export-report.json" \
  || fail "Extension privilege exclusion was not recorded in the export report"

FIRST_ARTIFACT=$(find "$LABEL_WORKSPACE/data" -type f -name '*.csv' | sort | head -1)
[[ -n "$FIRST_ARTIFACT" ]] || fail "Label export produced no CSV artifact"
rm -f "$FIRST_ARTIFACT.sig"
expect_tool_failure import "$LABEL_PROPERTIES" "Artifact is incomplete"
run_tool export "$LABEL_PROPERTIES"
LABEL_MTIME=$(stat -c %Y "$FIRST_ARTIFACT")
sleep 1
run_tool export "$LABEL_PROPERTIES"
[[ "$LABEL_MTIME" == "$(stat -c %Y "$FIRST_ARTIFACT")" ]] \
  || fail "Signed label artifact was unexpectedly re-exported"
printf 'corruption\n' >> "$FIRST_ARTIFACT"
expect_tool_failure import "$LABEL_PROPERTIES" "SHA-256 mismatch"
run_tool export "$LABEL_PROPERTIES"

ngql "$TARGET_GRAPH_ENDPOINT" "CREATE SPACE \`must_be_removed_manually\`(partition_num=1, replica_factor=1, vid_type=INT64)" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
sleep 3
expect_tool_failure import "$LABEL_PROPERTIES" "Target has business spaces"
ngql "$TARGET_GRAPH_ENDPOINT" "DROP SPACE \`must_be_removed_manually\`" >>"$E2E_ROOT/evidence/e2e.log" 2>&1
sleep 5

interrupt_import_after_checkpoint "$LABEL_RESUME_PROPERTIES" "$LABEL_WORKSPACE"
run_tool import "$LABEL_RESUME_PROPERTIES"
assert_ngql_contains "$TARGET_GRAPH_ENDPOINT" "SHOW USERS" "migration_user"
assert_ngql_contains "$TARGET_GRAPH_ENDPOINT" "SHOW USERS" "root"
assert_ngql_contains "$TARGET_GRAPH_ENDPOINT" "SHOW ROLES IN \`migration_string\`" "migration_user"
assert_ngql_contains "$TARGET_GRAPH_ENDPOINT" "USE \`migration_string\`; SHOW TAG INDEXES" "person_name"
assert_ngql_contains "$TARGET_GRAPH_ENDPOINT" "USE \`migration_string\`; SHOW EDGE INDEXES" "knows_since"
RETRY_ARTIFACT="$LABEL_WORKSPACE/data/migration_int/vertex/metric.csv"
RETRY_NGQL='INSERT VERTEX `metric`(`enabled`,`event_at`,`event_date`,`event_time`,`name`,`ratio`,`span`,`value`) VALUES 1:(true,datetime(\"2024-01-01T01:02:03.000000\"),date(\"2024-01-01\"),time(\"01:02:03.000000\"),\"one\",3.5,duration({months:1,seconds:2,microseconds:3}),11)'
printf '{"artifact":"%s","row":1,"ngql":"%s"}\n' "$RETRY_ARTIFACT" "$RETRY_NGQL" > "$LABEL_WORKSPACE/failures/import-failures.jsonl"
run_tool retry-failed "$LABEL_PROPERTIES"
[[ ! -s "$LABEL_WORKSPACE/failures/import-failures.jsonl" ]] || fail "Resolved retry records remained queued"
[[ -s "$LABEL_WORKSPACE/failures/import-retry-history.jsonl" ]] || fail "Retry history was not written"
run_tool verify "$LABEL_PROPERTIES"
cp "$LABEL_WORKSPACE/reports/verify-report.json" "$E2E_ROOT/evidence/verify-report-label-default.json"
rg -q '"fullConsistencyProven":"false"' "$LABEL_WORKSPACE/reports/verify-report.json" \
  || fail "Default verification did not report limited proof"
run_tool verify "$LABEL_FULL_PROPERTIES"
cp "$LABEL_WORKSPACE/reports/verify-report.json" "$E2E_ROOT/evidence/verify-report-label-full.json"

reset_target_cluster

PARTITION_WORKSPACE="$E2E_ROOT/work-partition"
PARTITION_PROPERTIES="$E2E_ROOT/partition.properties"
write_properties "$PARTITION_PROPERTIES" "$PARTITION_WORKSPACE" json partition true
printf '\nexport.label.concurrency=2\n' >> "$PARTITION_PROPERTIES"
printf 'verify.sample.max.records=1\n' >> "$PARTITION_PROPERTIES"
run_tool precheck "$PARTITION_PROPERTIES"
run_tool export "$PARTITION_PROPERTIES"
PARTITION_ARTIFACT=$(find "$PARTITION_WORKSPACE/data" -type f -name '*.jsonl' | sort | head -1)
[[ -n "$PARTITION_ARTIFACT" ]] || fail "Partition export produced no JSON artifact"
PARTITION_MTIME=$(stat -c %Y "$PARTITION_ARTIFACT")
sleep 1
run_tool export "$PARTITION_PROPERTIES"
[[ "$PARTITION_MTIME" == "$(stat -c %Y "$PARTITION_ARTIFACT")" ]] || fail "Signed partition was unexpectedly re-exported"
run_tool import "$PARTITION_PROPERTIES"
run_tool verify "$PARTITION_PROPERTIES"
cp "$PARTITION_WORKSPACE/reports/verify-report.json" "$E2E_ROOT/evidence/verify-report-partition-full.json"

log "E2E PASS: CSV/label and JSON/partition migrations verified on source/target 3-storage clusters"
