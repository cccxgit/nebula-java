# Nebula Graph Migration Tool

This tool performs a one-time full migration between two Nebula Graph 3.6 clusters. It uses
nebula-java only: StorageClient scans source data and graph nGQL INSERT statements populate the
target. The source must be frozen by the graphd `enable_graph_mutation=false` control before
`export` runs.

Vertex scans share the source StorageClient. For edge scans, each in-flight partition leases a
dedicated StorageClient for its full pagination lifetime. This preserves partition concurrency
while avoiding the mutable shared connection-pool behavior in nebula-java 3.8's edge iterator.

Freeze and export operate on the graphd nGQL mutation boundary. Stop all business writers and
data-changing background jobs first; direct storage write clients are outside this graphd guard and
must not be active. Freeze every source graphd, wait for each HTTP endpoint to report `FROZEN`,
then run `precheck` and `export`. Keep the source frozen until the required validation boundary is
reached, then explicitly restore `enable_graph_mutation=true`.

```ngql
UPDATE CONFIGS graph:enable_graph_mutation=false;
```

The fixed built-in HMAC key is a completion marker, not a security secret. Each `.sig` sidecar
contains HMAC-protected file name, byte size, SHA-256 and recovery statistics; do not edit it.

`precheck` requires graphd and metad to report an embedded `3.6` build version. Build the server
with `-DNEBULA_BUILD_VERSION=3.6.0`; `compatibility.allow.unreported.server.version=true` is an
explicit development-only exception and is recorded in the precheck report. Nebula 3.6's nGQL
host API does not expose a semantic version for storage hosts, so the tool verifies every storage
host is `ONLINE` and records that limitation in the same report.

Build:

```bash
mvn test package
```

Commands:

```bash
bin/nebula-migration precheck -c conf/migration.properties
bin/nebula-migration export -c conf/migration.properties
bin/nebula-migration import -c conf/migration.properties
bin/nebula-migration verify -c conf/migration.properties
bin/nebula-migration retry-failed -c conf/migration.properties
```

The workspace contains `manifest.properties`, checkpoints, reports, signed data files and
failure JSON Lines. Import never drops target objects automatically. A schema/index failure or a
non-empty target requires the operator to clean the target explicitly before retrying.

`retry-failed` is the only supported path for unresolved row failures. Import checkpoints are
contiguous prefixes, so rows after a failed row can be replayed safely without silently skipping
the failed record.

Import renders one multi-value `INSERT VERTEX` or `INSERT EDGE` statement per batch and imports
independent data artifacts concurrently. `import.artifact.concurrency` defaults to `8` and is
limited to `1-16`; each worker holds one graph session. `checkpoint.flush.batch.interval` defaults
to `20`, so an unplanned stop can replay at most `import.batch.size * interval` rows per active
artifact. Replayed rows use the documented idempotent INSERT behavior.
