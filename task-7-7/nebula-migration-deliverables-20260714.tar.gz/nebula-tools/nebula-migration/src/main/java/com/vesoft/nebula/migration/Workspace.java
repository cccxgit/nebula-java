package com.vesoft.nebula.migration;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public final class Workspace implements AutoCloseable {
    private final Path root;
    private final FileChannel lockChannel;
    private final FileLock lock;

    private Workspace(Path root, FileChannel lockChannel, FileLock lock) {
        this.root = root;
        this.lockChannel = lockChannel;
        this.lock = lock;
    }

    public static Workspace open(MigrationConfig config) throws MigrationException {
        Path root = config.workspace();
        try {
            Files.createDirectories(root);
            Files.createDirectories(root.resolve("data"));
            Files.createDirectories(root.resolve("meta"));
            Files.createDirectories(root.resolve("reports"));
            Files.createDirectories(root.resolve("failures"));
            FileChannel channel = FileChannel.open(root.resolve(".workspace.lock"),
                    StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            FileLock lock = channel.tryLock();
            if (lock == null) {
                channel.close();
                throw new MigrationException(ExitCode.USAGE,
                        "Another migration command owns workspace " + root);
            }
            return new Workspace(root, channel, lock);
        } catch (IOException e) {
            throw new MigrationException(ExitCode.INTERNAL_ERROR, "Cannot open workspace " + root, e);
        }
    }

    public Path root() {
        return root;
    }

    public Path data() {
        return root.resolve("data");
    }

    public Path meta() {
        return root.resolve("meta");
    }

    public Path reports() {
        return root.resolve("reports");
    }

    public Path failures() {
        return root.resolve("failures");
    }

    public Path manifestPath() {
        return root.resolve("manifest.properties");
    }

    public Path checkpointPath() {
        return root.resolve("checkpoint.properties");
    }

    @Override
    public void close() throws MigrationException {
        try {
            lock.release();
            lockChannel.close();
        } catch (IOException e) {
            throw new MigrationException(ExitCode.INTERNAL_ERROR, "Cannot release workspace lock", e);
        }
    }
}
