package com.vesoft.nebula.migration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class NgqlRenderer {
    private NgqlRenderer() {
    }

    public static String render(ArtifactDescriptor descriptor, MigrationRecord record)
            throws MigrationException {
        return renderBatch(descriptor, Collections.singletonList(record));
    }

    public static String renderBatch(ArtifactDescriptor descriptor, List<MigrationRecord> records)
            throws MigrationException {
        if (records == null || records.isEmpty()) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot render an empty INSERT batch");
        }
        MigrationRecord first = records.get(0);
        validateKind(descriptor, first);
        List<String> propertyNames = new ArrayList<String>(first.properties().keySet());
        List<String> names = new ArrayList<String>();
        for (String propertyName : propertyNames) {
            names.add(ClusterClient.identifier(propertyName));
        }
        String propertyList = "(" + join(names) + ")";
        StringBuilder statement = new StringBuilder();
        if (first.kind() == MigrationRecord.Kind.VERTEX) {
            statement.append("INSERT VERTEX ");
        } else {
            statement.append("INSERT EDGE ");
        }
        statement.append(ClusterClient.identifier(descriptor.label())).append(propertyList).append(" VALUES ");
        for (int index = 0; index < records.size(); index++) {
            MigrationRecord record = records.get(index);
            validateKind(descriptor, record);
            if (!propertyNames.equals(new ArrayList<String>(record.properties().keySet()))) {
                throw new MigrationException(ExitCode.IMPORT_FAILED,
                        "Records in one import batch have different property columns");
            }
            if (index > 0) {
                statement.append(',');
            }
            if (record.kind() == MigrationRecord.Kind.VERTEX) {
                statement.append(record.firstKey().ngqlLiteral());
            } else {
                statement.append(record.firstKey().ngqlLiteral()).append("->")
                        .append(record.secondKey().ngqlLiteral()).append('@').append(record.rank());
            }
            statement.append(':').append(valueList(record, propertyNames));
        }
        return statement.toString();
    }

    private static void validateKind(ArtifactDescriptor descriptor, MigrationRecord record)
            throws MigrationException {
        if (descriptor.kind() != record.kind()) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Artifact record kind does not match path");
        }
    }

    private static String valueList(MigrationRecord record, List<String> propertyNames)
            throws MigrationException {
        List<String> values = new ArrayList<String>();
        for (String propertyName : propertyNames) {
            values.add(record.properties().get(propertyName).ngqlLiteral());
        }
        return "(" + join(values) + ")";
    }

    private static String join(List<String> values) {
        StringBuilder builder = new StringBuilder();
        for (int index = 0; index < values.size(); index++) {
            if (index > 0) {
                builder.append(',');
            }
            builder.append(values.get(index));
        }
        return builder.toString();
    }
}
