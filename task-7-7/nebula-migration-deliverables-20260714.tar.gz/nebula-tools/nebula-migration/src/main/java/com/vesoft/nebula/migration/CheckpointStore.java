package com.vesoft.nebula.migration;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Properties;

public final class CheckpointStore {
    private final Path path;
    private final Properties values = new Properties();
    private final int flushBatchInterval;
    private int pendingUpdates;
    private boolean dirty;

    public CheckpointStore(Workspace workspace) throws MigrationException {
        this(workspace, 1);
    }

    public CheckpointStore(Workspace workspace, int flushBatchInterval) throws MigrationException {
        if (flushBatchInterval <= 0) {
            throw new MigrationException(ExitCode.USAGE,
                    "checkpoint.flush.batch.interval must be positive");
        }
        this.path = workspace.checkpointPath();
        this.flushBatchInterval = flushBatchInterval;
        if (Files.exists(path)) {
            try (InputStream input = Files.newInputStream(path)) {
                values.load(input);
            } catch (IOException e) {
                throw new MigrationException(ExitCode.INTERNAL_ERROR, "Cannot load checkpoint", e);
            }
        }
    }

    public synchronized long importedRows(Path artifact) {
        return Long.parseLong(values.getProperty(key(artifact), "0"));
    }

    public synchronized void markImported(Path artifact, long rows) throws MigrationException {
        values.setProperty(key(artifact), String.valueOf(rows));
        dirty = true;
        pendingUpdates++;
        if (pendingUpdates >= flushBatchInterval) {
            flush();
        }
    }

    public synchronized void flush() throws MigrationException {
        if (!dirty) {
            return;
        }
        try {
            AtomicFiles.storeProperties(path, values, "Nebula Graph migration checkpoint");
            dirty = false;
            pendingUpdates = 0;
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot persist import checkpoint", e);
        }
    }

    /**
     * A checkpoint is a contiguous prefix, never the largest successful row number. This keeps a
     * failed row eligible for recovery even when later rows in the same fallback batch succeeded.
     */
    public synchronized boolean markImportedIfNext(Path artifact, long row) throws MigrationException {
        if (row != importedRows(artifact) + 1) {
            return false;
        }
        markImported(artifact, row);
        return true;
    }

    private String key(Path artifact) {
        return "import." + Base64.getUrlEncoder().withoutPadding().encodeToString(
                artifact.toAbsolutePath().toString().getBytes(StandardCharsets.UTF_8));
    }
}
