package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.data.HostAddress;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public final class MigrationConfig {
    public static final String EXPECTED_SERVER_VERSION = "3.6";
    public static final String DEFAULT_HMAC_KEY = "nebula-migration-default-hmac-key-v1";

    private final Properties values;
    private final Path configPath;

    private MigrationConfig(Path configPath, Properties values) {
        this.configPath = configPath;
        this.values = values;
    }

    public static MigrationConfig load(String path) throws MigrationException {
        Path configPath = Paths.get(path).toAbsolutePath().normalize();
        Properties values = new Properties();
        try (InputStream input = Files.newInputStream(configPath)) {
            values.load(input);
        } catch (IOException e) {
            throw new MigrationException(ExitCode.USAGE, "Cannot load configuration " + configPath, e);
        }
        MigrationConfig config = new MigrationConfig(configPath, values);
        config.validate();
        return config;
    }

    private void validate() throws MigrationException {
        required("source.graph.addresses");
        required("source.meta.addresses");
        required("source.user");
        required("source.password");
        required("target.graph.addresses");
        required("target.meta.addresses");
        required("target.user");
        required("target.password");
        required("workspace");
        String format = exportFormat();
        if (!"csv".equals(format) && !"json".equals(format)) {
            throw new MigrationException(ExitCode.USAGE, "export.format must be csv or json");
        }
        String layout = exportLayout();
        if (!"label".equals(layout) && !"partition".equals(layout)) {
            throw new MigrationException(ExitCode.USAGE, "export.file.layout must be label or partition");
        }
        try {
            if (scanLimit() <= 0 || partitionConcurrency() <= 0 || labelConcurrency() <= 0
                    || importBatchSize() <= 0 || importArtifactConcurrency() <= 0
                    || importRetryTimes() < 0 || retryBackoffMs() < 0
                    || sampleModulo() <= 0 || sampleMaxRecords() <= 0
                    || schemaVisibilityTimeoutMs() <= 0 || checkpointFlushBatchInterval() <= 0) {
                throw new MigrationException(ExitCode.USAGE,
                        "Migration numeric configuration must be positive");
            }
            if (importArtifactConcurrency() > 16) {
                throw new MigrationException(ExitCode.USAGE,
                        "import.artifact.concurrency must not exceed the 16-session graph pool limit");
            }
        } catch (NumberFormatException e) {
            throw new MigrationException(ExitCode.USAGE,
                    "Migration numeric configuration contains a non-integer value", e);
        }
    }

    private void required(String key) throws MigrationException {
        if (get(key, "").trim().isEmpty()) {
            throw new MigrationException(ExitCode.USAGE, "Missing required configuration: " + key);
        }
    }

    public Path configPath() {
        return configPath;
    }

    public Path workspace() {
        Path configured = Paths.get(get("workspace", "work/migration-job"));
        if (!configured.isAbsolute()) {
            configured = configPath.getParent().resolve(configured);
        }
        return configured.toAbsolutePath().normalize();
    }

    public String exportFormat() {
        return get("export.format", "csv").toLowerCase();
    }

    public String exportLayout() {
        return get("export.file.layout", "label").toLowerCase();
    }

    public int scanLimit() {
        return integer("export.scan.limit", 1000);
    }

    public int partitionConcurrency() {
        return integer("export.partition.concurrency", 8);
    }

    public int labelConcurrency() {
        return integer("export.label.concurrency", 1);
    }

    public int importBatchSize() {
        return integer("import.batch.size", 500);
    }

    public int importArtifactConcurrency() {
        return integer("import.artifact.concurrency", 8);
    }

    public int importRetryTimes() {
        return integer("import.retry.times", 3);
    }

    public long retryBackoffMs() {
        return longValue("import.retry.backoff.ms", 1000L);
    }

    public int checkpointFlushBatchInterval() {
        return integer("checkpoint.flush.batch.interval", 20);
    }

    public long schemaVisibilityTimeoutMs() {
        return longValue("metadata.schema.visibility.timeout.ms", 60000L);
    }

    public int sampleModulo() {
        return integer("verify.sample.modulo", 1000);
    }

    public int sampleMaxRecords() {
        return integer("verify.sample.max.records", 10000);
    }

    public boolean fullChecksumEnabled() {
        return Boolean.parseBoolean(get("verify.full.checksum", "false"));
    }

    /**
     * Nebula development builds can omit NEBULA_BUILD_VERSION, which leaves the nGQL version
     * field empty. Production migrations keep this disabled so that an absent build version
     * cannot silently bypass the 3.6-only compatibility contract.
     */
    public boolean allowUnreportedServerVersion() {
        return Boolean.parseBoolean(get("compatibility.allow.unreported.server.version", "false"));
    }

    public String hmacKey() {
        return DEFAULT_HMAC_KEY;
    }

    public List<String> freezeUrls() {
        return split(get("source.freeze.urls", ""));
    }

    public Cluster source() throws MigrationException {
        return cluster("source");
    }

    public Cluster target() throws MigrationException {
        return cluster("target");
    }

    private Cluster cluster(String prefix) throws MigrationException {
        return new Cluster(
                parseAddresses(get(prefix + ".graph.addresses", "")),
                parseAddresses(get(prefix + ".meta.addresses", "")),
                get(prefix + ".user", ""),
                get(prefix + ".password", ""));
    }

    private List<HostAddress> parseAddresses(String raw) throws MigrationException {
        List<HostAddress> addresses = new ArrayList<HostAddress>();
        for (String token : split(raw)) {
            int separator = token.lastIndexOf(':');
            if (separator <= 0 || separator == token.length() - 1) {
                throw new MigrationException(ExitCode.USAGE, "Invalid address: " + token);
            }
            try {
                addresses.add(new HostAddress(token.substring(0, separator),
                        Integer.parseInt(token.substring(separator + 1))));
            } catch (NumberFormatException e) {
                throw new MigrationException(ExitCode.USAGE, "Invalid port in address: " + token, e);
            }
        }
        if (addresses.isEmpty()) {
            throw new MigrationException(ExitCode.USAGE, "At least one address is required");
        }
        return addresses;
    }

    private List<String> split(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return Collections.emptyList();
        }
        List<String> result = new ArrayList<String>();
        for (String item : raw.split(",")) {
            if (!item.trim().isEmpty()) {
                result.add(item.trim());
            }
        }
        return result;
    }

    private int integer(String key, int defaultValue) {
        return Integer.parseInt(get(key, String.valueOf(defaultValue)));
    }

    private long longValue(String key, long defaultValue) {
        return Long.parseLong(get(key, String.valueOf(defaultValue)));
    }

    private String get(String key, String defaultValue) {
        return values.getProperty(key, defaultValue).trim();
    }

    public static final class Cluster {
        private final List<HostAddress> graphAddresses;
        private final List<HostAddress> metaAddresses;
        private final String user;
        private final String password;

        private Cluster(List<HostAddress> graphAddresses, List<HostAddress> metaAddresses,
                        String user, String password) {
            this.graphAddresses = graphAddresses;
            this.metaAddresses = metaAddresses;
            this.user = user;
            this.password = password;
        }

        public List<HostAddress> graphAddresses() {
            return graphAddresses;
        }

        public List<HostAddress> metaAddresses() {
            return metaAddresses;
        }

        public String user() {
            return user;
        }

        public String password() {
            return password;
        }
    }
}
