package com.vesoft.nebula.migration;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.regex.Pattern;

/** Maps Nebula identifiers to one safe workspace path component without changing manifest names. */
public final class ArtifactPaths {
    private static final Pattern SAFE_COMPONENT = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]*");

    private ArtifactPaths() {
    }

    public static String component(String identifier) {
        if (SAFE_COMPONENT.matcher(identifier).matches() && !".".equals(identifier)
                && !"..".equals(identifier)) {
            return identifier;
        }
        // '~' cannot be returned by the safe branch, so encoded names cannot collide with it.
        return "~" + Base64.getUrlEncoder().withoutPadding().encodeToString(
                identifier.getBytes(StandardCharsets.UTF_8));
    }
}
