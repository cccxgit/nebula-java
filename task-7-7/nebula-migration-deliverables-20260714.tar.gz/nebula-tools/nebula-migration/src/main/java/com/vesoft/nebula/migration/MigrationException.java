package com.vesoft.nebula.migration;

public final class MigrationException extends Exception {
    private final ExitCode exitCode;

    public MigrationException(ExitCode exitCode, String message) {
        super(message);
        this.exitCode = exitCode;
    }

    public MigrationException(ExitCode exitCode, String message, Throwable cause) {
        super(message, cause);
        this.exitCode = exitCode;
    }

    public ExitCode exitCode() {
        return exitCode;
    }
}
