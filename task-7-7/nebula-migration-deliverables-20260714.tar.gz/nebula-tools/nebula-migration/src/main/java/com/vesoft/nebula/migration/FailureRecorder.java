package com.vesoft.nebula.migration;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

public final class FailureRecorder {
    private final Path path;

    public FailureRecorder(Workspace workspace) {
        this.path = workspace.failures().resolve("import-failures.jsonl");
    }

    public synchronized void record(ArtifactDescriptor artifact, long rowNumber, String line, String ngql,
                                    String error, int attempts) throws MigrationException {
        String value = "{\"timestamp\":" + MiniJson.quote(Instant.now().toString())
                + ",\"artifact\":" + MiniJson.quote(artifact.path().toString())
                + ",\"artifactId\":" + MiniJson.quote(artifact.id())
                + ",\"space\":" + MiniJson.quote(artifact.space())
                + ",\"row\":" + rowNumber
                + ",\"record\":" + MiniJson.quote(line)
                + ",\"ngql\":" + MiniJson.quote(ngql)
                + ",\"error\":" + MiniJson.quote(error)
                + ",\"attempts\":" + attempts + "}\n";
        try {
            Files.write(path, value.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot write failure record", e);
        }
    }

    public Path path() {
        return path;
    }

    public boolean hasUnresolved() throws MigrationException {
        if (!Files.exists(path)) {
            return false;
        }
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    return true;
                }
            }
            return false;
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED,
                    "Cannot inspect failure records", e);
        }
    }
}
