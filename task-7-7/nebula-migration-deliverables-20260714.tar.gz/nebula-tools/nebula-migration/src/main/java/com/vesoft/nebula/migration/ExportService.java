package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.net.Session;
import com.vesoft.nebula.client.storage.StorageClient;
import com.vesoft.nebula.client.storage.data.EdgeRow;
import com.vesoft.nebula.client.storage.data.VertexRow;
import com.vesoft.nebula.client.storage.scan.ScanEdgeResult;
import com.vesoft.nebula.client.storage.scan.ScanEdgeResultIterator;
import com.vesoft.nebula.client.storage.scan.ScanVertexResult;
import com.vesoft.nebula.client.storage.scan.ScanVertexResultIterator;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class ExportService {
    private final MetadataService metadataService = new MetadataService();

    public void export(ClusterClient source, Workspace workspace, Manifest manifest,
                       MigrationConfig config) throws MigrationException {
        manifest.initialize(config);
        manifest.setState(Manifest.State.EXPORTING);
        metadataService.exportMetadata(source, workspace, manifest, config);

        Session session = source.openSession();
        try {
            List<String> spaces = ClusterInspector.spaces(source, session, ExitCode.EXPORT_FAILED);
            Collections.sort(spaces);
            for (String space : spaces) {
                exportSpace(source, session, workspace, manifest, config, space,
                        MigrationRecord.Kind.VERTEX);
                exportSpace(source, session, workspace, manifest, config, space,
                        MigrationRecord.Kind.EDGE);
            }
        } finally {
            session.release();
        }
        manifest.setState(Manifest.State.EXPORTED);
    }

    private void exportSpace(ClusterClient source, Session session, Workspace workspace,
                             Manifest manifest, MigrationConfig config, String space,
                             MigrationRecord.Kind kind) throws MigrationException {
        List<String> labels = ClusterInspector.labels(source, session, space, kind);
        List<Integer> partitions = ClusterInspector.partitions(source, session, space);
        Collections.sort(labels);
        ExecutorService workers = Executors.newFixedThreadPool(config.labelConcurrency());
        List<Future<Void>> futures = new ArrayList<Future<Void>>();
        try {
            for (final String label : labels) {
                futures.add(workers.submit(new Callable<Void>() {
                    @Override
                    public Void call() throws Exception {
                        exportLabel(source, workspace, manifest, config, space, kind, label,
                                partitions);
                        return null;
                    }
                }));
            }
            for (Future<Void> future : futures) {
                try {
                    future.get();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new MigrationException(ExitCode.EXPORT_FAILED,
                            "Label export interrupted", e);
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof MigrationException) {
                        throw (MigrationException) cause;
                    }
                    throw new MigrationException(ExitCode.EXPORT_FAILED, "Label export failed", cause);
                }
            }
        } finally {
            workers.shutdownNow();
        }
    }

    private void exportLabel(ClusterClient source, Workspace workspace, Manifest manifest,
                             MigrationConfig config, String space, MigrationRecord.Kind kind,
                             String label, List<Integer> partitions) throws MigrationException {
        String extension = "csv".equals(config.exportFormat()) ? "csv" : "jsonl";
        Path directory = workspace.data().resolve(ArtifactPaths.component(space)).resolve(kind.pathName());
        Path finalPath = directory.resolve(ArtifactPaths.component(label) + "." + extension);
        ArtifactDescriptor labelArtifact = new ArtifactDescriptor(finalPath, space, kind, label, null,
                config.exportFormat());
        if ("label".equals(config.exportLayout())
                && restoreCompletedLabel(workspace, manifest, config, labelArtifact, partitions)) {
            return;
        }

        ExecutorService workers = Executors.newFixedThreadPool(config.partitionConcurrency());
        List<Future<PartExportResult>> futures = new ArrayList<Future<PartExportResult>>();
        StorageClient sharedStorage = kind == MigrationRecord.Kind.VERTEX ? source.storage() : null;
        EdgeScanClientPool edgeClients = kind == MigrationRecord.Kind.EDGE
                ? new EdgeScanClientPool(source, config.partitionConcurrency()) : null;
        try {
            for (Integer partition : partitions) {
                Path partTarget = "partition".equals(config.exportLayout())
                        ? directory.resolve(label + ".part-" + partition + "." + extension)
                        : directory.resolve(".staging").resolve(label + ".part-" + partition + "." + extension);
                Map<String, String> completed = "partition".equals(config.exportLayout())
                        ? completionMetadataOrNull(partTarget, config) : null;
                if (completed != null) {
                    futures.add(new CompletedFuture(recoverCompletedPartition(partition, partTarget, completed)));
                } else {
                    futures.add(workers.submit(new PartExportTask(sharedStorage, edgeClients, config, space,
                            kind, label, partition, partTarget)));
                }
            }
            List<PartExportResult> results = collect(futures);
            Collections.sort(results, new Comparator<PartExportResult>() {
                @Override
                public int compare(PartExportResult left, PartExportResult right) {
                    return left.partition - right.partition;
                }
            });
            if ("label".equals(config.exportLayout())) {
                PartExportResult merged = mergeLabel(workspace, config, finalPath, results);
                Integrity.markCompleted(finalPath, config.hmacKey(), labelCompletionMetadata(merged, results));
                registerLabelArtifact(workspace, manifest, labelArtifact, merged, results);
                deleteStagingFiles(results);
            } else {
                for (PartExportResult result : results) {
                    if (!result.alreadyCompleted) {
                        Integrity.markCompleted(result.path, config.hmacKey(),
                                partitionCompletionMetadata(result));
                    }
                    manifest.addArtifact(workspace.root(), new ArtifactDescriptor(result.path, space, kind,
                            label, result.partition, config.exportFormat()), result.rowCount,
                            result.canonicalDigest());
                }
            }
        } finally {
            workers.shutdownNow();
            if (edgeClients != null) {
                edgeClients.close();
            }
        }
    }

    private List<PartExportResult> collect(List<Future<PartExportResult>> futures)
            throws MigrationException {
        List<PartExportResult> results = new ArrayList<PartExportResult>();
        for (Future<PartExportResult> future : futures) {
            try {
                results.add(future.get());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new MigrationException(ExitCode.EXPORT_FAILED, "Partition export interrupted", e);
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                if (cause instanceof MigrationException) {
                    throw (MigrationException) cause;
                }
                throw new MigrationException(ExitCode.EXPORT_FAILED, "Partition export failed", cause);
            }
        }
        return results;
    }

    private PartExportResult mergeLabel(Workspace workspace, MigrationConfig config, Path finalPath,
                                        List<PartExportResult> results) throws MigrationException {
        Path temporary = finalPath.resolveSibling(finalPath.getFileName().toString() + ".tmp");
        CanonicalAccumulator accumulator = new CanonicalAccumulator();
        long count = 0L;
        try {
            Files.createDirectories(finalPath.getParent());
            try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                if ("csv".equals(config.exportFormat())) {
                    writer.write(RecordCodec.CSV_HEADER);
                    writer.newLine();
                }
                for (PartExportResult result : results) {
                    try (BufferedReader reader = Files.newBufferedReader(result.path, StandardCharsets.UTF_8)) {
                        String line;
                        boolean first = true;
                        while ((line = reader.readLine()) != null) {
                            if (first && "csv".equals(config.exportFormat())) {
                                first = false;
                                continue;
                            }
                            first = false;
                            writer.write(line);
                            writer.newLine();
                        }
                    }
                    accumulator.merge(result.accumulator);
                    count += result.rowCount;
                }
            }
            AtomicFiles.force(temporary);
            AtomicFiles.move(temporary, finalPath);
            return new PartExportResult(-1, finalPath, count, accumulator, false);
        } catch (IOException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot merge label artifact " + finalPath, e);
        }
    }

    private boolean restoreCompletedLabel(Workspace workspace, Manifest manifest, MigrationConfig config,
                                          ArtifactDescriptor artifact, List<Integer> partitions)
            throws MigrationException {
        Map<String, String> metadata = completionMetadataOrNull(artifact.path(), config);
        if (metadata == null) {
            return false;
        }
        PartExportResult result = recoverCompletedPartition(-1, artifact.path(), metadata);
        List<PartExportResult> partitionResults = new ArrayList<PartExportResult>();
        for (Integer partition : partitions) {
            String prefix = "partition." + partition + ".";
            partitionResults.add(new PartExportResult(partition, artifact.path(),
                    requiredLong(metadata, prefix + "row.count", artifact.path()),
                    required(metadata, prefix + "canonical.digest", artifact.path()), true));
        }
        registerLabelArtifact(workspace, manifest, artifact, result, partitionResults);
        return true;
    }

    private void registerLabelArtifact(Workspace workspace, Manifest manifest, ArtifactDescriptor artifact,
                                       PartExportResult merged, List<PartExportResult> partitions)
            throws MigrationException {
        manifest.addArtifact(workspace.root(), artifact, merged.rowCount, merged.canonicalDigest());
        for (PartExportResult partition : partitions) {
            manifest.addPartitionStats(workspace.root(), artifact.path(), partition.partition,
                    partition.rowCount, partition.canonicalDigest());
        }
    }

    private Map<String, String> labelCompletionMetadata(PartExportResult merged,
                                                         List<PartExportResult> partitions) {
        Map<String, String> metadata = partitionCompletionMetadata(merged);
        metadata.put("layout", "label");
        for (PartExportResult partition : partitions) {
            String prefix = "partition." + partition.partition + ".";
            metadata.put(prefix + "row.count", String.valueOf(partition.rowCount));
            metadata.put(prefix + "canonical.digest", partition.canonicalDigest());
        }
        return metadata;
    }

    private Map<String, String> partitionCompletionMetadata(PartExportResult result) {
        Map<String, String> metadata = new LinkedHashMap<String, String>();
        metadata.put("row.count", String.valueOf(result.rowCount));
        metadata.put("canonical.digest", result.canonicalDigest());
        metadata.put("partition", String.valueOf(result.partition));
        return metadata;
    }

    private Map<String, String> completionMetadataOrNull(Path artifact, MigrationConfig config) {
        try {
            return Integrity.completionMetadata(artifact, config.hmacKey(), ExitCode.EXPORT_FAILED);
        } catch (MigrationException ignored) {
            return null;
        }
    }

    private PartExportResult recoverCompletedPartition(int partition, Path artifact,
                                                       Map<String, String> metadata)
            throws MigrationException {
        return new PartExportResult(partition, artifact,
                requiredLong(metadata, "row.count", artifact),
                required(metadata, "canonical.digest", artifact), true);
    }

    private long requiredLong(Map<String, String> metadata, String name, Path artifact)
            throws MigrationException {
        try {
            return Long.parseLong(required(metadata, name, artifact));
        } catch (NumberFormatException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED,
                    "Invalid signed artifact recovery metadata " + name + ": " + artifact, e);
        }
    }

    private String required(Map<String, String> metadata, String name, Path artifact)
            throws MigrationException {
        String value = metadata.get(name);
        if (value == null || value.isEmpty()) {
            throw new MigrationException(ExitCode.EXPORT_FAILED,
                    "Signed artifact lacks recovery metadata " + name + ": " + artifact);
        }
        return value;
    }

    private void deleteStagingFiles(List<PartExportResult> results) throws MigrationException {
        try {
            for (PartExportResult result : results) {
                Files.deleteIfExists(result.path);
            }
        } catch (IOException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot clean label staging files", e);
        }
    }

    private static final class PartExportTask implements Callable<PartExportResult> {
        private final StorageClient sharedStorage;
        private final EdgeScanClientPool edgeClients;
        private final MigrationConfig config;
        private final String space;
        private final MigrationRecord.Kind kind;
        private final String label;
        private final int partition;
        private final Path finalPath;

        private PartExportTask(StorageClient sharedStorage, EdgeScanClientPool edgeClients,
                               MigrationConfig config, String space, MigrationRecord.Kind kind,
                               String label, int partition, Path finalPath) {
            this.sharedStorage = sharedStorage;
            this.edgeClients = edgeClients;
            this.config = config;
            this.space = space;
            this.kind = kind;
            this.label = label;
            this.partition = partition;
            this.finalPath = finalPath;
        }

        @Override
        public PartExportResult call() throws MigrationException {
            Path temporary = finalPath.resolveSibling(finalPath.getFileName().toString() + ".tmp");
            CanonicalAccumulator accumulator = new CanonicalAccumulator();
            long count = 0L;
            StorageClient storage = null;
            try {
                storage = kind == MigrationRecord.Kind.EDGE ? edgeClients.borrow() : sharedStorage;
                Files.createDirectories(finalPath.getParent());
                try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                    if ("csv".equals(config.exportFormat())) {
                        writer.write(RecordCodec.CSV_HEADER);
                        writer.newLine();
                    }
                    if (kind == MigrationRecord.Kind.VERTEX) {
                        ScanVertexResultIterator iterator = storage.scanVertex(space, partition, label,
                                Collections.<String>emptyList(), config.scanLimit(), 0L, Long.MAX_VALUE,
                                false, false);
                        while (iterator.hasNext()) {
                            ScanVertexResult result = iterator.next();
                            if (!result.isAllSuccess()) {
                                throw new MigrationException(ExitCode.EXPORT_FAILED,
                                        "Storage scan vertex returned partial failure for " + space + "/" + label
                                                + "/" + partition);
                            }
                            for (VertexRow row : result.getVertices()) {
                                MigrationRecord record = MigrationRecord.vertex(TypedValue.from(row.getVid()),
                                        values(row.getProps()));
                                write(writer, config.exportFormat(), record);
                                accumulator.add(record.canonical(label));
                                count++;
                            }
                        }
                    } else {
                        ScanEdgeResultIterator iterator = storage.scanEdge(space, partition, label,
                                Collections.<String>emptyList(), config.scanLimit(), 0L, Long.MAX_VALUE,
                                false, false);
                        while (iterator.hasNext()) {
                            ScanEdgeResult result = iterator.next();
                            if (!result.isAllSuccess()) {
                                throw new MigrationException(ExitCode.EXPORT_FAILED,
                                        "Storage scan edge returned partial failure for " + space + "/" + label
                                                + "/" + partition);
                            }
                            for (EdgeRow row : result.getEdges()) {
                                MigrationRecord record = MigrationRecord.edge(TypedValue.from(row.getSrcId()),
                                        TypedValue.from(row.getDstId()), row.getRank(), values(row.getProps()));
                                write(writer, config.exportFormat(), record);
                                accumulator.add(record.canonical(label));
                                count++;
                            }
                        }
                    }
                }
                AtomicFiles.force(temporary);
                AtomicFiles.move(temporary, finalPath);
                return new PartExportResult(partition, finalPath, count, accumulator, false);
            } catch (MigrationException e) {
                throw e;
            } catch (Exception e) {
                throw new MigrationException(ExitCode.EXPORT_FAILED,
                        "Cannot export " + space + "/" + kind.pathName() + "/" + label + "/" + partition, e);
            } finally {
                if (kind == MigrationRecord.Kind.EDGE && storage != null) {
                    edgeClients.release(storage);
                }
            }
        }

        private static Map<String, TypedValue> values(Map<String, com.vesoft.nebula.client.graph.data.ValueWrapper> raw)
                throws MigrationException {
            Map<String, TypedValue> values = new LinkedHashMap<String, TypedValue>();
            for (Map.Entry<String, com.vesoft.nebula.client.graph.data.ValueWrapper> entry : raw.entrySet()) {
                values.put(entry.getKey(), TypedValue.from(entry.getValue()));
            }
            return values;
        }

        private static void write(BufferedWriter writer, String format, MigrationRecord record)
                throws IOException {
            writer.write("csv".equals(format) ? RecordCodec.toCsv(record) : RecordCodec.toJson(record));
            writer.newLine();
        }
    }

    /**
     * Gives each in-flight edge partition its own StorageClient. nebula-java 3.8's edge iterator
     * mutates its connection pool while paging, so sharing one client across edge iterators can
     * corrupt a Thrift stream under partition concurrency.
     */
    private static final class EdgeScanClientPool implements AutoCloseable {
        private final BlockingQueue<StorageClient> available;
        private final List<StorageClient> clients = new ArrayList<StorageClient>();

        private EdgeScanClientPool(ClusterClient source, int capacity) throws MigrationException {
            available = new ArrayBlockingQueue<StorageClient>(capacity, true);
            try {
                for (int index = 0; index < capacity; index++) {
                    StorageClient client = source.openDedicatedStorageClient();
                    clients.add(client);
                    available.add(client);
                }
            } catch (MigrationException e) {
                close();
                throw e;
            }
        }

        private StorageClient borrow() throws MigrationException {
            try {
                return available.take();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new MigrationException(ExitCode.EXPORT_FAILED,
                        "Interrupted while acquiring edge scan client", e);
            }
        }

        private void release(StorageClient client) {
            if (!available.offer(client)) {
                throw new IllegalStateException("Edge scan client was released more than once");
            }
        }

        @Override
        public void close() {
            for (StorageClient client : clients) {
                try {
                    client.close();
                } catch (Exception ignored) {
                    // Cleanup must not hide the export failure that triggered it.
                }
            }
            clients.clear();
            available.clear();
        }
    }

    private static final class PartExportResult {
        private final int partition;
        private final Path path;
        private final long rowCount;
        private final CanonicalAccumulator accumulator;
        private final String recoveredCanonicalDigest;
        private final boolean alreadyCompleted;

        private PartExportResult(int partition, Path path, long rowCount,
                                 CanonicalAccumulator accumulator, boolean alreadyCompleted) {
            this.partition = partition;
            this.path = path;
            this.rowCount = rowCount;
            this.accumulator = accumulator;
            this.recoveredCanonicalDigest = null;
            this.alreadyCompleted = alreadyCompleted;
        }

        private PartExportResult(int partition, Path path, long rowCount,
                                 String canonicalDigest, boolean alreadyCompleted) {
            this.partition = partition;
            this.path = path;
            this.rowCount = rowCount;
            this.accumulator = null;
            this.recoveredCanonicalDigest = canonicalDigest;
            this.alreadyCompleted = alreadyCompleted;
        }

        private String canonicalDigest() {
            return accumulator == null ? recoveredCanonicalDigest : accumulator.digest();
        }
    }

    private static final class CompletedFuture implements Future<PartExportResult> {
        private final PartExportResult result;

        private CompletedFuture(PartExportResult result) {
            this.result = result;
        }

        @Override public boolean cancel(boolean mayInterruptIfRunning) { return false; }
        @Override public boolean isCancelled() { return false; }
        @Override public boolean isDone() { return true; }
        @Override public PartExportResult get() { return result; }
        @Override public PartExportResult get(long timeout, java.util.concurrent.TimeUnit unit) { return result; }
    }
}
