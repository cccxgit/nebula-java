package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.NebulaPoolConfig;
import com.vesoft.nebula.client.graph.data.HostAddress;
import com.vesoft.nebula.client.graph.data.ResultSet;
import com.vesoft.nebula.client.graph.data.ValueWrapper;
import com.vesoft.nebula.client.graph.net.NebulaPool;
import com.vesoft.nebula.client.graph.net.Session;
import com.vesoft.nebula.client.storage.StorageClient;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.apache.log4j.Logger;

public final class ClusterClient implements AutoCloseable {
    private static final Logger LOG = Logger.getLogger(ClusterClient.class);

    private final MigrationConfig.Cluster config;
    private NebulaPool graphPool;
    private StorageClient storageClient;

    public ClusterClient(MigrationConfig.Cluster config) {
        this.config = config;
    }

    public void connect() throws MigrationException {
        try {
            graphPool = new NebulaPool();
            NebulaPoolConfig poolConfig = new NebulaPoolConfig();
            poolConfig.setMinConnSize(0);
            poolConfig.setMaxConnSize(16);
            if (!graphPool.init(config.graphAddresses(), poolConfig)) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED, "Cannot initialize graph pool");
            }
            storageClient = new StorageClient(config.metaAddresses());
            storageClient.setUser(config.user()).setPassword(config.password());
            storageClient.connect();
        } catch (MigrationException e) {
            closeQuietly();
            throw e;
        } catch (Exception e) {
            closeQuietly();
            throw new MigrationException(ExitCode.PRECHECK_FAILED, "Cannot connect Nebula cluster", e);
        }
    }

    public Session openSession() throws MigrationException {
        try {
            Session session = graphPool.getSession(config.user(), config.password(), true);
            if (session == null) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED, "Graph authentication returned no session");
            }
            return session;
        } catch (MigrationException e) {
            throw e;
        } catch (Exception e) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED, "Cannot open graph session", e);
        }
    }

    public ResultSet execute(Session session, String ngql, ExitCode failureCode) throws MigrationException {
        try {
            ResultSet result = session.execute(ngql);
            if (!result.isSucceeded()) {
                throw new MigrationException(failureCode, "nGQL failed [" + result.getErrorCode() + "]: "
                        + result.getErrorMessage() + ", statement=" + ngql);
            }
            return result;
        } catch (MigrationException e) {
            throw e;
        } catch (Exception e) {
            throw new MigrationException(failureCode, "nGQL execution failed: " + ngql, e);
        }
    }

    public ResultSet execute(String ngql, ExitCode failureCode) throws MigrationException {
        Session session = openSession();
        try {
            return execute(session, ngql, failureCode);
        } finally {
            session.release();
        }
    }

    public StorageClient storage() throws MigrationException {
        if (storageClient == null) {
            throw new MigrationException(ExitCode.INTERNAL_ERROR, "StorageClient is not connected");
        }
        return storageClient;
    }

    public StorageClient openDedicatedStorageClient() throws MigrationException {
        StorageClient client = null;
        try {
            client = new StorageClient(config.metaAddresses());
            client.setUser(config.user()).setPassword(config.password());
            client.connect();
            return client;
        } catch (Exception e) {
            if (client != null) {
                try {
                    client.close();
                } catch (Exception closeError) {
                    LOG.warn("Cannot close dedicated StorageClient after connect failure", closeError);
                }
            }
            throw new MigrationException(ExitCode.EXPORT_FAILED,
                    "Cannot initialize dedicated StorageClient for partition scan", e);
        }
    }

    public List<HostAddress> graphAddresses() {
        return config.graphAddresses();
    }

    /**
     * Runs a space-scoped statement against one specified graphd. Metadata DDL is accepted by
     * meta before every graphd has refreshed its cache, so readiness checks must not rely on a
     * load-balanced pool session.
     */
    public ResultSet executeInSpaceOnGraph(HostAddress graphAddress, String space, String ngql,
                                           ExitCode failureCode) throws MigrationException {
        NebulaPool directPool = null;
        Session session = null;
        try {
            directPool = new NebulaPool();
            NebulaPoolConfig poolConfig = new NebulaPoolConfig();
            poolConfig.setMinConnSize(0);
            poolConfig.setMaxConnSize(1);
            if (!directPool.init(Collections.singletonList(graphAddress), poolConfig)) {
                throw new MigrationException(failureCode,
                        "Cannot initialize graph connection for " + graphAddress);
            }
            session = directPool.getSession(config.user(), config.password(), true);
            if (session == null) {
                throw new MigrationException(failureCode,
                        "Graph authentication returned no session for " + graphAddress);
            }
            execute(session, "USE " + identifier(space), failureCode);
            return execute(session, ngql, failureCode);
        } catch (MigrationException e) {
            throw e;
        } catch (Exception e) {
            throw new MigrationException(failureCode,
                    "Cannot execute against graphd " + graphAddress, e);
        } finally {
            if (session != null) {
                try {
                    session.release();
                } catch (Exception e) {
                    LOG.warn("Cannot release direct graph session", e);
                }
            }
            if (directPool != null) {
                try {
                    directPool.close();
                } catch (Exception e) {
                    LOG.warn("Cannot close direct graph pool", e);
                }
            }
        }
    }

    public List<String> stringColumn(ResultSet result, int column) throws MigrationException {
        List<String> values = new ArrayList<String>();
        for (int row = 0; row < result.rowsSize(); row++) {
            values.add(valueAsString(result.rowValues(row).get(column)));
        }
        return values;
    }

    public static String valueAsString(ValueWrapper value) throws MigrationException {
        try {
            if (value.isString()) {
                return value.asString();
            }
            if (value.isLong()) {
                return String.valueOf(value.asLong());
            }
            if (value.isBoolean()) {
                return String.valueOf(value.asBoolean());
            }
            if (value.isDouble()) {
                return String.valueOf(value.asDouble());
            }
            return value.toString();
        } catch (UnsupportedEncodingException e) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED, "Cannot decode graph result", e);
        }
    }

    public static String identifier(String value) {
        return "`" + value.replace("`", "``") + "`";
    }

    public static String stringLiteral(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    @Override
    public void close() {
        closeQuietly();
    }

    private void closeQuietly() {
        if (storageClient != null) {
            try {
                storageClient.close();
            } catch (Exception e) {
                LOG.warn("Cannot close StorageClient", e);
            }
            storageClient = null;
        }
        if (graphPool != null) {
            try {
                graphPool.close();
            } catch (Exception e) {
                LOG.warn("Cannot close NebulaPool", e);
            }
            graphPool = null;
        }
    }
}
