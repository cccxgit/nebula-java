package com.vesoft.nebula.migration;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

// Order-independent 256-bit XOR and modular sum make checksum comparison stable across scan page
// scheduling while retaining a bounded memory footprint.
public final class CanonicalAccumulator {
    private static final BigInteger MODULUS = BigInteger.ONE.shiftLeft(256);
    private final byte[] xor = new byte[32];
    private BigInteger sum = BigInteger.ZERO;
    private long count;

    public void add(String canonical) {
        byte[] digest;
        try {
            digest = MessageDigest.getInstance("SHA-256")
                    .digest(canonical.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
        for (int index = 0; index < xor.length; index++) {
            xor[index] ^= digest[index];
        }
        sum = sum.add(new BigInteger(1, digest)).mod(MODULUS);
        count++;
    }

    public void merge(CanonicalAccumulator other) {
        for (int index = 0; index < xor.length; index++) {
            xor[index] ^= other.xor[index];
        }
        sum = sum.add(other.sum).mod(MODULUS);
        count += other.count;
    }

    public long count() {
        return count;
    }

    public String digest() {
        String sumHex = sum.toString(16);
        StringBuilder padded = new StringBuilder(64);
        for (int index = sumHex.length(); index < 64; index++) {
            padded.append('0');
        }
        padded.append(sumHex);
        return Integrity.hex(Arrays.copyOf(xor, xor.length)) + ":" + padded;
    }
}
