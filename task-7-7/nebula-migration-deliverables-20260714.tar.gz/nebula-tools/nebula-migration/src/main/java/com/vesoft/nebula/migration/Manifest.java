package com.vesoft.nebula.migration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public final class Manifest {
    public enum State { NEW, PRECHECKED, EXPORTING, EXPORTED, IMPORTING, IMPORTED, VERIFYING,
        VERIFIED, FAILED }

    private final Path path;
    private final Properties values;

    private Manifest(Path path, Properties values) {
        this.path = path;
        this.values = values;
    }

    public static Manifest load(Workspace workspace) throws MigrationException {
        Properties values = new Properties();
        Path path = workspace.manifestPath();
        if (Files.exists(path)) {
            try (java.io.InputStream input = Files.newInputStream(path)) {
                values.load(input);
            } catch (IOException e) {
                throw new MigrationException(ExitCode.INTERNAL_ERROR, "Cannot read manifest", e);
            }
        } else {
            values.setProperty("manifest.version", "1");
            values.setProperty("job.id", "migration-" + Instant.now().toEpochMilli());
            values.setProperty("state", State.NEW.name());
            values.setProperty("file.count", "0");
        }
        return new Manifest(path, values);
    }

    public synchronized void setState(State state) throws MigrationException {
        values.setProperty("state", state.name());
        values.setProperty("updated.at", Instant.now().toString());
        save();
    }

    public synchronized State state() {
        return State.valueOf(values.getProperty("state", State.NEW.name()));
    }

    public synchronized String jobId() {
        return values.getProperty("job.id");
    }

    public synchronized void initialize(MigrationConfig config) throws MigrationException {
        values.setProperty("tool.version", "0.1.0");
        values.setProperty("nebula.java.version", "3.8.4");
        values.setProperty("source.version", MigrationConfig.EXPECTED_SERVER_VERSION);
        values.setProperty("target.version", MigrationConfig.EXPECTED_SERVER_VERSION);
        values.setProperty("format", config.exportFormat());
        values.setProperty("layout", config.exportLayout());
        values.setProperty("full.checksum.enabled", String.valueOf(config.fullChecksumEnabled()));
        values.setProperty("created.at", values.getProperty("created.at", Instant.now().toString()));
        save();
    }

    public synchronized void setMetadata(Path workspace, Path metadata) throws MigrationException {
        values.setProperty("metadata.path", workspace.relativize(metadata).toString());
        try {
            values.setProperty("metadata.sha256", Integrity.sha256(metadata));
        } catch (Exception e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot hash metadata", e);
        }
        save();
    }

    public synchronized void setTtlDetected(boolean ttlDetected) throws MigrationException {
        values.setProperty("ttl.detected", String.valueOf(ttlDetected));
        save();
    }

    public synchronized void setMetadataAudit(boolean rootPresent, int sourceUsers,
                                              int migratedUsers, int migratedSpaceRoles)
            throws MigrationException {
        values.setProperty("metadata.audit.root.user", rootPresent ? "root" : "NOT_FOUND");
        values.setProperty("metadata.audit.root.action", "AUDIT_ONLY_NOT_IMPORTED");
        values.setProperty("metadata.audit.source.user.count", String.valueOf(sourceUsers));
        values.setProperty("metadata.audit.migrated.user.count", String.valueOf(migratedUsers));
        values.setProperty("metadata.audit.migrated.space.role.count",
                String.valueOf(migratedSpaceRoles));
        values.setProperty("metadata.audit.permission.scope", "NON_ROOT_SPACE_ROLE_ONLY");
        values.setProperty("metadata.audit.extended.privileges",
                "WARNING_NOT_EXPORTED_UNSUPPORTED_EXTENSION_PRIVILEGES");
        values.setProperty("metadata.audit.excluded.objects",
                "job history,fulltext indexes,configurations,snapshots,logs");
        save();
    }

    public synchronized String metadataAudit(String field, String defaultValue) {
        return values.getProperty("metadata.audit." + field, defaultValue);
    }

    public synchronized boolean ttlDetected() {
        return Boolean.parseBoolean(values.getProperty("ttl.detected", "false"));
    }

    public synchronized boolean metadataImported() {
        return Boolean.parseBoolean(values.getProperty("metadata.imported", "false"));
    }

    public synchronized void setMetadataImported() throws MigrationException {
        values.setProperty("metadata.imported", "true");
        save();
    }

    public synchronized void addArtifact(Path workspace, ArtifactDescriptor descriptor, long rowCount,
                                         String canonicalDigest) throws MigrationException {
        List<ArtifactDescriptor> existing = artifacts(workspace);
        for (ArtifactDescriptor artifact : existing) {
            if (artifact.path().equals(descriptor.path())) {
                return;
            }
        }
        // file.count is a monotonic allocation cursor. Recovery can leave a sparse index when a
        // process dies after signing one artifact but before its manifest entry is saved; never
        // reuse a hole and overwrite an unrelated completed artifact.
        int index = Integer.parseInt(values.getProperty("file.count", "0"));
        String prefix = "file." + index + ".";
        values.setProperty(prefix + "path", workspace.relativize(descriptor.path()).toString());
        values.setProperty(prefix + "space", descriptor.space());
        values.setProperty(prefix + "kind", descriptor.kind().name());
        values.setProperty(prefix + "label", descriptor.label());
        values.setProperty(prefix + "partition", descriptor.partition() == null ? "" :
                String.valueOf(descriptor.partition()));
        values.setProperty(prefix + "format", descriptor.format());
        values.setProperty(prefix + "row.count", String.valueOf(rowCount));
        values.setProperty(prefix + "sha256", safeSha(descriptor.path()));
        values.setProperty(prefix + "canonical.digest", canonicalDigest == null ? "" : canonicalDigest);
        values.setProperty("file.count", String.valueOf(index + 1));
        save();
    }

    public synchronized List<ArtifactDescriptor> artifacts(Path workspace) throws MigrationException {
        List<ArtifactDescriptor> result = new ArrayList<ArtifactDescriptor>();
        int count = Integer.parseInt(values.getProperty("file.count", "0"));
        for (int index = 0; index < count; index++) {
            String prefix = "file." + index + ".";
            String relative = values.getProperty(prefix + "path");
            if (relative == null) {
                continue;
            }
            String partition = values.getProperty(prefix + "partition", "");
            result.add(new ArtifactDescriptor(workspace.resolve(relative),
                    values.getProperty(prefix + "space"),
                    MigrationRecord.Kind.valueOf(values.getProperty(prefix + "kind")),
                    values.getProperty(prefix + "label"),
                    partition.isEmpty() ? null : Integer.valueOf(partition),
                    values.getProperty(prefix + "format")));
        }
        return result;
    }

    public synchronized boolean hasArtifact(Path workspace, Path artifact) {
        String expected = workspace.relativize(artifact).toString();
        int count = Integer.parseInt(values.getProperty("file.count", "0"));
        for (int index = 0; index < count; index++) {
            if (expected.equals(values.getProperty("file." + index + ".path"))) {
                return true;
            }
        }
        return false;
    }

    public synchronized boolean hasPartitionStats(Path workspace, Path artifact, int partition)
            throws MigrationException {
        String prefix = prefixFor(workspace, artifact);
        return values.containsKey(prefix + "partition." + partition + ".row.count")
                && values.containsKey(prefix + "partition." + partition + ".canonical.digest");
    }

    public synchronized long rowCount(ArtifactDescriptor descriptor, Path workspace)
            throws MigrationException {
        int count = Integer.parseInt(values.getProperty("file.count", "0"));
        String expected = workspace.relativize(descriptor.path()).toString();
        for (int index = 0; index < count; index++) {
            String prefix = "file." + index + ".";
            if (expected.equals(values.getProperty(prefix + "path"))) {
                return Long.parseLong(values.getProperty(prefix + "row.count", "0"));
            }
        }
        throw new MigrationException(ExitCode.INTERNAL_ERROR, "Artifact missing from manifest: " + expected);
    }

    public synchronized String canonicalDigest(ArtifactDescriptor descriptor, Path workspace)
            throws MigrationException {
        int count = Integer.parseInt(values.getProperty("file.count", "0"));
        String expected = workspace.relativize(descriptor.path()).toString();
        for (int index = 0; index < count; index++) {
            String prefix = "file." + index + ".";
            if (expected.equals(values.getProperty(prefix + "path"))) {
                return values.getProperty(prefix + "canonical.digest", "");
            }
        }
        throw new MigrationException(ExitCode.INTERNAL_ERROR, "Artifact missing from manifest: " + expected);
    }

    public synchronized void addPartitionStats(Path workspace, Path artifact, int partition,
                                               long rowCount, String canonicalDigest)
            throws MigrationException {
        String expected = workspace.relativize(artifact).toString();
        int count = Integer.parseInt(values.getProperty("file.count", "0"));
        for (int index = 0; index < count; index++) {
            String prefix = "file." + index + ".";
            if (expected.equals(values.getProperty(prefix + "path"))) {
                values.setProperty(prefix + "partition." + partition + ".row.count",
                        String.valueOf(rowCount));
                values.setProperty(prefix + "partition." + partition + ".canonical.digest",
                        canonicalDigest);
                save();
                return;
            }
        }
        throw new MigrationException(ExitCode.INTERNAL_ERROR, "Artifact missing from manifest: " + expected);
    }

    public synchronized long partitionRowCount(Path workspace, Path artifact, int partition)
            throws MigrationException {
        String prefix = prefixFor(workspace, artifact);
        return Long.parseLong(values.getProperty(prefix + "partition." + partition + ".row.count", "-1"));
    }

    public synchronized String partitionCanonicalDigest(Path workspace, Path artifact, int partition)
            throws MigrationException {
        String prefix = prefixFor(workspace, artifact);
        return values.getProperty(prefix + "partition." + partition + ".canonical.digest", "");
    }

    public synchronized Path metadataPath(Path workspace) throws MigrationException {
        String metadata = values.getProperty("metadata.path");
        if (metadata == null) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Manifest has no metadata artifact");
        }
        return workspace.resolve(metadata);
    }

    private String safeSha(Path path) throws MigrationException {
        try {
            return Integrity.sha256(path);
        } catch (Exception e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot hash artifact " + path, e);
        }
    }

    private String prefixFor(Path workspace, Path artifact) throws MigrationException {
        String expected = workspace.relativize(artifact).toString();
        int count = Integer.parseInt(values.getProperty("file.count", "0"));
        for (int index = 0; index < count; index++) {
            String prefix = "file." + index + ".";
            if (expected.equals(values.getProperty(prefix + "path"))) {
                return prefix;
            }
        }
        throw new MigrationException(ExitCode.INTERNAL_ERROR, "Artifact missing from manifest: " + expected);
    }

    private void save() throws MigrationException {
        try {
            if (Files.exists(path)) {
                Files.copy(path, path.resolveSibling(path.getFileName().toString() + ".bak"),
                        StandardCopyOption.REPLACE_EXISTING);
            }
            AtomicFiles.storeProperties(path, values, "Nebula Graph migration manifest");
        } catch (IOException e) {
            throw new MigrationException(ExitCode.INTERNAL_ERROR, "Cannot save manifest", e);
        }
    }
}
