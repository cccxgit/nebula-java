package com.vesoft.nebula.migration;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public final class MigrationRecord {
    public enum Kind { VERTEX("vertex"), EDGE("edge");

        private final String pathName;

        Kind(String pathName) {
            this.pathName = pathName;
        }

        public String pathName() {
            return pathName;
        }
    }

    private final Kind kind;
    private final TypedValue firstKey;
    private final TypedValue secondKey;
    private final long rank;
    private final Map<String, TypedValue> properties;

    private MigrationRecord(Kind kind, TypedValue firstKey, TypedValue secondKey, long rank,
                            Map<String, TypedValue> properties) {
        this.kind = kind;
        this.firstKey = firstKey;
        this.secondKey = secondKey;
        this.rank = rank;
        this.properties = Collections.unmodifiableMap(new LinkedHashMap<String, TypedValue>(
                new TreeMap<String, TypedValue>(properties)));
    }

    public static MigrationRecord vertex(TypedValue vid, Map<String, TypedValue> properties) {
        return new MigrationRecord(Kind.VERTEX, vid, null, 0L, properties);
    }

    public static MigrationRecord edge(TypedValue src, TypedValue dst, long rank,
                                       Map<String, TypedValue> properties) {
        return new MigrationRecord(Kind.EDGE, src, dst, rank, properties);
    }

    public Kind kind() {
        return kind;
    }

    public TypedValue firstKey() {
        return firstKey;
    }

    public TypedValue secondKey() {
        return secondKey;
    }

    public long rank() {
        return rank;
    }

    public Map<String, TypedValue> properties() {
        return properties;
    }

    public String canonical(String label) {
        StringBuilder builder = new StringBuilder();
        builder.append(kind.name()).append('|').append(label).append('|').append(firstKey.encode());
        if (secondKey != null) {
            builder.append('|').append(secondKey.encode()).append('|').append(rank);
        }
        for (Map.Entry<String, TypedValue> property : properties.entrySet()) {
            builder.append('|').append(property.getKey()).append('=').append(property.getValue().encode());
        }
        return builder.toString();
    }

    public String canonicalHash(String label) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256")
                    .digest(canonical(label).getBytes(StandardCharsets.UTF_8));
            return Integrity.hex(bytes);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
