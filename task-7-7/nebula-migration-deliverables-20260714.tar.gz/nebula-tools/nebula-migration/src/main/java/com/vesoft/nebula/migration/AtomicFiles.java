package com.vesoft.nebula.migration;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Properties;

public final class AtomicFiles {
    private AtomicFiles() {
    }

    public static void writeUtf8(Path destination, String value) throws IOException {
        Path tmp = destination.resolveSibling(destination.getFileName().toString() + ".tmp");
        Files.createDirectories(destination.getParent());
        try (OutputStream output = Files.newOutputStream(tmp)) {
            output.write(value.getBytes(StandardCharsets.UTF_8));
            output.flush();
        }
        force(tmp);
        move(tmp, destination);
    }

    public static void storeProperties(Path destination, Properties properties, String comment)
            throws IOException {
        Path tmp = destination.resolveSibling(destination.getFileName().toString() + ".tmp");
        Files.createDirectories(destination.getParent());
        try (OutputStream output = Files.newOutputStream(tmp)) {
            properties.store(output, comment);
            output.flush();
        }
        force(tmp);
        move(tmp, destination);
    }

    public static void force(Path path) throws IOException {
        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.WRITE)) {
            channel.force(true);
        }
    }

    public static void move(Path source, Path destination) throws IOException {
        try {
            Files.move(source, destination, StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(source, destination, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
