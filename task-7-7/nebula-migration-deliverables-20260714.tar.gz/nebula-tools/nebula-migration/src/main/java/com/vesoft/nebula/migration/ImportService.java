package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.net.Session;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.apache.log4j.Logger;

public final class ImportService {
    private static final Logger LOG = Logger.getLogger(ImportService.class);
    private final MetadataService metadataService = new MetadataService();

    public void importAll(ClusterClient target, Workspace workspace, Manifest manifest,
                          MigrationConfig config) throws MigrationException {
        verifyImportArtifacts(workspace, manifest, config);
        Manifest.State previousState = manifest.state();
        if (!manifest.metadataImported()) {
            ClusterInspector.precheckTarget(target, config);
        } else if (previousState != Manifest.State.IMPORTING && previousState != Manifest.State.FAILED) {
            throw new MigrationException(ExitCode.IMPORT_FAILED,
                    "Target is not empty but metadata import was not in a resumable state");
        }
        manifest.setState(Manifest.State.IMPORTING);
        if (!manifest.metadataImported()) {
            try {
                metadataService.importMetadata(target, workspace, manifest, config);
                manifest.setMetadataImported();
            } catch (MigrationException e) {
                manifest.setState(Manifest.State.FAILED);
                throw e;
            }
        }
        CheckpointStore checkpoints = new CheckpointStore(workspace, config.checkpointFlushBatchInterval());
        FailureRecorder failures = new FailureRecorder(workspace);
        if (failures.hasUnresolved()) {
            manifest.setState(Manifest.State.FAILED);
            throw new MigrationException(ExitCode.IMPORT_FAILED,
                    "Unresolved import failure records exist. Run retry-failed before resuming import: "
                            + failures.path());
        }
        boolean hasFailure = importArtifacts(target, manifest.artifacts(workspace.root()), checkpoints,
                failures, config);
        if (hasFailure) {
            manifest.setState(Manifest.State.FAILED);
            throw new MigrationException(ExitCode.IMPORT_FAILED,
                    "Import has final failed records. See " + failures.path());
        }
        manifest.setState(Manifest.State.IMPORTED);
    }

    private boolean importArtifacts(ClusterClient target, List<ArtifactDescriptor> artifacts,
                                    CheckpointStore checkpoints, FailureRecorder failures,
                                    MigrationConfig config) throws MigrationException {
        ExecutorService workers = Executors.newFixedThreadPool(config.importArtifactConcurrency());
        List<Future<Boolean>> futures = new ArrayList<Future<Boolean>>();
        try {
            for (final ArtifactDescriptor artifact : artifacts) {
                futures.add(workers.submit(new Callable<Boolean>() {
                    @Override
                    public Boolean call() throws Exception {
                        return importArtifact(target, artifact, checkpoints, failures, config);
                    }
                }));
            }
            boolean hasFailure = false;
            for (Future<Boolean> future : futures) {
                try {
                    hasFailure |= !future.get();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new MigrationException(ExitCode.IMPORT_FAILED,
                            "Artifact import interrupted", e);
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof MigrationException) {
                        throw (MigrationException) cause;
                    }
                    throw new MigrationException(ExitCode.IMPORT_FAILED,
                            "Artifact import failed", cause);
                }
            }
            return hasFailure;
        } finally {
            for (Future<Boolean> future : futures) {
                future.cancel(true);
            }
            workers.shutdownNow();
            checkpoints.flush();
        }
    }

    private void verifyImportArtifacts(Workspace workspace, Manifest manifest,
                                       MigrationConfig config) throws MigrationException {
        Integrity.verifyCompleted(manifest.metadataPath(workspace.root()), config.hmacKey(),
                ExitCode.IMPORT_FAILED);
        for (ArtifactDescriptor artifact : manifest.artifacts(workspace.root())) {
            Integrity.verifyCompleted(artifact.path(), config.hmacKey(), ExitCode.IMPORT_FAILED);
        }
    }

    private boolean importArtifact(ClusterClient target, ArtifactDescriptor artifact,
                                   CheckpointStore checkpoints, FailureRecorder failures,
                                   MigrationConfig config) throws MigrationException {
        long completed = checkpoints.importedRows(artifact.path());
        boolean success = true;
        Session session = target.openSession();
        try (DataFileReader reader = new DataFileReader(artifact.path(), artifact.format())) {
            // Each pool session begins without a selected graph space.
            executeWithRetry(target, session, "USE " + ClusterClient.identifier(artifact.space()), config);
            List<DataFileReader.Entry> batch = new ArrayList<DataFileReader.Entry>();
            DataFileReader.Entry entry;
            while ((entry = reader.next()) != null) {
                if (entry.rowNumber() <= completed) {
                    continue;
                }
                batch.add(entry);
                if (batch.size() >= config.importBatchSize()) {
                    success &= executeBatch(target, session, artifact, batch, checkpoints, failures, config);
                    batch.clear();
                }
            }
            if (!batch.isEmpty()) {
                success &= executeBatch(target, session, artifact, batch, checkpoints, failures, config);
            }
        } finally {
            try {
                session.release();
            } finally {
                checkpoints.flush();
            }
        }
        return success;
    }

    private boolean executeBatch(ClusterClient target, Session session, ArtifactDescriptor artifact,
                                 List<DataFileReader.Entry> batch, CheckpointStore checkpoints,
                                 FailureRecorder failures, MigrationConfig config) throws MigrationException {
        List<MigrationRecord> records = new ArrayList<MigrationRecord>();
        for (DataFileReader.Entry entry : batch) {
            records.add(entry.record());
        }
        try {
            executeWithRetry(target, session, NgqlRenderer.renderBatch(artifact, records), config);
            checkpoints.markImported(artifact.path(), batch.get(batch.size() - 1).rowNumber());
            return true;
        } catch (MigrationException batchFailure) {
            LOG.warn("Batch import failed; retrying individual rows for " + artifact.path(), batchFailure);
            boolean success = true;
            for (DataFileReader.Entry entry : batch) {
                String ngql = NgqlRenderer.render(artifact, entry.record());
                try {
                    executeWithRetry(target, session, ngql, config);
                    checkpoints.markImportedIfNext(artifact.path(), entry.rowNumber());
                } catch (MigrationException rowFailure) {
                    failures.record(artifact, entry.rowNumber(), entry.raw(), ngql,
                            rowFailure.getMessage(), config.importRetryTimes() + 1);
                    success = false;
                }
            }
            return success;
        }
    }

    public void retryFailed(ClusterClient target, Workspace workspace, Manifest manifest,
                            MigrationConfig config) throws MigrationException {
        Instant startedAt = Instant.now();
        Path file = workspace.failures().resolve("import-failures.jsonl");
        if (!Files.exists(file)) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "No failure record file: " + file);
        }
        int retried = 0;
        int failed = 0;
        List<String> unresolved = new ArrayList<String>();
        Set<Path> resolvedArtifacts = new LinkedHashSet<Path>();
        Set<Path> unresolvedArtifacts = new LinkedHashSet<Path>();
        CheckpointStore checkpoints = new CheckpointStore(workspace, config.checkpointFlushBatchInterval());
        Session session = target.openSession();
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                String ngql = jsonField(line, "ngql");
                Path artifact = failureArtifact(jsonField(line, "artifact"));
                String space = optionalJsonField(line, "space");
                if (space == null || space.trim().isEmpty()) {
                    space = spaceFromManifest(manifest, workspace, artifact);
                }
                try {
                    executeWithRetry(target, session, "USE " + ClusterClient.identifier(space), config);
                    executeWithRetry(target, session, ngql, config);
                    resolvedArtifacts.add(artifact);
                    appendRetryHistory(workspace, line, "RESOLVED", "");
                    retried++;
                } catch (MigrationException e) {
                    failed++;
                    unresolved.add(line);
                    unresolvedArtifacts.add(artifact);
                    appendRetryHistory(workspace, line, "RETRY_FAILED", e.getMessage());
                }
            }
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot read failure records", e);
        } finally {
            session.release();
        }
        rewriteFailureQueue(file, unresolved);
        // A terminal import failure has already read every row in its artifact. Once every failed
        // row for that artifact succeeds, the whole artifact can safely become checkpointed. For
        // interrupted imports we keep the prefix checkpoint and let a later import replay rows.
        if (failed == 0 && manifest.state() == Manifest.State.FAILED) {
            for (Path artifact : resolvedArtifacts) {
                if (!unresolvedArtifacts.contains(artifact)) {
                    ArtifactDescriptor descriptor = descriptorFromManifest(manifest, workspace, artifact);
                    checkpoints.markImported(artifact,
                            manifest.rowCount(descriptor, workspace.root()));
                }
            }
        }
        checkpoints.flush();
        java.util.Map<String, String> report = new java.util.LinkedHashMap<String, String>();
        report.put("retried", String.valueOf(retried));
        report.put("failed", String.valueOf(failed));
        report.put("remaining", String.valueOf(unresolved.size()));
        addOperationAudit(report, manifest, startedAt);
        if (failed == 0 && manifest.metadataImported()
                && allArtifactsImported(manifest, workspace, checkpoints)) {
            manifest.setState(Manifest.State.IMPORTED);
            report.put("manifestState", Manifest.State.IMPORTED.name());
        } else {
            report.put("manifestState", manifest.state().name());
        }
        ReportWriter.write(workspace, "retry-report", report);
        if (failed > 0) {
            throw new MigrationException(ExitCode.IMPORT_FAILED,
                    "retry-failed still has " + failed + " failed records");
        }
    }

    private Path failureArtifact(String raw) throws MigrationException {
        try {
            return Paths.get(raw).toAbsolutePath().normalize();
        } catch (Exception e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Malformed failure artifact path", e);
        }
    }

    private String spaceFromManifest(Manifest manifest, Workspace workspace, Path artifact)
            throws MigrationException {
        return descriptorFromManifest(manifest, workspace, artifact).space();
    }

    private ArtifactDescriptor descriptorFromManifest(Manifest manifest, Workspace workspace, Path artifact)
            throws MigrationException {
        for (ArtifactDescriptor descriptor : manifest.artifacts(workspace.root())) {
            if (descriptor.path().toAbsolutePath().normalize().equals(artifact)) {
                return descriptor;
            }
        }
        throw new MigrationException(ExitCode.IMPORT_FAILED,
                "Failure record has no space and artifact is absent from manifest: " + artifact);
    }

    private boolean allArtifactsImported(Manifest manifest, Workspace workspace,
                                         CheckpointStore checkpoints) throws MigrationException {
        for (ArtifactDescriptor artifact : manifest.artifacts(workspace.root())) {
            if (checkpoints.importedRows(artifact.path())
                    < manifest.rowCount(artifact, workspace.root())) {
                return false;
            }
        }
        return true;
    }

    private void rewriteFailureQueue(Path file, List<String> unresolved) throws MigrationException {
        StringBuilder content = new StringBuilder();
        for (String line : unresolved) {
            content.append(line).append('\n');
        }
        try {
            AtomicFiles.writeUtf8(file, content.toString());
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot rewrite failure queue", e);
        }
    }

    private void appendRetryHistory(Workspace workspace, String record, String outcome, String error)
            throws MigrationException {
        String history = "{\"timestamp\":" + MiniJson.quote(Instant.now().toString())
                + ",\"outcome\":" + MiniJson.quote(outcome)
                + ",\"error\":" + MiniJson.quote(error)
                + ",\"record\":" + MiniJson.quote(record) + "}\n";
        try {
            Files.write(workspace.failures().resolve("import-retry-history.jsonl"),
                    history.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot write retry history", e);
        }
    }

    private void addOperationAudit(java.util.Map<String, String> report, Manifest manifest,
                                   Instant startedAt) {
        Instant endedAt = Instant.now();
        report.put("jobId", manifest.jobId());
        report.put("startedAt", startedAt.toString());
        report.put("endedAt", endedAt.toString());
        report.put("durationMs", String.valueOf(java.time.Duration.between(startedAt, endedAt).toMillis()));
    }

    private void executeWithRetry(ClusterClient target, Session session, String ngql,
                                  MigrationConfig config) throws MigrationException {
        MigrationException last = null;
        for (int attempt = 0; attempt <= config.importRetryTimes(); attempt++) {
            try {
                target.execute(session, ngql, ExitCode.IMPORT_FAILED);
                return;
            } catch (MigrationException e) {
                last = e;
                if (!retryable(e) || attempt == config.importRetryTimes()) {
                    break;
                }
                try {
                    Thread.sleep(config.retryBackoffMs() * (attempt + 1));
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new MigrationException(ExitCode.IMPORT_FAILED, "Import retry interrupted", interrupted);
                }
            }
        }
        throw last;
    }

    private boolean retryable(MigrationException exception) {
        String message = exception.getMessage().toLowerCase(Locale.ROOT);
        return message.contains("leader") || message.contains("connect") || message.contains("timeout")
                || message.contains("rpc") || message.contains("e_unknown")
                // Meta schema has reached graphd, but a storage replica can still be refreshing.
                || message.contains("storage error: tag not found")
                || message.contains("storage error: edge not found")
                || message.contains("no schema found") || message.contains("tagnotfound")
                || message.contains("edgenotfound");
    }

    private String jsonField(String line, String name) throws MigrationException {
        String value = optionalJsonField(line, name);
        if (value == null) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Malformed failure record");
        }
        return value;
    }

    private String optionalJsonField(String line, String name) throws MigrationException {
        String marker = "\"" + name + "\":";
        int start = line.indexOf(marker);
        if (start < 0) {
            return null;
        }
        start += marker.length();
        if (start >= line.length() || line.charAt(start) != '"') {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Malformed failure record field");
        }
        int end = start + 1;
        boolean escaped = false;
        while (end < line.length()) {
            char value = line.charAt(end);
            if (value == '"' && !escaped) {
                break;
            }
            escaped = value == '\\' && !escaped;
            if (value != '\\') {
                escaped = false;
            }
            end++;
        }
        if (end >= line.length()) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Malformed failure record field");
        }
        return MiniJson.unquote(line.substring(start, end + 1));
    }

}
