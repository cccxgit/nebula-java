package com.vesoft.nebula.migration;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ReportWriter {
    private ReportWriter() {
    }

    public static void write(Workspace workspace, String name, Map<String, String> fields)
            throws MigrationException {
        Map<String, String> report = new LinkedHashMap<String, String>(fields);
        report.put("generatedAt", Instant.now().toString());
        StringBuilder json = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, String> field : report.entrySet()) {
            if (!first) {
                json.append(',');
            }
            json.append(MiniJson.quote(field.getKey())).append(':').append(MiniJson.quote(field.getValue()));
            first = false;
        }
        json.append("}\n");
        Path destination = workspace.reports().resolve(name + ".json");
        try {
            AtomicFiles.writeUtf8(destination, json.toString());
        } catch (IOException e) {
            throw new MigrationException(ExitCode.INTERNAL_ERROR, "Cannot write report " + destination, e);
        }
    }
}
