package com.vesoft.nebula.migration;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class RecordCodec {
    public static final String CSV_HEADER = "kind,key1,key2,rank,properties";

    private RecordCodec() {
    }

    public static String toCsv(MigrationRecord record) {
        List<String> fields = new ArrayList<String>();
        fields.add(record.kind() == MigrationRecord.Kind.VERTEX ? "V" : "E");
        fields.add(record.firstKey().encode());
        fields.add(record.secondKey() == null ? "" : record.secondKey().encode());
        fields.add(String.valueOf(record.rank()));
        fields.add(encodeProperties(record.properties()));
        return csv(fields);
    }

    public static MigrationRecord fromCsv(String line) throws MigrationException {
        List<String> fields = parseCsv(line);
        if (fields.size() != 5) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid CSV migration record");
        }
        TypedValue first = TypedValue.decode(fields.get(1));
        Map<String, TypedValue> properties = decodeProperties(fields.get(4));
        if ("V".equals(fields.get(0))) {
            return MigrationRecord.vertex(first, properties);
        }
        if ("E".equals(fields.get(0))) {
            try {
                return MigrationRecord.edge(first, TypedValue.decode(fields.get(2)),
                        Long.parseLong(fields.get(3)), properties);
            } catch (NumberFormatException e) {
                throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid edge rank", e);
            }
        }
        throw new MigrationException(ExitCode.IMPORT_FAILED, "Unknown migration record kind");
    }

    public static String toJson(MigrationRecord record) {
        return "{\"kind\":" + MiniJson.quote(record.kind() == MigrationRecord.Kind.VERTEX ? "V" : "E")
                + ",\"key1\":" + MiniJson.quote(record.firstKey().encode())
                + ",\"key2\":" + MiniJson.quote(record.secondKey() == null ? "" : record.secondKey().encode())
                + ",\"rank\":" + record.rank()
                + ",\"properties\":" + MiniJson.quote(encodeProperties(record.properties())) + "}";
    }

    public static MigrationRecord fromJson(String line) throws MigrationException {
        String kind = jsonString(line, "kind");
        String first = jsonString(line, "key1");
        String second = jsonString(line, "key2");
        String properties = jsonString(line, "properties");
        String rank = jsonNumber(line, "rank");
        if ("V".equals(kind)) {
            return MigrationRecord.vertex(TypedValue.decode(first), decodeProperties(properties));
        }
        if ("E".equals(kind)) {
            try {
                return MigrationRecord.edge(TypedValue.decode(first), TypedValue.decode(second),
                        Long.parseLong(rank), decodeProperties(properties));
            } catch (NumberFormatException e) {
                throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid JSON edge rank", e);
            }
        }
        throw new MigrationException(ExitCode.IMPORT_FAILED, "Unknown JSON migration record kind");
    }

    private static String encodeProperties(Map<String, TypedValue> properties) {
        StringBuilder builder = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, TypedValue> property : properties.entrySet()) {
            if (!first) {
                builder.append(';');
            }
            builder.append(Base64.getUrlEncoder().withoutPadding().encodeToString(
                    property.getKey().getBytes(StandardCharsets.UTF_8)));
            builder.append(':').append(property.getValue().encode());
            first = false;
        }
        return builder.toString();
    }

    private static Map<String, TypedValue> decodeProperties(String encoded) throws MigrationException {
        Map<String, TypedValue> properties = new LinkedHashMap<String, TypedValue>();
        if (encoded.isEmpty()) {
            return properties;
        }
        for (String item : encoded.split(";")) {
            int separator = item.indexOf(':');
            if (separator <= 0) {
                throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid properties encoding");
            }
            try {
                String name = new String(Base64.getUrlDecoder().decode(item.substring(0, separator)),
                        StandardCharsets.UTF_8);
                properties.put(name, TypedValue.decode(item.substring(separator + 1)));
            } catch (IllegalArgumentException e) {
                throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid property name encoding", e);
            }
        }
        return properties;
    }

    private static String csv(List<String> fields) {
        StringBuilder builder = new StringBuilder();
        for (int index = 0; index < fields.size(); index++) {
            if (index > 0) {
                builder.append(',');
            }
            String field = fields.get(index);
            boolean quote = field.indexOf(',') >= 0 || field.indexOf('"') >= 0
                    || field.indexOf('\n') >= 0 || field.indexOf('\r') >= 0;
            if (quote) {
                builder.append('"').append(field.replace("\"", "\"\"")).append('"');
            } else {
                builder.append(field);
            }
        }
        return builder.toString();
    }

    private static List<String> parseCsv(String input) throws MigrationException {
        List<String> result = new ArrayList<String>();
        StringBuilder current = new StringBuilder();
        boolean quoted = false;
        for (int index = 0; index < input.length(); index++) {
            char character = input.charAt(index);
            if (quoted) {
                if (character == '"') {
                    if (index + 1 < input.length() && input.charAt(index + 1) == '"') {
                        current.append('"');
                        index++;
                    } else {
                        quoted = false;
                    }
                } else {
                    current.append(character);
                }
            } else if (character == ',') {
                result.add(current.toString());
                current.setLength(0);
            } else if (character == '"' && current.length() == 0) {
                quoted = true;
            } else {
                current.append(character);
            }
        }
        if (quoted) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Unterminated CSV quoted field");
        }
        result.add(current.toString());
        return result;
    }

    private static String jsonString(String line, String field) throws MigrationException {
        String marker = "\"" + field + "\":";
        int start = line.indexOf(marker);
        if (start < 0) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Missing JSON field " + field);
        }
        start += marker.length();
        if (start >= line.length() || line.charAt(start) != '"') {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid JSON field " + field);
        }
        int end = start + 1;
        boolean escaped = false;
        while (end < line.length()) {
            char current = line.charAt(end);
            if (current == '"' && !escaped) {
                break;
            }
            if (current == '\\' && !escaped) {
                escaped = true;
            } else {
                escaped = false;
            }
            end++;
        }
        if (end >= line.length()) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Unterminated JSON field " + field);
        }
        return MiniJson.unquote(line.substring(start, end + 1));
    }

    private static String jsonNumber(String line, String field) throws MigrationException {
        String marker = "\"" + field + "\":";
        int start = line.indexOf(marker);
        if (start < 0) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Missing JSON field " + field);
        }
        start += marker.length();
        int end = start;
        while (end < line.length() && line.charAt(end) != ',' && line.charAt(end) != '}') {
            end++;
        }
        return line.substring(start, end);
    }
}
