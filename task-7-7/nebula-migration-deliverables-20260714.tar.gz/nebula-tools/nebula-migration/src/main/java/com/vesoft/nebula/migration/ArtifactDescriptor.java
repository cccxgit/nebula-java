package com.vesoft.nebula.migration;

import java.nio.file.Path;

public final class ArtifactDescriptor {
    private final Path path;
    private final String space;
    private final MigrationRecord.Kind kind;
    private final String label;
    private final Integer partition;
    private final String format;

    public ArtifactDescriptor(Path path, String space, MigrationRecord.Kind kind, String label,
                              Integer partition, String format) {
        this.path = path;
        this.space = space;
        this.kind = kind;
        this.label = label;
        this.partition = partition;
        this.format = format;
    }

    public Path path() {
        return path;
    }

    public String space() {
        return space;
    }

    public MigrationRecord.Kind kind() {
        return kind;
    }

    public String label() {
        return label;
    }

    public Integer partition() {
        return partition;
    }

    public String format() {
        return format;
    }

    public String id() {
        return space + "/" + kind.pathName() + "/" + label + "/"
                + (partition == null ? "label" : partition);
    }
}
