package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.data.ValueWrapper;
import com.vesoft.nebula.client.graph.net.Session;
import com.vesoft.nebula.client.storage.StorageClient;
import com.vesoft.nebula.client.storage.data.EdgeRow;
import com.vesoft.nebula.client.storage.data.VertexRow;
import com.vesoft.nebula.client.storage.scan.ScanEdgeResult;
import com.vesoft.nebula.client.storage.scan.ScanEdgeResultIterator;
import com.vesoft.nebula.client.storage.scan.ScanVertexResult;
import com.vesoft.nebula.client.storage.scan.ScanVertexResultIterator;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public final class VerifyService {
    public void verify(ClusterClient target, Workspace workspace, Manifest manifest,
                       MigrationConfig config) throws MigrationException {
        Instant startedAt = Instant.now();
        manifest.setState(Manifest.State.VERIFYING);
        boolean success = true;
        long checked = 0;
        Path detailsPath = workspace.reports().resolve("verify-details.jsonl");
        try (BufferedWriter details = Files.newBufferedWriter(detailsPath, StandardCharsets.UTF_8)) {
            Session session = target.openSession();
            try {
                for (ArtifactDescriptor artifact : manifest.artifacts(workspace.root())) {
                    Integrity.verifyCompleted(artifact.path(), config.hmacKey(), ExitCode.VERIFY_FAILED);
                    VerifyResult result = verifyArtifact(target, session, workspace, manifest, artifact, config,
                            details);
                    success &= result.success;
                    checked++;
                }
            } finally {
                session.release();
            }
        } catch (IOException e) {
            throw new MigrationException(ExitCode.VERIFY_FAILED, "Cannot write verify details", e);
        }
        Map<String, String> report = new LinkedHashMap<String, String>();
        report.put("status", success ? "PASS" : "FAIL");
        report.put("artifactsChecked", String.valueOf(checked));
        report.put("ttlDetected", String.valueOf(manifest.ttlDetected()));
        report.put("fullChecksumEnabled", String.valueOf(config.fullChecksumEnabled()));
        report.put("fullConsistencyProven", String.valueOf(config.fullChecksumEnabled() && success));
        if (!config.fullChecksumEnabled()) {
            report.put("fullChecksum", "SKIPPED_DISABLED: 未证明全量完全一致");
        }
        addOperationAudit(report, manifest, startedAt);
        ReportWriter.write(workspace, "verify-report", report);
        if (!success) {
            manifest.setState(Manifest.State.FAILED);
            throw new MigrationException(ExitCode.VERIFY_FAILED, "Migration verification found differences");
        }
        manifest.setState(Manifest.State.VERIFIED);
    }

    private VerifyResult verifyArtifact(ClusterClient target, Session session, Workspace workspace,
                                        Manifest manifest, ArtifactDescriptor artifact,
                                        MigrationConfig config, BufferedWriter details)
            throws MigrationException, IOException {
        List<Integer> partitions = artifact.partition() == null
                ? ClusterInspector.partitions(target, session, artifact.space())
                : Collections.singletonList(artifact.partition());
        ScanStats total = new ScanStats(config.fullChecksumEnabled(), config.sampleModulo(),
                config.sampleMaxRecords(), artifact.label());
        for (Integer partition : partitions) {
            ScanStats stats = scanTarget(target.storage(), artifact, partition, config);
            total.merge(stats);
            long expected = artifact.partition() == null
                    ? manifest.partitionRowCount(workspace.root(), artifact.path(), partition)
                    : manifest.rowCount(artifact, workspace.root());
            boolean countMatch = expected == stats.count;
            String expectedDigest = artifact.partition() == null
                    ? manifest.partitionCanonicalDigest(workspace.root(), artifact.path(), partition)
                    : manifest.canonicalDigest(artifact, workspace.root());
            boolean checksumMatch = !config.fullChecksumEnabled()
                    || expectedDigest.equals(stats.accumulator.digest());
            writeDetail(details, artifact, partition, expected, stats.count, countMatch, checksumMatch,
                    "partition");
            if (!countMatch || !checksumMatch) {
                total.success = false;
            }
        }
        long expectedTotal = manifest.rowCount(artifact, workspace.root());
        boolean totalCountMatch = expectedTotal == total.count;
        SampleCollector sourceSamples = samplesFromArtifact(artifact, config.sampleModulo(),
                config.sampleMaxRecords());
        boolean sampleMatch = sourceSamples.matches(total.samples);
        boolean checksumMatch = !config.fullChecksumEnabled()
                || manifest.canonicalDigest(artifact, workspace.root()).equals(total.accumulator.digest());
        boolean success = total.success && totalCountMatch && sampleMatch && checksumMatch;
        writeDetail(details, artifact, null, expectedTotal, total.count, totalCountMatch,
                checksumMatch && sampleMatch, "artifact");
        return new VerifyResult(success);
    }

    private ScanStats scanTarget(StorageClient storage, ArtifactDescriptor artifact, int partition,
                                 MigrationConfig config) throws MigrationException {
        ScanStats stats = new ScanStats(config.fullChecksumEnabled(), config.sampleModulo(),
                config.sampleMaxRecords(), artifact.label());
        try {
            if (artifact.kind() == MigrationRecord.Kind.VERTEX) {
                ScanVertexResultIterator iterator = storage.scanVertex(artifact.space(), partition,
                        artifact.label(), Collections.<String>emptyList(), config.scanLimit(), 0L,
                        Long.MAX_VALUE, false, false);
                while (iterator.hasNext()) {
                    ScanVertexResult result = iterator.next();
                    if (!result.isAllSuccess()) {
                        throw new MigrationException(ExitCode.VERIFY_FAILED,
                                "Target vertex scan returned partial failure");
                    }
                    for (VertexRow row : result.getVertices()) {
                        MigrationRecord record = MigrationRecord.vertex(TypedValue.from(row.getVid()),
                                values(row.getProps()));
                        stats.add(record);
                    }
                }
            } else {
                ScanEdgeResultIterator iterator = storage.scanEdge(artifact.space(), partition,
                        artifact.label(), Collections.<String>emptyList(), config.scanLimit(), 0L,
                        Long.MAX_VALUE, false, false);
                while (iterator.hasNext()) {
                    ScanEdgeResult result = iterator.next();
                    if (!result.isAllSuccess()) {
                        throw new MigrationException(ExitCode.VERIFY_FAILED,
                                "Target edge scan returned partial failure");
                    }
                    for (EdgeRow row : result.getEdges()) {
                        MigrationRecord record = MigrationRecord.edge(TypedValue.from(row.getSrcId()),
                                TypedValue.from(row.getDstId()), row.getRank(), values(row.getProps()));
                        stats.add(record);
                    }
                }
            }
            return stats;
        } catch (MigrationException e) {
            throw e;
        } catch (Exception e) {
            throw new MigrationException(ExitCode.VERIFY_FAILED, "Cannot scan target artifact", e);
        }
    }

    private SampleCollector samplesFromArtifact(ArtifactDescriptor artifact, int modulo, int maxRecords)
            throws MigrationException {
        SampleCollector samples = new SampleCollector(modulo, maxRecords, artifact.label());
        try (DataFileReader reader = new DataFileReader(artifact.path(), artifact.format())) {
            DataFileReader.Entry entry;
            while ((entry = reader.next()) != null) {
                samples.add(entry.record());
            }
        }
        return samples;
    }

    private Map<String, TypedValue> values(Map<String, ValueWrapper> raw) throws MigrationException {
        Map<String, TypedValue> values = new LinkedHashMap<String, TypedValue>();
        for (Map.Entry<String, ValueWrapper> entry : raw.entrySet()) {
            values.put(entry.getKey(), TypedValue.from(entry.getValue()));
        }
        return values;
    }

    private void writeDetail(BufferedWriter writer, ArtifactDescriptor artifact, Integer partition,
                             long expected, long actual, boolean countMatch, boolean valueMatch,
                             String scope) throws IOException {
        writer.write("{\"scope\":" + MiniJson.quote(scope)
                + ",\"space\":" + MiniJson.quote(artifact.space())
                + ",\"kind\":" + MiniJson.quote(artifact.kind().pathName())
                + ",\"label\":" + MiniJson.quote(artifact.label())
                + ",\"partition\":" + MiniJson.quote(partition == null ? "" : String.valueOf(partition))
                + ",\"expectedCount\":" + expected
                + ",\"actualCount\":" + actual
                + ",\"countMatch\":" + countMatch
                + ",\"valueMatch\":" + valueMatch + "}\n");
    }

    private void addOperationAudit(Map<String, String> report, Manifest manifest, Instant startedAt) {
        Instant endedAt = Instant.now();
        report.put("jobId", manifest.jobId());
        report.put("startedAt", startedAt.toString());
        report.put("endedAt", endedAt.toString());
        report.put("durationMs", String.valueOf(Duration.between(startedAt, endedAt).toMillis()));
    }

    private static final class VerifyResult {
        private final boolean success;

        private VerifyResult(boolean success) {
            this.success = success;
        }
    }

    private static final class ScanStats {
        private long count;
        private boolean success = true;
        private final CanonicalAccumulator accumulator;
        private final SampleCollector samples;

        private ScanStats(boolean fullChecksumEnabled, int sampleModulo, int sampleMaxRecords,
                          String label) {
            accumulator = fullChecksumEnabled ? new CanonicalAccumulator() : null;
            samples = new SampleCollector(sampleModulo, sampleMaxRecords, label);
        }

        private void add(MigrationRecord record) {
            if (accumulator != null) {
                accumulator.add(record.canonical(samples.label));
            }
            samples.add(record);
            count++;
        }

        private void merge(ScanStats other) {
            count += other.count;
            success &= other.success;
            if (accumulator != null) {
                accumulator.merge(other.accumulator);
            }
            samples.merge(other.samples);
        }
    }

    private static final class SampleCollector {
        private final int modulo;
        private final int maxRecords;
        private final String label;
        private final TreeMap<String, Sample> selected = new TreeMap<String, Sample>();
        private String lowestHash;
        private String lowestKey;
        private String lowestValue;

        private SampleCollector(int modulo, int maxRecords, String label) {
            this.modulo = modulo;
            this.maxRecords = maxRecords;
            this.label = label;
        }

        private void add(MigrationRecord record) {
            String key = key(record);
            String hash = sha256(key);
            if (lowestHash == null || hash.compareTo(lowestHash) < 0) {
                lowestHash = hash;
                lowestKey = key;
                lowestValue = record.canonicalHash(label);
            }
            long bucket = Long.parseLong(hash.substring(0, 8), 16);
            if (Math.floorMod(bucket, (long) modulo) == 0L) {
                addSelected(hash, key, record.canonicalHash(label));
            }
        }

        private void merge(SampleCollector other) {
            for (Sample sample : other.selected.values()) {
                addSelected(sample.hash, sample.key, sample.value);
            }
            if (other.lowestHash != null && (lowestHash == null || other.lowestHash.compareTo(lowestHash) < 0)) {
                lowestHash = other.lowestHash;
                lowestKey = other.lowestKey;
                lowestValue = other.lowestValue;
            }
        }

        private boolean matches(SampleCollector other) {
            ensureFallback();
            other.ensureFallback();
            return values().equals(other.values());
        }

        private void ensureFallback() {
            if (selected.isEmpty() && lowestKey != null) {
                addSelected(lowestHash, lowestKey, lowestValue);
            }
        }

        private void addSelected(String hash, String key, String value) {
            selected.put(hash + "|" + key, new Sample(hash, key, value));
            while (selected.size() > maxRecords) {
                selected.pollLastEntry();
            }
        }

        private Map<String, String> values() {
            Map<String, String> values = new LinkedHashMap<String, String>();
            for (Sample sample : selected.values()) {
                values.put(sample.key, sample.value);
            }
            return values;
        }

        private static final class Sample {
            private final String hash;
            private final String key;
            private final String value;

            private Sample(String hash, String key, String value) {
                this.hash = hash;
                this.key = key;
                this.value = value;
            }
        }

        private static String key(MigrationRecord record) {
            return record.kind().name() + "|" + record.firstKey().encode() + "|"
                    + (record.secondKey() == null ? "" : record.secondKey().encode()) + "|" + record.rank();
        }

        private static String sha256(String input) {
            try {
                return Integrity.hex(MessageDigest.getInstance("SHA-256")
                        .digest(input.getBytes(StandardCharsets.UTF_8)));
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }
    }
}
