package com.vesoft.nebula.migration;

public enum ExitCode {
    SUCCESS(0),
    USAGE(2),
    PRECHECK_FAILED(3),
    EXPORT_FAILED(4),
    IMPORT_FAILED(5),
    METADATA_FAILED(6),
    VERIFY_FAILED(7),
    INTERNAL_ERROR(10);

    private final int value;

    ExitCode(int value) {
        this.value = value;
    }

    public int value() {
        return value;
    }
}
