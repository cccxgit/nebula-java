package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.data.ResultSet;
import com.vesoft.nebula.client.graph.data.ValueWrapper;
import com.vesoft.nebula.client.graph.data.HostAddress;
import com.vesoft.nebula.client.graph.net.Session;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

public final class MetadataService {
    private static final Logger LOG = Logger.getLogger(MetadataService.class);
    private static final Pattern USE_STATEMENT = Pattern.compile(
            "^\\s*USE\\s+(`(?:``|[^`])*`|[A-Za-z_][A-Za-z0-9_]*)\\s*$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern CREATE_LABEL_STATEMENT = Pattern.compile(
            "^\\s*CREATE\\s+(TAG|EDGE)\\s+(?!INDEX\\b)(`(?:``|[^`])*`|[A-Za-z_][A-Za-z0-9_]*)",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TTL_DURATION = Pattern.compile(
            "\\bttl_duration\\s*=\\s*([0-9]+)", Pattern.CASE_INSENSITIVE);

    public void exportMetadata(ClusterClient source, Workspace workspace, Manifest manifest,
                               MigrationConfig config) throws MigrationException {
        List<String> statements = new ArrayList<String>();
        List<String> readable = new ArrayList<String>();
        boolean ttlDetected = false;
        Session session = source.openSession();
        try {
            List<String> spaces = ClusterInspector.spaces(source, session, ExitCode.EXPORT_FAILED);
            for (String space : spaces) {
                String statement = showCreate(source, session, "SHOW CREATE SPACE " + ClusterClient.identifier(space));
                statements.add(statement);
                readable.add(statement);
            }
            for (String space : spaces) {
                statements.add("USE " + ClusterClient.identifier(space));
                readable.add("USE " + ClusterClient.identifier(space));
                ttlDetected |= exportLabels(source, session, space, MigrationRecord.Kind.VERTEX, statements, readable);
                ttlDetected |= exportLabels(source, session, space, MigrationRecord.Kind.EDGE, statements, readable);
                exportIndexes(source, session, "SHOW TAG INDEXES", "SHOW CREATE TAG INDEX ", statements, readable);
                exportIndexes(source, session, "SHOW EDGE INDEXES", "SHOW CREATE EDGE INDEX ", statements, readable);
            }
            MetadataAudit audit = exportUsersAndRoles(source, session, spaces, statements, readable);
            manifest.setMetadataAudit(audit.rootPresent, audit.sourceUsers, audit.migratedUsers,
                    audit.migratedSpaceRoles);
        } finally {
            session.release();
        }

        Path statementFile = workspace.meta().resolve("metadata.statements");
        Path readableFile = workspace.meta().resolve("metadata.nql");
        writeStatements(statementFile, statements);
        writeReadable(readableFile, statements);
        Integrity.markCompleted(statementFile, config.hmacKey());
        manifest.setMetadata(workspace.root(), statementFile);
        manifest.setTtlDetected(ttlDetected);
        if (ttlDetected) {
            LOG.warn("TTL schema detected. Export continues, but rows can age between export and import.");
        }
    }

    public void importMetadata(ClusterClient target, Workspace workspace, Manifest manifest,
                               MigrationConfig config) throws MigrationException {
        Path statementFile = manifest.metadataPath(workspace.root());
        Integrity.verifyCompleted(statementFile, config.hmacKey(), ExitCode.METADATA_FAILED);
        Session session = target.openSession();
        try {
            List<String> statements = readStatements(statementFile);
            // Space creation is asynchronous from graphd's perspective. Finish all spaces first
            // so the following USE/schema statements can retry against a stable meta view.
            for (String statement : statements) {
                if (isCreateSpace(statement)) {
                    executeDdlWithRetry(target, session, statement, config);
                }
            }
            for (String statement : statements) {
                if (!isCreateSpace(statement)) {
                    executeDdlWithRetry(target, session, statement, config);
                }
            }
            waitForSchemaVisibility(target, statements, config);
        } finally {
            session.release();
        }
    }

    private List<String> readStatements(Path statementFile) throws MigrationException {
        List<String> statements = new ArrayList<String>();
        try (BufferedReader reader = Files.newBufferedReader(statementFile, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                try {
                    statements.add(new String(Base64.getDecoder().decode(line), StandardCharsets.UTF_8));
                } catch (IllegalArgumentException e) {
                    throw new MigrationException(ExitCode.METADATA_FAILED,
                            "Invalid metadata statement encoding", e);
                }
            }
        } catch (IOException e) {
            throw new MigrationException(ExitCode.METADATA_FAILED, "Cannot read metadata artifact", e);
        }
        return statements;
    }

    private boolean isCreateSpace(String statement) {
        return statement.trim().toUpperCase(Locale.ROOT).startsWith("CREATE SPACE");
    }

    private void waitForSchemaVisibility(ClusterClient target, List<String> statements,
                                         MigrationConfig config) throws MigrationException {
        Map<String, SchemaLabels> expected = expectedSchemas(statements);
        if (expected.isEmpty()) {
            return;
        }
        long deadline = System.currentTimeMillis() + config.schemaVisibilityTimeoutMs();
        String pending = "";
        MigrationException lastFailure = null;
        do {
            boolean visible = true;
            for (HostAddress graphAddress : target.graphAddresses()) {
                for (Map.Entry<String, SchemaLabels> entry : expected.entrySet()) {
                    for (String tag : entry.getValue().tags) {
                        MigrationException failure = schemaCacheFailure(target, graphAddress,
                                entry.getKey(), "EXPLAIN INSERT VERTEX " + ClusterClient.identifier(tag)
                                        + "() VALUES 0:()");
                        if (failure != null) {
                            visible = false;
                            lastFailure = failure;
                            pending = "graphd=" + graphAddress + ", space=" + entry.getKey()
                                    + ", tag=" + tag + ", error=" + failure.getMessage();
                        }
                    }
                    for (String edge : entry.getValue().edges) {
                        MigrationException failure = schemaCacheFailure(target, graphAddress,
                                entry.getKey(), "EXPLAIN INSERT EDGE " + ClusterClient.identifier(edge)
                                        + "() VALUES 0->0:()");
                        if (failure != null) {
                            visible = false;
                            lastFailure = failure;
                            pending = "graphd=" + graphAddress + ", space=" + entry.getKey()
                                    + ", edge=" + edge + ", error=" + failure.getMessage();
                        }
                    }
                }
            }
            if (visible) {
                return;
            }
            if (System.currentTimeMillis() >= deadline) {
                break;
            }
            sleep(Math.max(100L, Math.min(config.retryBackoffMs(), 1000L)));
        } while (true);
        String message = "Metadata schema was not visible on every target graphd within "
                + config.schemaVisibilityTimeoutMs() + "ms";
        if (!pending.isEmpty()) {
            message += ": " + pending;
        }
        throw new MigrationException(ExitCode.METADATA_FAILED, message, lastFailure);
    }

    /**
     * SHOW TAGS reads MetaClient directly, while INSERT validation reads SchemaManager's local
     * cache. EXPLAIN validates an INSERT without writing data, which makes it an accurate cache
     * barrier. A VID type mismatch means the schema was found, so it is not a pending condition.
     */
    private MigrationException schemaCacheFailure(ClusterClient target, HostAddress graphAddress,
                                                  String space, String statement) {
        try {
            target.executeInSpaceOnGraph(graphAddress, space, statement, ExitCode.METADATA_FAILED);
            return null;
        } catch (MigrationException e) {
            String message = e.getMessage().toLowerCase(Locale.ROOT);
            if (message.contains("no schema found") || message.contains("tagnotfound")
                    || message.contains("edgenotfound") || message.contains("spacenotfound")
                    || message.contains("space not found") || message.contains("cannot execute against")) {
                return e;
            }
            return null;
        }
    }

    private Map<String, SchemaLabels> expectedSchemas(List<String> statements)
            throws MigrationException {
        Map<String, SchemaLabels> expected = new LinkedHashMap<String, SchemaLabels>();
        String currentSpace = null;
        for (String statement : statements) {
            Matcher use = USE_STATEMENT.matcher(statement);
            if (use.matches()) {
                currentSpace = unquoteIdentifier(use.group(1));
                continue;
            }
            Matcher createLabel = CREATE_LABEL_STATEMENT.matcher(statement);
            if (!createLabel.find()) {
                continue;
            }
            if (currentSpace == null) {
                throw new MigrationException(ExitCode.METADATA_FAILED,
                        "Schema DDL appears before a USE statement: " + statement);
            }
            SchemaLabels labels = expected.get(currentSpace);
            if (labels == null) {
                labels = new SchemaLabels();
                expected.put(currentSpace, labels);
            }
            if ("TAG".equalsIgnoreCase(createLabel.group(1))) {
                labels.tags.add(unquoteIdentifier(createLabel.group(2)));
            } else {
                labels.edges.add(unquoteIdentifier(createLabel.group(2)));
            }
        }
        return expected;
    }

    private String unquoteIdentifier(String token) {
        if (token.startsWith("`") && token.endsWith("`")) {
            return token.substring(1, token.length() - 1).replace("``", "`");
        }
        return token;
    }

    private boolean exportLabels(ClusterClient source, Session session, String space,
                                 MigrationRecord.Kind kind, List<String> statements,
                                 List<String> readable) throws MigrationException {
        boolean ttl = false;
        for (String label : ClusterInspector.labels(source, session, space, kind)) {
            String statement = showCreate(source, session,
                    "SHOW CREATE " + (kind == MigrationRecord.Kind.VERTEX ? "TAG " : "EDGE ")
                            + ClusterClient.identifier(label));
            statements.add(statement);
            readable.add(statement);
            ttl |= hasActiveTtl(statement);
        }
        return ttl;
    }

    static boolean hasActiveTtl(String statement) {
        Matcher matcher = TTL_DURATION.matcher(statement);
        if (!matcher.find()) {
            return false;
        }
        try {
            return Long.parseLong(matcher.group(1)) > 0L;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    private void exportIndexes(ClusterClient source, Session session, String showCommand,
                               String showCreatePrefix, List<String> statements,
                               List<String> readable) throws MigrationException {
        ResultSet indexes = source.execute(session, showCommand, ExitCode.EXPORT_FAILED);
        for (int row = 0; row < indexes.rowsSize(); row++) {
            String indexName = ClusterClient.valueAsString(indexes.rowValues(row).get(0));
            String statement = showCreate(source, session, showCreatePrefix + ClusterClient.identifier(indexName));
            statements.add(statement);
            readable.add(statement);
        }
    }

    private MetadataAudit exportUsersAndRoles(ClusterClient source, Session session, List<String> spaces,
                                              List<String> statements, List<String> readable)
            throws MigrationException {
        MetadataAudit audit = new MetadataAudit();
        ResultSet users = source.execute(session, "SHOW USERS", ExitCode.EXPORT_FAILED);
        for (int row = 0; row < users.rowsSize(); row++) {
            String user = ClusterClient.valueAsString(users.rowValues(row).get(0));
            audit.sourceUsers++;
            if (!"root".equals(user)) {
                String statement = "CREATE USER " + ClusterClient.identifier(user)
                        + " WITH PASSWORD \"nebula\"";
                statements.add(statement);
                readable.add(statement + ";");
                audit.migratedUsers++;
            } else {
                audit.rootPresent = true;
            }
        }
        for (String space : spaces) {
            ResultSet roles = source.execute(session, "SHOW ROLES IN " + ClusterClient.identifier(space),
                    ExitCode.EXPORT_FAILED);
            for (int row = 0; row < roles.rowsSize(); row++) {
                if (roles.rowValues(row).size() < 2) {
                    continue;
                }
                String user = ClusterClient.valueAsString(roles.rowValues(row).get(0));
                String role = ClusterClient.valueAsString(roles.rowValues(row).get(1));
                if ("root".equals(user)) {
                    continue;
                }
                String statement = "GRANT ROLE " + role + " ON " + ClusterClient.identifier(space)
                        + " TO " + ClusterClient.identifier(user);
                statements.add(statement);
                readable.add(statement + ";");
                audit.migratedSpaceRoles++;
            }
        }
        return audit;
    }

    private String showCreate(ClusterClient source, Session session, String statement)
            throws MigrationException {
        ResultSet result = source.execute(session, statement, ExitCode.EXPORT_FAILED);
        if (result.isEmpty()) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "SHOW CREATE returned no DDL: " + statement);
        }
        String ddl = null;
        for (ValueWrapper value : result.rowValues(0)) {
            if (value.isString()) {
                ddl = ClusterClient.valueAsString(value);
            }
        }
        if (ddl == null || ddl.trim().isEmpty()) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot decode SHOW CREATE result: " + statement);
        }
        return ddl.trim().endsWith(";") ? ddl.trim().substring(0, ddl.trim().length() - 1) : ddl.trim();
    }

    private void writeStatements(Path path, List<String> statements) throws MigrationException {
        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            for (String statement : statements) {
                writer.write(Base64.getEncoder().encodeToString(statement.getBytes(StandardCharsets.UTF_8)));
                writer.newLine();
            }
        } catch (IOException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot write metadata statements", e);
        }
    }

    private void writeReadable(Path path, List<String> statements) throws MigrationException {
        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            writer.write("-- Generated by nebula-migration. Root is audit-only and not recreated.\n");
            writer.write("-- Only non-root space roles are migrated. Unsupported extension privileges are excluded.\n");
            writer.write("-- Excluded objects: job history, fulltext indexes, configurations, snapshots, logs.\n\n");
            for (String statement : statements) {
                writer.write(statement);
                writer.write(";\n\n");
            }
        } catch (IOException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot write readable metadata", e);
        }
    }

    private void executeDdlWithRetry(ClusterClient target, Session session, String statement,
                                     MigrationConfig config) throws MigrationException {
        MigrationException last = null;
        for (int attempt = 0; attempt <= config.importRetryTimes(); attempt++) {
            try {
                target.execute(session, statement, ExitCode.METADATA_FAILED);
                return;
            } catch (MigrationException e) {
                last = e;
                if (!isRetryable(e) || attempt == config.importRetryTimes()) {
                    break;
                }
                sleep(config.retryBackoffMs() * (attempt + 1));
            }
        }
        throw new MigrationException(ExitCode.METADATA_FAILED,
                "Metadata import failed. Clean the target manually before retrying. statement=" + statement,
                last);
    }

    private boolean isRetryable(MigrationException exception) {
        String message = exception.getMessage().toLowerCase(Locale.ROOT);
        return message.contains("leader") || message.contains("connect") || message.contains("timeout")
                || message.contains("e_rpc_failure") || message.contains("spacenotfound")
                || message.contains("space not found");
    }

    private void sleep(long millis) throws MigrationException {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new MigrationException(ExitCode.METADATA_FAILED, "Metadata retry interrupted", e);
        }
    }

    private static final class SchemaLabels {
        private final Set<String> tags = new LinkedHashSet<String>();
        private final Set<String> edges = new LinkedHashSet<String>();
    }

    private static final class MetadataAudit {
        private boolean rootPresent;
        private int sourceUsers;
        private int migratedUsers;
        private int migratedSpaceRoles;
    }
}
