package com.vesoft.nebula.migration;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class Integrity {
    private static final String SIGNATURE_VERSION = "1";
    private static final String HMAC_KEY = "hmac";
    private static final String METADATA_PREFIX = "metadata.";

    private Integrity() {
    }

    public static void markCompleted(Path artifact, String hmacKey) throws MigrationException {
        markCompleted(artifact, hmacKey, Collections.<String, String>emptyMap());
    }

    /**
     * The signature includes immutable file metadata and export statistics. The latter forms a
     * small recovery journal: a process killed after signing but before manifest persistence can
     * reconstruct its manifest without rescanning the frozen source cluster.
     */
    public static void markCompleted(Path artifact, String hmacKey, Map<String, String> metadata)
            throws MigrationException {
        try {
            String sha256 = sha256(artifact);
            Properties signature = signatureProperties(artifact, sha256, metadata);
            signature.setProperty(HMAC_KEY, hmac(canonicalPayload(signature), hmacKey));
            AtomicFiles.writeUtf8(shaPath(artifact), sha256 + "\n");
            AtomicFiles.storeProperties(signaturePath(artifact), signature,
                    "Nebula Graph migration artifact signature");
        } catch (IOException | GeneralSecurityException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED,
                    "Cannot produce integrity sidecars for " + artifact, e);
        }
    }

    public static void verifyCompleted(Path artifact, String hmacKey, ExitCode failureCode)
            throws MigrationException {
        completionMetadata(artifact, hmacKey, failureCode);
    }

    public static Map<String, String> completionMetadata(Path artifact, String hmacKey,
                                                          ExitCode failureCode)
            throws MigrationException {
        try {
            if (!Files.isRegularFile(artifact) || !Files.isRegularFile(shaPath(artifact))
                    || !Files.isRegularFile(signaturePath(artifact))) {
                throw new MigrationException(failureCode, "Artifact is incomplete: " + artifact);
            }
            String expectedSha = readTrimmed(shaPath(artifact));
            String actualSha = sha256(artifact);
            if (!MessageDigest.isEqual(expectedSha.getBytes(StandardCharsets.US_ASCII),
                    actualSha.getBytes(StandardCharsets.US_ASCII))) {
                throw new MigrationException(failureCode, "SHA-256 mismatch: " + artifact);
            }
            Properties signature = loadProperties(signaturePath(artifact));
            if (!SIGNATURE_VERSION.equals(signature.getProperty("version"))) {
                throw new MigrationException(failureCode,
                        "Unsupported artifact signature format: " + artifact);
            }
            if (!artifact.getFileName().toString().equals(signature.getProperty("artifact.name"))
                    || !String.valueOf(Files.size(artifact)).equals(signature.getProperty("artifact.bytes"))
                    || !MessageDigest.isEqual(expectedSha.getBytes(StandardCharsets.US_ASCII),
                    signature.getProperty("sha256", "").getBytes(StandardCharsets.US_ASCII))) {
                throw new MigrationException(failureCode, "Artifact signature metadata mismatch: " + artifact);
            }
            String expectedSignature = signature.getProperty(HMAC_KEY, "");
            String actualSignature = hmac(canonicalPayload(signature), hmacKey);
            if (!MessageDigest.isEqual(expectedSignature.getBytes(StandardCharsets.US_ASCII),
                    actualSignature.getBytes(StandardCharsets.US_ASCII))) {
                throw new MigrationException(failureCode, "HMAC signature mismatch: " + artifact);
            }
            Map<String, String> metadata = new LinkedHashMap<String, String>();
            for (String name : signature.stringPropertyNames()) {
                if (name.startsWith(METADATA_PREFIX)) {
                    metadata.put(name.substring(METADATA_PREFIX.length()), signature.getProperty(name));
                }
            }
            return Collections.unmodifiableMap(metadata);
        } catch (IOException | GeneralSecurityException e) {
            throw new MigrationException(failureCode, "Cannot verify artifact " + artifact, e);
        }
    }

    public static boolean isCompleted(Path artifact, String hmacKey) {
        try {
            completionMetadata(artifact, hmacKey, ExitCode.EXPORT_FAILED);
            return true;
        } catch (MigrationException ignored) {
            return false;
        }
    }

    public static String sha256(Path file) throws IOException, GeneralSecurityException {
        return digest(file, MessageDigest.getInstance("SHA-256"));
    }

    private static Properties signatureProperties(Path artifact, String sha256,
                                                  Map<String, String> metadata) throws IOException {
        Properties signature = new Properties();
        signature.setProperty("version", SIGNATURE_VERSION);
        signature.setProperty("artifact.name", artifact.getFileName().toString());
        signature.setProperty("artifact.bytes", String.valueOf(Files.size(artifact)));
        signature.setProperty("sha256", sha256);
        if (metadata != null) {
            for (Map.Entry<String, String> entry : metadata.entrySet()) {
                if (entry.getKey() == null || entry.getKey().trim().isEmpty()) {
                    throw new IOException("Artifact metadata key is empty");
                }
                signature.setProperty(METADATA_PREFIX + entry.getKey(),
                        entry.getValue() == null ? "" : entry.getValue());
            }
        }
        return signature;
    }

    private static Properties loadProperties(Path path) throws IOException {
        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(path)) {
            properties.load(input);
        }
        return properties;
    }

    private static String canonicalPayload(Properties signature) {
        List<String> names = new ArrayList<String>();
        for (String name : signature.stringPropertyNames()) {
            if (!HMAC_KEY.equals(name)) {
                names.add(name);
            }
        }
        Collections.sort(names);
        StringBuilder payload = new StringBuilder();
        for (String name : names) {
            String value = signature.getProperty(name, "");
            payload.append(name.length()).append(':').append(name)
                    .append('=').append(value.length()).append(':').append(value).append('\n');
        }
        return payload.toString();
    }

    private static String hmac(String payload, String key) throws GeneralSecurityException {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        mac.update(payload.getBytes(StandardCharsets.UTF_8));
        return hex(mac.doFinal());
    }

    private static String digest(Path file, MessageDigest digest) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        try (InputStream input = Files.newInputStream(file)) {
            int read;
            while ((read = input.read(buffer)) >= 0) {
                digest.update(buffer, 0, read);
            }
        }
        return hex(digest.digest());
    }

    public static String hex(byte[] bytes) {
        StringBuilder builder = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            builder.append(String.format("%02x", value & 0xff));
        }
        return builder.toString();
    }

    public static Path shaPath(Path artifact) {
        return artifact.resolveSibling(artifact.getFileName().toString() + ".sha256");
    }

    public static Path signaturePath(Path artifact) {
        return artifact.resolveSibling(artifact.getFileName().toString() + ".sig");
    }

    private static String readTrimmed(Path path) throws IOException {
        return new String(Files.readAllBytes(path), StandardCharsets.US_ASCII).trim();
    }
}
