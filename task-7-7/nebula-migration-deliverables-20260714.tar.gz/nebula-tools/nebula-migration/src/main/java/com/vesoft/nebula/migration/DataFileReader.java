package com.vesoft.nebula.migration;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class DataFileReader implements AutoCloseable {
    private final BufferedReader reader;
    private final String format;
    private long logicalRow;

    public DataFileReader(Path path, String format) throws MigrationException {
        this.format = format;
        try {
            reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);
            if ("csv".equals(format)) {
                String header = reader.readLine();
                if (!RecordCodec.CSV_HEADER.equals(header)) {
                    throw new MigrationException(ExitCode.IMPORT_FAILED, "Unexpected CSV header in " + path);
                }
            }
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot open artifact " + path, e);
        }
    }

    public Entry next() throws MigrationException {
        try {
            String line = reader.readLine();
            if (line == null) {
                return null;
            }
            logicalRow++;
            MigrationRecord record = "csv".equals(format)
                    ? RecordCodec.fromCsv(line) : RecordCodec.fromJson(line);
            return new Entry(logicalRow, line, record);
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot read artifact", e);
        }
    }

    @Override
    public void close() throws MigrationException {
        try {
            reader.close();
        } catch (IOException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Cannot close artifact reader", e);
        }
    }

    public static final class Entry {
        private final long rowNumber;
        private final String raw;
        private final MigrationRecord record;

        private Entry(long rowNumber, String raw, MigrationRecord record) {
            this.rowNumber = rowNumber;
            this.raw = raw;
            this.record = record;
        }

        public long rowNumber() {
            return rowNumber;
        }

        public String raw() {
            return raw;
        }

        public MigrationRecord record() {
            return record;
        }
    }
}
