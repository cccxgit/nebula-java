package com.vesoft.nebula.migration;

import java.nio.file.Files;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public final class MigrationCli {
    static {
        if (System.getProperty("migration.log.file") == null) {
            System.setProperty("migration.log.file",
                    System.getProperty("java.io.tmpdir") + "/nebula-migration.log");
        }
    }

    private static final Logger LOG = Logger.getLogger(MigrationCli.class);

    private MigrationCli() {
    }

    public static void main(String[] args) {
        System.exit(run(args).value());
    }

    static ExitCode run(String[] args) {
        if (args.length != 3 || !"-c".equals(args[1])) {
            usage();
            return ExitCode.USAGE;
        }
        String command = args[0];
        try {
            MigrationConfig config = MigrationConfig.load(args[2]);
            try (Workspace workspace = Workspace.open(config)) {
                configureLogging(workspace, command);
                Manifest manifest = Manifest.load(workspace);
                if ("precheck".equals(command)) {
                    precheck(config, workspace, manifest);
                } else if ("export".equals(command)) {
                    export(config, workspace, manifest);
                } else if ("import".equals(command)) {
                    importData(config, workspace, manifest);
                } else if ("verify".equals(command)) {
                    verify(config, workspace, manifest);
                } else if ("retry-failed".equals(command)) {
                    retryFailed(config, workspace, manifest);
                } else {
                    usage();
                    return ExitCode.USAGE;
                }
                return ExitCode.SUCCESS;
            }
        } catch (MigrationException e) {
            LOG.error(e.getMessage(), e);
            System.err.println("Migration failed: " + e.getMessage());
            return e.exitCode();
        } catch (Exception e) {
            LOG.error("Unexpected migration failure", e);
            System.err.println("Migration failed: " + e.getMessage());
            return ExitCode.INTERNAL_ERROR;
        }
    }

    private static void precheck(MigrationConfig config, Workspace workspace, Manifest manifest)
            throws MigrationException {
        Instant startedAt = Instant.now();
        try (ClusterClient source = new ClusterClient(config.source());
             ClusterClient target = new ClusterClient(config.target())) {
            source.connect();
            target.connect();
            Map<String, String> sourceResult = ClusterInspector.precheckSource(source, config);
            Map<String, String> targetResult = ClusterInspector.precheckTarget(target, config);
            Map<String, String> report = new LinkedHashMap<String, String>();
            prefix(report, "source.", sourceResult);
            prefix(report, "target.", targetResult);
            report.put("status", "PASS");
            addOperationAudit(report, manifest, startedAt);
            ReportWriter.write(workspace, "precheck-report", report);
            manifest.initialize(config);
            manifest.setState(Manifest.State.PRECHECKED);
        }
    }

    private static void export(MigrationConfig config, Workspace workspace, Manifest manifest)
            throws MigrationException {
        Instant startedAt = Instant.now();
        try (ClusterClient source = new ClusterClient(config.source())) {
            source.connect();
            Map<String, String> sourceResult = ClusterInspector.precheckSource(source, config);
            new ExportService().export(source, workspace, manifest, config);
            Map<String, String> report = new LinkedHashMap<String, String>(sourceResult);
            report.put("status", "PASS");
            report.put("format", config.exportFormat());
            report.put("layout", config.exportLayout());
            report.put("ttlDetected", String.valueOf(manifest.ttlDetected()));
            report.put("artifacts", String.valueOf(manifest.artifacts(workspace.root()).size()));
            report.put("rootUser", manifest.metadataAudit("root.user", "NOT_REPORTED"));
            report.put("rootImportAction", manifest.metadataAudit("root.action", "AUDIT_ONLY_NOT_IMPORTED"));
            report.put("sourceUserCount", manifest.metadataAudit("source.user.count", "0"));
            report.put("migratedUserCount", manifest.metadataAudit("migrated.user.count", "0"));
            report.put("migratedSpaceRoleCount",
                    manifest.metadataAudit("migrated.space.role.count", "0"));
            report.put("permissionScope", manifest.metadataAudit("permission.scope",
                    "NON_ROOT_SPACE_ROLE_ONLY"));
            report.put("extendedPrivileges", manifest.metadataAudit("extended.privileges",
                    "WARNING_NOT_EXPORTED_UNSUPPORTED_EXTENSION_PRIVILEGES"));
            report.put("excludedObjects", manifest.metadataAudit("excluded.objects",
                    "job history,fulltext indexes,configurations,snapshots,logs"));
            addOperationAudit(report, manifest, startedAt);
            ReportWriter.write(workspace, "export-report", report);
        } catch (MigrationException e) {
            manifest.setState(Manifest.State.FAILED);
            throw e;
        }
    }

    private static void importData(MigrationConfig config, Workspace workspace, Manifest manifest)
            throws MigrationException {
        Instant startedAt = Instant.now();
        try (ClusterClient target = new ClusterClient(config.target())) {
            target.connect();
            new ImportService().importAll(target, workspace, manifest, config);
            Map<String, String> report = new LinkedHashMap<String, String>();
            report.put("status", "PASS");
            report.put("artifacts", String.valueOf(manifest.artifacts(workspace.root()).size()));
            report.put("metadataImported", String.valueOf(manifest.metadataImported()));
            addOperationAudit(report, manifest, startedAt);
            ReportWriter.write(workspace, "import-report", report);
        }
    }

    private static void verify(MigrationConfig config, Workspace workspace, Manifest manifest)
            throws MigrationException {
        try (ClusterClient target = new ClusterClient(config.target())) {
            target.connect();
            new VerifyService().verify(target, workspace, manifest, config);
        }
    }

    private static void retryFailed(MigrationConfig config, Workspace workspace, Manifest manifest)
            throws MigrationException {
        try (ClusterClient target = new ClusterClient(config.target())) {
            target.connect();
            new ImportService().retryFailed(target, workspace, manifest, config);
        }
    }

    private static void configureLogging(Workspace workspace, String command) throws MigrationException {
        try {
            java.nio.file.Path directory = workspace.root().resolve("logs");
            Files.createDirectories(directory);
            System.setProperty("migration.log.file", directory.resolve(command + ".log").toString());
            PropertyConfigurator.configure(MigrationCli.class.getClassLoader().getResource("log4j.properties"));
        } catch (Exception e) {
            throw new MigrationException(ExitCode.INTERNAL_ERROR, "Cannot configure log4j", e);
        }
    }

    private static void prefix(Map<String, String> destination, String prefix,
                               Map<String, String> source) {
        for (Map.Entry<String, String> entry : source.entrySet()) {
            destination.put(prefix + entry.getKey(), entry.getValue());
        }
    }

    private static void addOperationAudit(Map<String, String> report, Manifest manifest,
                                          Instant startedAt) {
        Instant endedAt = Instant.now();
        report.put("jobId", manifest.jobId());
        report.put("startedAt", startedAt.toString());
        report.put("endedAt", endedAt.toString());
        report.put("durationMs", String.valueOf(Duration.between(startedAt, endedAt).toMillis()));
    }

    private static void usage() {
        System.err.println("Usage: nebula-migration <precheck|export|import|verify|retry-failed> -c <properties>");
    }
}
