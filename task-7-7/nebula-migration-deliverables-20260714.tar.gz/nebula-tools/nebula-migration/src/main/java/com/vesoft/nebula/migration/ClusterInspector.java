package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.data.ResultSet;
import com.vesoft.nebula.client.graph.data.ValueWrapper;
import com.vesoft.nebula.client.graph.net.Session;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ClusterInspector {
    private ClusterInspector() {
    }

    public static List<String> spaces(ClusterClient client, Session session, ExitCode code)
            throws MigrationException {
        ResultSet result = client.execute(session, "SHOW SPACES", code);
        if (result.isEmpty()) {
            return Collections.emptyList();
        }
        return client.stringColumn(result, 0);
    }

    public static List<String> labels(ClusterClient client, Session session, String space,
                                      MigrationRecord.Kind kind) throws MigrationException {
        client.execute(session, "USE " + ClusterClient.identifier(space), ExitCode.EXPORT_FAILED);
        ResultSet result = client.execute(session, kind == MigrationRecord.Kind.VERTEX
                ? "SHOW TAGS" : "SHOW EDGES", ExitCode.EXPORT_FAILED);
        if (result.isEmpty()) {
            return Collections.emptyList();
        }
        return client.stringColumn(result, 0);
    }

    public static List<Integer> partitions(ClusterClient client, Session session, String space)
            throws MigrationException {
        client.execute(session, "USE " + ClusterClient.identifier(space), ExitCode.EXPORT_FAILED);
        ResultSet result = client.execute(session, "SHOW PARTS", ExitCode.EXPORT_FAILED);
        List<Integer> partitions = new ArrayList<Integer>();
        for (int row = 0; row < result.rowsSize(); row++) {
            ValueWrapper value = result.rowValues(row).get(0);
            try {
                partitions.add((int) value.asLong());
            } catch (Exception e) {
                throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot read partition id", e);
            }
        }
        Collections.sort(partitions);
        return partitions;
    }

    public static VersionEvidence verifyVersion(ClusterClient client, Session session,
                                                MigrationConfig config) throws MigrationException {
        String graphEvidence = verifyHostRoleVersion(client, session, "GRAPH", config);
        String metaEvidence = verifyHostRoleVersion(client, session, "META", config);
        verifyStorageHostsOnline(client, session);
        return new VersionEvidence(graphEvidence, metaEvidence);
    }

    private static String verifyHostRoleVersion(ClusterClient client, Session session, String role,
                                                MigrationConfig config) throws MigrationException {
        ResultSet result = client.execute(session, "SHOW HOSTS " + role, ExitCode.PRECHECK_FAILED);
        if (result.isEmpty()) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED,
                    "SHOW HOSTS " + role + " returned no hosts");
        }
        int versionColumn = -1;
        for (int index = 0; index < result.getColumnNames().size(); index++) {
            if (result.getColumnNames().get(index).toLowerCase(Locale.ROOT).contains("version")) {
                versionColumn = index;
                break;
            }
        }
        if (versionColumn < 0) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED,
                    "SHOW HOSTS " + role + " did not expose a version column; "
                            + "cannot prove Nebula Graph 3.6 baseline");
        }
        boolean unreported = false;
        for (int row = 0; row < result.rowsSize(); row++) {
            String version = ClusterClient.valueAsString(result.rowValues(row).get(versionColumn));
            if (version.trim().isEmpty()) {
                unreported = true;
                continue;
            }
            if (!version.contains(MigrationConfig.EXPECTED_SERVER_VERSION)) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED,
                        "Unsupported Nebula Graph " + role + " host version: " + version);
            }
        }
        if (unreported) {
            if (!config.allowUnreportedServerVersion()) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED,
                        "Nebula Graph " + role + " host version is not embedded in the running "
                                + "binary. Rebuild with -DNEBULA_BUILD_VERSION=3.6.0, or set "
                                + "compatibility.allow.unreported.server.version=true only after "
                                + "independently confirming both clusters are Nebula Graph 3.6.");
            }
            return "UNREPORTED_ALLOWED";
        }
        return "RUNTIME_" + MigrationConfig.EXPECTED_SERVER_VERSION;
    }

    private static void verifyStorageHostsOnline(ClusterClient client, Session session)
            throws MigrationException {
        ResultSet result = client.execute(session, "SHOW HOSTS STORAGE", ExitCode.PRECHECK_FAILED);
        if (result.isEmpty()) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED,
                    "SHOW HOSTS STORAGE returned no hosts");
        }
        int statusColumn = -1;
        for (int index = 0; index < result.getColumnNames().size(); index++) {
            if (result.getColumnNames().get(index).toLowerCase(Locale.ROOT).contains("status")) {
                statusColumn = index;
                break;
            }
        }
        if (statusColumn < 0) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED,
                    "SHOW HOSTS STORAGE did not expose a status column");
        }
        for (int row = 0; row < result.rowsSize(); row++) {
            String status = ClusterClient.valueAsString(result.rowValues(row).get(statusColumn));
            if (!"ONLINE".equalsIgnoreCase(status)) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED,
                        "Storage host is not ONLINE: " + status);
            }
        }
    }

    public static boolean hasRunningJobs(ClusterClient client, Session session, List<String> spaces)
            throws MigrationException {
        for (String space : spaces) {
            client.execute(session, "USE " + ClusterClient.identifier(space), ExitCode.PRECHECK_FAILED);
            ResultSet result = client.execute(session, "SHOW JOBS", ExitCode.PRECHECK_FAILED);
            for (int row = 0; row < result.rowsSize(); row++) {
                for (ValueWrapper value : result.rowValues(row)) {
                    String text = ClusterClient.valueAsString(value).toUpperCase(Locale.ROOT);
                    if (text.contains("RUNNING") || text.contains("QUEUE")) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static void verifyFreeze(List<String> urls) throws MigrationException {
        if (urls.isEmpty()) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED,
                    "source.freeze.urls is required for export precheck");
        }
        for (String url : urls) {
            String response = httpGet(url).replaceAll("\\s+", "");
            if (!response.contains("\"state\":\"FROZEN\"")) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED,
                        "Source graphd is not frozen: " + url + " response=" + response);
            }
        }
    }

    private static String httpGet(String rawUrl) throws MigrationException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(rawUrl).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            if (connection.getResponseCode() != 200) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED,
                        "Freeze endpoint returned HTTP " + connection.getResponseCode());
            }
            StringBuilder response = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    connection.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            }
            return response.toString();
        } catch (MigrationException e) {
            throw e;
        } catch (Exception e) {
            throw new MigrationException(ExitCode.PRECHECK_FAILED,
                    "Cannot query freeze endpoint " + rawUrl, e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    public static Map<String, String> precheckSource(ClusterClient source, MigrationConfig config)
            throws MigrationException {
        Session session = source.openSession();
        try {
            VersionEvidence versionEvidence = verifyVersion(source, session, config);
            List<String> spaces = spaces(source, session, ExitCode.PRECHECK_FAILED);
            if (hasRunningJobs(source, session, spaces)) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED,
                        "Source has RUNNING or QUEUE background jobs");
            }
            verifyFreeze(config.freezeUrls());
            Map<String, String> result = new LinkedHashMap<String, String>();
            result.put("status", "PASS");
            result.put("serverVersion", MigrationConfig.EXPECTED_SERVER_VERSION);
            result.put("serverVersionEvidence", versionEvidence.toString());
            result.put("spaceCount", String.valueOf(spaces.size()));
            result.put("freezeEndpoints", String.valueOf(config.freezeUrls().size()));
            return result;
        } finally {
            session.release();
        }
    }

    public static Map<String, String> precheckTarget(ClusterClient target, MigrationConfig config)
            throws MigrationException {
        Session session = target.openSession();
        try {
            VersionEvidence versionEvidence = verifyVersion(target, session, config);
            List<String> spaces = spaces(target, session, ExitCode.PRECHECK_FAILED);
            if (!spaces.isEmpty()) {
                throw new MigrationException(ExitCode.PRECHECK_FAILED,
                        "Target has business spaces: " + spaces);
            }
            ResultSet users = target.execute(session, "SHOW USERS", ExitCode.PRECHECK_FAILED);
            List<String> accounts = users.isEmpty() ? Collections.<String>emptyList()
                    : target.stringColumn(users, 0);
            for (String account : accounts) {
                if (!"root".equals(account)) {
                    throw new MigrationException(ExitCode.PRECHECK_FAILED,
                            "Target has non-root user: " + account);
                }
            }
            Map<String, String> result = new LinkedHashMap<String, String>();
            result.put("status", "PASS");
            result.put("serverVersion", MigrationConfig.EXPECTED_SERVER_VERSION);
            result.put("serverVersionEvidence", versionEvidence.toString());
            result.put("spaceCount", "0");
            result.put("users", accounts.toString());
            return result;
        } finally {
            session.release();
        }
    }

    public static final class VersionEvidence {
        private final String graph;
        private final String meta;

        private VersionEvidence(String graph, String meta) {
            this.graph = graph;
            this.meta = meta;
        }

        @Override
        public String toString() {
            return "graph=" + graph + ";meta=" + meta
                    + ";storage=ONLINE_API_VERSION_UNAVAILABLE";
        }
    }
}
