package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.data.ValueWrapper;
import com.vesoft.nebula.client.graph.data.DurationWrapper;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public final class TypedValue {
    public enum Type {
        NULL("N"), BOOLEAN("B"), INTEGER("I"), DOUBLE("F"), STRING("S"),
        DATE("D"), TIME("T"), DATETIME("DT"), GEOGRAPHY("G"), DURATION("DU");

        private final String code;

        Type(String code) {
            this.code = code;
        }

        public String code() {
            return code;
        }

        public static Type parse(String code) throws MigrationException {
            for (Type type : values()) {
                if (type.code.equals(code)) {
                    return type;
                }
            }
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Unsupported typed value code: " + code);
        }
    }

    private final Type type;
    private final String value;

    public TypedValue(Type type, String value) {
        this.type = type;
        this.value = value == null ? "" : value;
    }

    public Type type() {
        return type;
    }

    public String value() {
        return value;
    }

    public static TypedValue from(ValueWrapper value) throws MigrationException {
        try {
            if (value.isNull() || value.isEmpty()) {
                return new TypedValue(Type.NULL, "");
            }
            if (value.isBoolean()) {
                return new TypedValue(Type.BOOLEAN, String.valueOf(value.asBoolean()));
            }
            if (value.isLong()) {
                return new TypedValue(Type.INTEGER, String.valueOf(value.asLong()));
            }
            if (value.isDouble()) {
                double number = value.asDouble();
                if (Double.isNaN(number) || Double.isInfinite(number)) {
                    throw new MigrationException(ExitCode.EXPORT_FAILED,
                            "NaN and infinite floating values cannot be rendered as nGQL literals");
                }
                return new TypedValue(Type.DOUBLE, Double.toString(number));
            }
            if (value.isString()) {
                return new TypedValue(Type.STRING, value.asString());
            }
            if (value.isDate()) {
                return new TypedValue(Type.DATE, value.asDate().toString());
            }
            if (value.isTime()) {
                return new TypedValue(Type.TIME, value.asTime().getUTCTimeStr());
            }
            if (value.isDateTime()) {
                return new TypedValue(Type.DATETIME, value.asDateTime().getUTCDateTimeStr());
            }
            if (value.isGeography()) {
                return new TypedValue(Type.GEOGRAPHY, value.asGeography().toString());
            }
            if (value.isDuration()) {
                DurationWrapper duration = value.asDuration();
                // Persist the wire fields rather than DurationWrapper.toString(), whose ISO-like
                // presentation is not an nGQL literal and normalizes sub-second values.
                return new TypedValue(Type.DURATION, duration.getMonths() + ","
                        + duration.getSeconds() + "," + duration.getMicroseconds());
            }
        } catch (UnsupportedEncodingException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot decode Nebula string value", e);
        } catch (RuntimeException e) {
            throw new MigrationException(ExitCode.EXPORT_FAILED, "Cannot convert Nebula value", e);
        }
        throw new MigrationException(ExitCode.EXPORT_FAILED,
                "Unsupported property value type returned by StorageClient");
    }

    public String encode() {
        return type.code() + ":" + Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    public static TypedValue decode(String encoded) throws MigrationException {
        int separator = encoded.indexOf(':');
        if (separator <= 0) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid typed value encoding");
        }
        try {
            Type type = Type.parse(encoded.substring(0, separator));
            String value = new String(Base64.getDecoder().decode(encoded.substring(separator + 1)),
                    StandardCharsets.UTF_8);
            return new TypedValue(type, value);
        } catch (IllegalArgumentException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid typed value base64", e);
        }
    }

    public String ngqlLiteral() throws MigrationException {
        switch (type) {
            case NULL:
                return "NULL";
            case BOOLEAN:
                return Boolean.parseBoolean(value) ? "true" : "false";
            case INTEGER:
            case DOUBLE:
                return value;
            case STRING:
                return quoted(value);
            case DATE:
                return "date(" + quoted(value) + ")";
            case TIME:
                return "time(" + quoted(value) + ")";
            case DATETIME:
                return "datetime(" + quoted(value) + ")";
            case GEOGRAPHY:
                return "ST_GeogFromText(" + quoted(value) + ")";
            case DURATION:
                return durationLiteral(value);
            default:
                throw new MigrationException(ExitCode.IMPORT_FAILED, "Unsupported typed value");
        }
    }

    private static String quoted(String input) {
        StringBuilder builder = new StringBuilder(input.length() + 2);
        builder.append('"');
        for (int i = 0; i < input.length(); i++) {
            char character = input.charAt(i);
            switch (character) {
                case '\\': builder.append("\\\\"); break;
                case '"': builder.append("\\\""); break;
                case '\n': builder.append("\\n"); break;
                case '\r': builder.append("\\r"); break;
                case '\t': builder.append("\\t"); break;
                default: builder.append(character);
            }
        }
        return builder.append('"').toString();
    }

    private static String durationLiteral(String encoded) throws MigrationException {
        String[] fields = encoded.split(",", -1);
        if (fields.length != 3) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid duration encoding");
        }
        try {
            int months = Integer.parseInt(fields[0]);
            long seconds = Long.parseLong(fields[1]);
            int microseconds = Integer.parseInt(fields[2]);
            return "duration({months:" + months + ",seconds:" + seconds
                    + ",microseconds:" + microseconds + "})";
        } catch (NumberFormatException e) {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid duration encoding", e);
        }
    }
}
