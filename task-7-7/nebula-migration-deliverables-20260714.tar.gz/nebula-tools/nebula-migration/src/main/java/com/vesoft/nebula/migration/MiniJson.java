package com.vesoft.nebula.migration;

public final class MiniJson {
    private MiniJson() {
    }

    public static String quote(String value) {
        StringBuilder builder = new StringBuilder(value.length() + 16);
        builder.append('"');
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            switch (character) {
                case '"': builder.append("\\\""); break;
                case '\\': builder.append("\\\\"); break;
                case '\b': builder.append("\\b"); break;
                case '\f': builder.append("\\f"); break;
                case '\n': builder.append("\\n"); break;
                case '\r': builder.append("\\r"); break;
                case '\t': builder.append("\\t"); break;
                default:
                    if (character < 0x20) {
                        builder.append(String.format("\\u%04x", (int) character));
                    } else {
                        builder.append(character);
                    }
            }
        }
        return builder.append('"').toString();
    }

    public static String unquote(String value) throws MigrationException {
        if (value == null || value.length() < 2 || value.charAt(0) != '"'
                || value.charAt(value.length() - 1) != '"') {
            throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid JSON string");
        }
        StringBuilder builder = new StringBuilder(value.length());
        for (int index = 1; index < value.length() - 1; index++) {
            char current = value.charAt(index);
            if (current != '\\') {
                builder.append(current);
                continue;
            }
            if (++index >= value.length() - 1) {
                throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid JSON escape");
            }
            char escaped = value.charAt(index);
            switch (escaped) {
                case '"': builder.append('"'); break;
                case '\\': builder.append('\\'); break;
                case '/': builder.append('/'); break;
                case 'b': builder.append('\b'); break;
                case 'f': builder.append('\f'); break;
                case 'n': builder.append('\n'); break;
                case 'r': builder.append('\r'); break;
                case 't': builder.append('\t'); break;
                case 'u':
                    if (index + 4 >= value.length()) {
                        throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid JSON unicode escape");
                    }
                    try {
                        builder.append((char) Integer.parseInt(value.substring(index + 1, index + 5), 16));
                    } catch (NumberFormatException e) {
                        throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid JSON unicode escape", e);
                    }
                    index += 4;
                    break;
                default:
                    throw new MigrationException(ExitCode.IMPORT_FAILED, "Invalid JSON escape");
            }
        }
        return builder.toString();
    }
}
