package com.vesoft.nebula.migration;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class ManifestCheckpointTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void manifestAndCheckpointPersistAcrossWorkspaceReopen() throws Exception {
        Path config = temporaryFolder.newFile("migration.properties").toPath();
        Path workspace = temporaryFolder.newFolder("workspace").toPath();
        Properties properties = requiredProperties(workspace);
        try (java.io.OutputStream output = Files.newOutputStream(config)) {
            properties.store(output, "test");
        }
        MigrationConfig migrationConfig = MigrationConfig.load(config.toString());
        Path artifact;
        try (Workspace opened = Workspace.open(migrationConfig)) {
            Manifest manifest = Manifest.load(opened);
            manifest.initialize(migrationConfig);
            artifact = opened.data().resolve("s/vertex/t.csv");
            Files.createDirectories(artifact.getParent());
            Files.write(artifact, (RecordCodec.CSV_HEADER + "\n").getBytes(StandardCharsets.UTF_8));
            Integrity.markCompleted(artifact, migrationConfig.hmacKey());
            ArtifactDescriptor descriptor = new ArtifactDescriptor(artifact, "s", MigrationRecord.Kind.VERTEX,
                    "t", null, "csv");
            manifest.addArtifact(opened.root(), descriptor, 0L, new CanonicalAccumulator().digest());
            manifest.addPartitionStats(opened.root(), artifact, 1, 0L,
                    new CanonicalAccumulator().digest());
            CheckpointStore checkpoint = new CheckpointStore(opened);
            checkpoint.markImported(artifact, 17L);
        }
        try (Workspace reopened = Workspace.open(migrationConfig)) {
            Manifest manifest = Manifest.load(reopened);
            ArtifactDescriptor descriptor = manifest.artifacts(reopened.root()).get(0);
            Assert.assertEquals(0L, manifest.rowCount(descriptor, reopened.root()));
            Assert.assertEquals(0L, manifest.partitionRowCount(reopened.root(), artifact, 1));
            Assert.assertEquals(17L, new CheckpointStore(reopened).importedRows(artifact));
        }
    }

    @Test
    public void checkpointOnlyAdvancesForContiguousRows() throws Exception {
        Path config = temporaryFolder.newFile("prefix.properties").toPath();
        Path workspace = temporaryFolder.newFolder("prefix-workspace").toPath();
        Properties properties = requiredProperties(workspace);
        try (java.io.OutputStream output = Files.newOutputStream(config)) {
            properties.store(output, "test");
        }
        MigrationConfig migrationConfig = MigrationConfig.load(config.toString());
        try (Workspace opened = Workspace.open(migrationConfig)) {
            Path artifact = opened.data().resolve("rows.csv");
            CheckpointStore checkpoint = new CheckpointStore(opened);
            Assert.assertTrue(checkpoint.markImportedIfNext(artifact, 1L));
            Assert.assertFalse(checkpoint.markImportedIfNext(artifact, 3L));
            Assert.assertEquals(1L, checkpoint.importedRows(artifact));
            Assert.assertTrue(checkpoint.markImportedIfNext(artifact, 2L));
            Assert.assertTrue(checkpoint.markImportedIfNext(artifact, 3L));
            Assert.assertEquals(3L, checkpoint.importedRows(artifact));
        }
    }

    @Test
    public void bufferedCheckpointFlushesAtConfiguredBatchInterval() throws Exception {
        Path config = temporaryFolder.newFile("buffered.properties").toPath();
        Path workspace = temporaryFolder.newFolder("buffered-workspace").toPath();
        Properties properties = requiredProperties(workspace);
        try (java.io.OutputStream output = Files.newOutputStream(config)) {
            properties.store(output, "test");
        }
        MigrationConfig migrationConfig = MigrationConfig.load(config.toString());
        try (Workspace opened = Workspace.open(migrationConfig)) {
            Path artifact = opened.data().resolve("buffered.csv");
            CheckpointStore checkpoint = new CheckpointStore(opened, 2);
            checkpoint.markImported(artifact, 1L);
            Assert.assertEquals(0L, new CheckpointStore(opened).importedRows(artifact));
            checkpoint.markImported(artifact, 2L);
            Assert.assertEquals(2L, new CheckpointStore(opened).importedRows(artifact));
        }
    }

    @Test
    public void recoveryAppendsAfterSparseManifestIndex() throws Exception {
        Path config = temporaryFolder.newFile("sparse.properties").toPath();
        Path workspace = temporaryFolder.newFolder("sparse-workspace").toPath();
        Properties properties = requiredProperties(workspace);
        try (java.io.OutputStream output = Files.newOutputStream(config)) {
            properties.store(output, "test");
        }
        MigrationConfig migrationConfig = MigrationConfig.load(config.toString());
        try (Workspace opened = Workspace.open(migrationConfig)) {
            Path first = artifact(opened, "first.csv");
            Path second = artifact(opened, "second.csv");
            Path recovered = artifact(opened, "recovered.csv");
            Manifest manifest = Manifest.load(opened);
            manifest.initialize(migrationConfig);
            manifest.addArtifact(opened.root(), descriptor(first, "first"), 0L, "first");
            manifest.addArtifact(opened.root(), descriptor(second, "second"), 0L, "second");

            Properties persisted = new Properties();
            try (java.io.InputStream input = Files.newInputStream(opened.manifestPath())) {
                persisted.load(input);
            }
            for (Object key : new java.util.ArrayList<Object>(persisted.keySet())) {
                if (String.valueOf(key).startsWith("file.0.")) {
                    persisted.remove(key);
                }
            }
            try (java.io.OutputStream output = Files.newOutputStream(opened.manifestPath())) {
                persisted.store(output, "sparse test");
            }

            Manifest reloaded = Manifest.load(opened);
            reloaded.addArtifact(opened.root(), descriptor(recovered, "recovered"), 0L, "recovered");
            java.util.List<ArtifactDescriptor> artifacts = reloaded.artifacts(opened.root());
            Assert.assertEquals(2, artifacts.size());
            Assert.assertEquals(second, artifacts.get(0).path());
            Assert.assertEquals(recovered, artifacts.get(1).path());
        }
    }

    private Path artifact(Workspace workspace, String name) throws Exception {
        Path artifact = workspace.data().resolve(name);
        Files.write(artifact, (RecordCodec.CSV_HEADER + "\n").getBytes(StandardCharsets.UTF_8));
        return artifact;
    }

    private ArtifactDescriptor descriptor(Path artifact, String label) {
        return new ArtifactDescriptor(artifact, "s", MigrationRecord.Kind.VERTEX, label, null, "csv");
    }

    static Properties requiredProperties(Path workspace) {
        Properties values = new Properties();
        values.setProperty("source.graph.addresses", "127.0.0.1:9669");
        values.setProperty("source.meta.addresses", "127.0.0.1:9559");
        values.setProperty("source.user", "root");
        values.setProperty("source.password", "nebula");
        values.setProperty("target.graph.addresses", "127.0.0.1:19669");
        values.setProperty("target.meta.addresses", "127.0.0.1:19559");
        values.setProperty("target.user", "root");
        values.setProperty("target.password", "nebula");
        values.setProperty("workspace", workspace.toString());
        return values;
    }
}
