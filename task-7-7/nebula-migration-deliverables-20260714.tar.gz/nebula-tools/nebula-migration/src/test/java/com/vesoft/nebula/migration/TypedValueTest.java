package com.vesoft.nebula.migration;

import com.vesoft.nebula.DateTime;
import com.vesoft.nebula.Time;
import com.vesoft.nebula.Value;
import com.vesoft.nebula.client.graph.data.ValueWrapper;
import org.junit.Assert;
import org.junit.Test;

public class TypedValueTest {
    @Test
    public void rendersUtcTemporalWireValuesInsteadOfDebugStrings() throws Exception {
        Value time = new Value();
        time.setTVal(new Time((byte) 1, (byte) 2, (byte) 3, 4));
        TypedValue encodedTime = TypedValue.from(new ValueWrapper(time, "utf-8", 28800));
        Assert.assertEquals("time(\"01:02:03.000004\")", encodedTime.ngqlLiteral());

        Value dateTime = new Value();
        dateTime.setDtVal(new DateTime((short) 2024, (byte) 2, (byte) 3,
                (byte) 4, (byte) 5, (byte) 6, 7));
        TypedValue encodedDateTime = TypedValue.from(new ValueWrapper(dateTime, "utf-8", 28800));
        Assert.assertEquals("datetime(\"2024-02-03T04:05:06.000007\")",
                encodedDateTime.ngqlLiteral());
    }
}
