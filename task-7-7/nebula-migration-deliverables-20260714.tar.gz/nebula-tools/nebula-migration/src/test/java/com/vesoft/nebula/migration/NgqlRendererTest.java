package com.vesoft.nebula.migration;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;

public class NgqlRendererTest {
    @Test
    public void rendersEscapedVertexAndRankedEdge() throws Exception {
        Map<String, TypedValue> values = new LinkedHashMap<String, TypedValue>();
        values.put("strange`name", new TypedValue(TypedValue.Type.STRING, "a\"b\\c\n"));
        values.put("duration", new TypedValue(TypedValue.Type.DURATION, "1,2,3"));
        ArtifactDescriptor vertex = new ArtifactDescriptor(Paths.get("vertex.csv"), "space",
                MigrationRecord.Kind.VERTEX, "tag`name", null, "csv");
        String vertexNgql = NgqlRenderer.render(vertex, MigrationRecord.vertex(
                new TypedValue(TypedValue.Type.STRING, "vid"), values));
        Assert.assertTrue(vertexNgql.contains("INSERT VERTEX `tag``name`"));
        Assert.assertTrue(vertexNgql.contains("`strange``name`"));
        Assert.assertTrue(vertexNgql.contains("duration({months:1,seconds:2,microseconds:3})"));

        ArtifactDescriptor edge = new ArtifactDescriptor(Paths.get("edge.csv"), "space",
                MigrationRecord.Kind.EDGE, "edge", null, "csv");
        String edgeNgql = NgqlRenderer.render(edge, MigrationRecord.edge(
                new TypedValue(TypedValue.Type.INTEGER, "1"),
                new TypedValue(TypedValue.Type.INTEGER, "2"), -9L, values));
        Assert.assertTrue(edgeNgql.contains("VALUES 1->2@-9:" ));
    }

    @Test
    public void rendersOneMultiValueStatementPerBatch() throws Exception {
        Map<String, TypedValue> firstValues = new LinkedHashMap<String, TypedValue>();
        firstValues.put("name", new TypedValue(TypedValue.Type.STRING, "first"));
        firstValues.put("score", new TypedValue(TypedValue.Type.INTEGER, "1"));
        Map<String, TypedValue> secondValues = new LinkedHashMap<String, TypedValue>();
        secondValues.put("score", new TypedValue(TypedValue.Type.INTEGER, "2"));
        secondValues.put("name", new TypedValue(TypedValue.Type.STRING, "second"));
        ArtifactDescriptor vertex = new ArtifactDescriptor(Paths.get("vertex.csv"), "space",
                MigrationRecord.Kind.VERTEX, "tag", null, "csv");

        String nGql = NgqlRenderer.renderBatch(vertex, Arrays.asList(
                MigrationRecord.vertex(new TypedValue(TypedValue.Type.INTEGER, "1"), firstValues),
                MigrationRecord.vertex(new TypedValue(TypedValue.Type.INTEGER, "2"), secondValues)));

        Assert.assertEquals("INSERT VERTEX `tag`(`name`,`score`) VALUES 1:(\"first\",1),2:(\"second\",2)",
                nGql);
    }

    @Test(expected = MigrationException.class)
    public void rejectsBatchWithDifferentPropertyColumns() throws Exception {
        Map<String, TypedValue> first = new LinkedHashMap<String, TypedValue>();
        first.put("name", new TypedValue(TypedValue.Type.STRING, "first"));
        Map<String, TypedValue> second = new LinkedHashMap<String, TypedValue>();
        second.put("other", new TypedValue(TypedValue.Type.STRING, "second"));
        ArtifactDescriptor vertex = new ArtifactDescriptor(Paths.get("vertex.csv"), "space",
                MigrationRecord.Kind.VERTEX, "tag", null, "csv");

        NgqlRenderer.renderBatch(vertex, Arrays.asList(
                MigrationRecord.vertex(new TypedValue(TypedValue.Type.INTEGER, "1"), first),
                MigrationRecord.vertex(new TypedValue(TypedValue.Type.INTEGER, "2"), second)));
    }
}
