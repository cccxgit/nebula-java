package com.vesoft.nebula.migration;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class IntegrityTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void signedArtifactRejectsTampering() throws Exception {
        Path artifact = temporaryFolder.newFile("rows.csv").toPath();
        Files.write(artifact, "first\n".getBytes(StandardCharsets.UTF_8));
        Integrity.markCompleted(artifact, "test-key");
        Integrity.verifyCompleted(artifact, "test-key", ExitCode.IMPORT_FAILED);

        Files.write(artifact, "second\n".getBytes(StandardCharsets.UTF_8));
        try {
            Integrity.verifyCompleted(artifact, "test-key", ExitCode.IMPORT_FAILED);
            Assert.fail("tampered artifact must not verify");
        } catch (MigrationException expected) {
            Assert.assertEquals(ExitCode.IMPORT_FAILED, expected.exitCode());
        }
    }

    @Test
    public void signatureBindsRecoveryMetadata() throws Exception {
        Path artifact = temporaryFolder.newFile("rows.jsonl").toPath();
        Files.write(artifact, "record\n".getBytes(StandardCharsets.UTF_8));
        Map<String, String> metadata = new LinkedHashMap<String, String>();
        metadata.put("row.count", "1");
        metadata.put("canonical.digest", "digest");
        Integrity.markCompleted(artifact, "test-key", metadata);
        Assert.assertEquals(metadata, Integrity.completionMetadata(artifact, "test-key",
                ExitCode.IMPORT_FAILED));

        Properties signature = new Properties();
        try (java.io.InputStream input = Files.newInputStream(Integrity.signaturePath(artifact))) {
            signature.load(input);
        }
        signature.setProperty("metadata.row.count", "2");
        try (java.io.OutputStream output = Files.newOutputStream(Integrity.signaturePath(artifact))) {
            signature.store(output, "tampered");
        }
        try {
            Integrity.verifyCompleted(artifact, "test-key", ExitCode.IMPORT_FAILED);
            Assert.fail("tampered signature metadata must not verify");
        } catch (MigrationException expected) {
            Assert.assertEquals(ExitCode.IMPORT_FAILED, expected.exitCode());
        }
    }
}
