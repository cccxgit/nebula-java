package com.vesoft.nebula.migration;

import java.io.OutputStream;
import java.nio.file.Path;
import java.util.Properties;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class MigrationConfigTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void rejectsNonNumericValueAsUsageError() throws Exception {
        Path config = temporaryFolder.newFile("migration.properties").toPath();
        Properties properties = ManifestCheckpointTest.requiredProperties(temporaryFolder.newFolder("work").toPath());
        properties.setProperty("export.scan.limit", "not-a-number");
        try (OutputStream output = java.nio.file.Files.newOutputStream(config)) {
            properties.store(output, "test");
        }
        try {
            MigrationConfig.load(config.toString());
            Assert.fail("invalid numeric value must be rejected");
        } catch (MigrationException expected) {
            Assert.assertEquals(ExitCode.USAGE, expected.exitCode());
        }
    }

    @Test
    public void rejectsArtifactConcurrencyAboveGraphPoolLimit() throws Exception {
        Path config = temporaryFolder.newFile("artifact-concurrency.properties").toPath();
        Properties properties = ManifestCheckpointTest.requiredProperties(temporaryFolder.newFolder("work2").toPath());
        properties.setProperty("import.artifact.concurrency", "17");
        try (OutputStream output = java.nio.file.Files.newOutputStream(config)) {
            properties.store(output, "test");
        }
        try {
            MigrationConfig.load(config.toString());
            Assert.fail("artifact concurrency above graph pool limit must be rejected");
        } catch (MigrationException expected) {
            Assert.assertEquals(ExitCode.USAGE, expected.exitCode());
        }
    }
}
