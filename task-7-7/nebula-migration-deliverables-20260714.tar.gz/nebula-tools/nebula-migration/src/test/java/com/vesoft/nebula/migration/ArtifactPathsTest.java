package com.vesoft.nebula.migration;

import org.junit.Assert;
import org.junit.Test;

public class ArtifactPathsTest {
    @Test
    public void preservesSafeNamesAndEncodesUnsafeNamesWithoutPathSeparators() {
        Assert.assertEquals("player_01", ArtifactPaths.component("player_01"));
        String encoded = ArtifactPaths.component("../tag/with space");
        Assert.assertTrue(encoded.startsWith("~"));
        Assert.assertFalse(encoded.contains("/"));
        Assert.assertFalse(encoded.contains("\\"));
        Assert.assertNotEquals(ArtifactPaths.component("~Li4vdGFnL3dpdGggc3BhY2U"), encoded);
    }
}
