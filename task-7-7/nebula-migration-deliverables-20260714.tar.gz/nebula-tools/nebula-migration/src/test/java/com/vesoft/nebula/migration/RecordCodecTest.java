package com.vesoft.nebula.migration;

import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;

public class RecordCodecTest {
    @Test
    public void csvAndJsonRoundTripPreserveTypedValues() throws Exception {
        Map<String, TypedValue> properties = new LinkedHashMap<String, TypedValue>();
        properties.put("empty", new TypedValue(TypedValue.Type.STRING, ""));
        properties.put("escaped", new TypedValue(TypedValue.Type.STRING,
                "comma, quote \" newline\nslash\\ and 中文"));
        properties.put("nil", new TypedValue(TypedValue.Type.NULL, ""));
        properties.put("float", new TypedValue(TypedValue.Type.DOUBLE, "-1.25E-7"));
        properties.put("date", new TypedValue(TypedValue.Type.DATE, "2026-07-10"));
        properties.put("datetime", new TypedValue(TypedValue.Type.DATETIME,
                "2026-07-10T12:34:56.123456"));
        properties.put("duration", new TypedValue(TypedValue.Type.DURATION, "3,-15,42"));
        MigrationRecord source = MigrationRecord.edge(
                new TypedValue(TypedValue.Type.STRING, "src,\"\\\n"),
                new TypedValue(TypedValue.Type.INTEGER, "99"), -7L, properties);

        assertSame(source, RecordCodec.fromCsv(RecordCodec.toCsv(source)));
        assertSame(source, RecordCodec.fromJson(RecordCodec.toJson(source)));
    }

    @Test
    public void durationRendersAsNebulaLiteral() throws Exception {
        Assert.assertEquals("duration({months:3,seconds:-15,microseconds:42})",
                new TypedValue(TypedValue.Type.DURATION, "3,-15,42").ngqlLiteral());
    }

    private static void assertSame(MigrationRecord expected, MigrationRecord actual) {
        Assert.assertEquals(expected.kind(), actual.kind());
        Assert.assertEquals(expected.firstKey().encode(), actual.firstKey().encode());
        Assert.assertEquals(expected.secondKey().encode(), actual.secondKey().encode());
        Assert.assertEquals(expected.rank(), actual.rank());
        Assert.assertEquals(expected.canonical("edge_label"), actual.canonical("edge_label"));
    }
}
