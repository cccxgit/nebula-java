package com.vesoft.nebula.migration;

import com.vesoft.nebula.client.graph.NebulaPoolConfig;
import com.vesoft.nebula.client.graph.data.HostAddress;
import com.vesoft.nebula.client.graph.data.ResultSet;
import com.vesoft.nebula.client.graph.net.NebulaPool;
import com.vesoft.nebula.client.graph.net.Session;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/** Test-only deterministic data loader for the local 50M migration benchmark. */
public final class PerformanceFixtureLoader {
    private static final String[] SPACES = {"perf_0", "perf_1", "perf_2"};

    private PerformanceFixtureLoader() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 6) {
            throw new IllegalArgumentException("Usage: PerformanceFixtureLoader <graph-addresses> <user> "
                    + "<password> <records-per-space> <batch-size> <workers-per-space>");
        }
        long recordsPerSpace = Long.parseLong(args[3]);
        int batchSize = Integer.parseInt(args[4]);
        int workersPerSpace = Integer.parseInt(args[5]);
        if (recordsPerSpace <= 0 || batchSize <= 0 || workersPerSpace <= 0) {
            throw new IllegalArgumentException("records, batch size and workers must be positive");
        }

        NebulaPool pool = new NebulaPool();
        NebulaPoolConfig config = new NebulaPoolConfig();
        config.setMinConnSize(0);
        config.setMaxConnSize(SPACES.length * workersPerSpace + 4);
        if (!pool.init(addresses(args[0]), config)) {
            throw new IllegalStateException("Cannot initialize NebulaPool");
        }
        try {
            load(pool, args[1], args[2], recordsPerSpace, batchSize, workersPerSpace, false);
            load(pool, args[1], args[2], recordsPerSpace, batchSize, workersPerSpace, true);
        } finally {
            pool.close();
        }
    }

    private static void load(final NebulaPool pool, final String user, final String password,
                             final long recordsPerSpace, final int batchSize,
                             final int workersPerSpace, final boolean edges) throws Exception {
        final long total = recordsPerSpace * SPACES.length;
        final AtomicLong completed = new AtomicLong();
        final long started = System.nanoTime();
        final ExecutorService workers = Executors.newFixedThreadPool(SPACES.length * workersPerSpace);
        final ScheduledExecutorService reporter = Executors.newSingleThreadScheduledExecutor();
        reporter.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                long rows = completed.get();
                double seconds = (System.nanoTime() - started) / 1_000_000_000.0;
                System.out.println("phase=" + (edges ? "edges" : "vertices") + " completed=" + rows
                        + "/" + total + " rateRowsPerSec=" + (long) (rows / Math.max(seconds, 0.001)));
            }
        }, 10L, 10L, TimeUnit.SECONDS);
        try {
            List<Future<Void>> futures = new ArrayList<Future<Void>>();
            for (int spaceIndex = 0; spaceIndex < SPACES.length; spaceIndex++) {
                for (int worker = 0; worker < workersPerSpace; worker++) {
                    final String space = SPACES[spaceIndex];
                    final long start = 1L + worker * recordsPerSpace / workersPerSpace;
                    final long end = (worker + 1L) * recordsPerSpace / workersPerSpace;
                    futures.add(workers.submit(new Callable<Void>() {
                        @Override
                        public Void call() throws Exception {
                            loadRange(pool, user, password, space, start, end, recordsPerSpace,
                                    batchSize, edges, completed);
                            return null;
                        }
                    }));
                }
            }
            for (Future<Void> future : futures) {
                future.get();
            }
        } finally {
            reporter.shutdownNow();
            workers.shutdownNow();
        }
        double seconds = (System.nanoTime() - started) / 1_000_000_000.0;
        System.out.println("phase=" + (edges ? "edges" : "vertices") + " completed=" + completed.get()
                + " durationSeconds=" + String.format(java.util.Locale.ROOT, "%.3f", seconds)
                + " rateRowsPerSec=" + (long) (completed.get() / Math.max(seconds, 0.001)));
    }

    private static void loadRange(NebulaPool pool, String user, String password, String space,
                                  long start, long end, long recordsPerSpace, int batchSize,
                                  boolean edges, AtomicLong completed) throws Exception {
        Session session = pool.getSession(user, password, true);
        if (session == null) {
            throw new IllegalStateException("Cannot open graph session");
        }
        try {
            execute(session, "USE `" + space + "`");
            long current = start;
            while (current <= end) {
                long last = Math.min(end, current + batchSize - 1L);
                execute(session, edges ? edgeStatement(current, last, recordsPerSpace)
                        : vertexStatement(current, last));
                completed.addAndGet(last - current + 1L);
                current = last + 1L;
            }
        } finally {
            session.release();
        }
    }

    private static String vertexStatement(long first, long last) {
        StringBuilder statement = new StringBuilder("INSERT VERTEX `load_tag`(`name`,`value`,`active`,`score`,`created`) VALUES ");
        for (long id = first; id <= last; id++) {
            if (id > first) {
                statement.append(',');
            }
            statement.append(id).append(":(\"node-").append(id)
                    .append("\",").append(id).append(',').append((id & 1L) == 0L ? "true" : "false")
                    .append(",1.25,datetime(\"2024-01-02T03:04:05\"))");
        }
        return statement.toString();
    }

    private static String edgeStatement(long first, long last, long recordsPerSpace) {
        StringBuilder statement = new StringBuilder("INSERT EDGE `load_edge`(`weight`,`code`) VALUES ");
        for (long id = first; id <= last; id++) {
            if (id > first) {
                statement.append(',');
            }
            long next = id == recordsPerSpace ? 1L : id + 1L;
            statement.append(id).append("->").append(next).append("@0:(1.5,\"edge-")
                    .append(id).append("\")");
        }
        return statement.toString();
    }

    private static void execute(Session session, String statement) throws Exception {
        ResultSet result = session.execute(statement);
        if (!result.isSucceeded()) {
            throw new IllegalStateException("nGQL failed [" + result.getErrorCode() + "]: "
                    + result.getErrorMessage());
        }
    }

    private static List<HostAddress> addresses(String raw) {
        if (raw.trim().isEmpty()) {
            return Collections.emptyList();
        }
        List<HostAddress> result = new ArrayList<HostAddress>();
        for (String item : raw.split(",")) {
            int separator = item.lastIndexOf(':');
            if (separator <= 0 || separator == item.length() - 1) {
                throw new IllegalArgumentException("Invalid graph address: " + item);
            }
            result.add(new HostAddress(item.substring(0, separator),
                    Integer.parseInt(item.substring(separator + 1))));
        }
        return result;
    }
}
