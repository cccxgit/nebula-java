package com.vesoft.nebula.migration;

import org.junit.Assert;
import org.junit.Test;

public class MetadataServiceTest {
    @Test
    public void detectsOnlyEnabledTtlDuration() {
        Assert.assertFalse(MetadataService.hasActiveTtl(
                "CREATE TAG `load_tag`(name string) ttl_duration = 0, ttl_col = \"\""));
        Assert.assertTrue(MetadataService.hasActiveTtl(
                "CREATE TAG `person`(expires_at timestamp) ttl_duration = 3600, ttl_col = \"expires_at\""));
    }
}
