package com.vesoft.nebula.migration;

import org.junit.Assert;
import org.junit.Test;

public class CanonicalAccumulatorTest {
    @Test
    public void orderAndMergeDoNotChangeDigest() {
        CanonicalAccumulator left = new CanonicalAccumulator();
        left.add("a");
        left.add("b");
        left.add("c");

        CanonicalAccumulator right = new CanonicalAccumulator();
        right.add("c");
        right.add("a");
        right.add("b");

        CanonicalAccumulator splitA = new CanonicalAccumulator();
        splitA.add("a");
        CanonicalAccumulator splitB = new CanonicalAccumulator();
        splitB.add("b");
        splitB.add("c");
        splitA.merge(splitB);

        Assert.assertEquals(left.digest(), right.digest());
        Assert.assertEquals(left.digest(), splitA.digest());
        Assert.assertEquals(3L, splitA.count());
    }
}
