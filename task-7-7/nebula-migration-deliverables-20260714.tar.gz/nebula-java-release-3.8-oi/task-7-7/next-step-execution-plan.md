# Nebula Graph 跨集群搬迁下一阶段执行计划

> 状态：待评审后进入代码开发。
> 适用范围：Nebula Graph 3.6 同版本、一次性全量迁移、Java + Shell + nebula-java、源/目标均为三实例 graph/meta/storage 集群。

## 1. 当前基线

以下软件实现设计已经完成，当前尚未创建迁移工具业务代码或自动化测试代码：

| 范围 | 设计文档 |
| --- | --- |
| 工程、连接、冻结、元数据、文件 | `model_design/01-05-*.md` |
| 导出、状态、导入、校验、TTL | `model_design/06-10-*.md` |
| 测试、故障注入、性能验收 | `model_design/11-test-acceptance-software-design.md` |

已有 [development-task-breakdown.md](development-task-breakdown.md) 给出工具侧任务清单。本文件补充实际启动开发时的关键路径、阻断条件、并行边界和每个阶段的退出标准。

## 2. 首要结论

生产可用迁移的前提不是导出工具，而是 graphd 数据静止能力。

`/home/sch/nebula/nebula-3.6-io` 是本需求 Nebula Graph 3.6 的服务端实现、构建和测试基线。开始 graphd 改造前，必须固定该目录对应的分支、commit、构建方式和三实例测试环境。当前 nebula-java 3.8.4 还必须先通过对 Nebula Graph 3.6 的协议/API 冒烟验证；若不通过，改用兼容的 nebula-java 版本。

迁移工具基础设施可与 graphd 冻结改造并行开发；任何连接真实源数据的 `export` 集成测试和生产使用都必须等待冻结能力通过三 graphd 验证。

## 3. 关键路径

```mermaid
flowchart LR
    B0[W0: 3.6 基线与契约定版] --> F1[W1: graphd 数据静止]
    B0 --> T1[W2: 工具基础设施]
    F1 --> P1[W3: Precheck/TTL/元数据]
    T1 --> P1
    P1 --> E1[W4: CSV + label 导出]
    E1 --> I1[W5: 默认导入与恢复]
    I1 --> V1[W6: 默认校验闭环]
    V1 --> X1[W7: partition/JSON/full checksum]
    X1 --> A1[W8: 故障注入、50M 性能、交付]
```

关键路径是 `W0 -> W1 -> W3 -> W4 -> W5 -> W6 -> W7 -> W8`。`W2` 不阻塞 W1，但会阻塞 W3 之后的全部工具功能。

## 4. W0：实现基线与契约定版

### 目标

固定编译、运行、接口和默认参数，确保 graphd 源码、服务端二进制和测试集群均为 3.6，并显式验证 nebula-java 3.8.4 与该服务端版本的兼容性。

### 任务

| ID | 工作项 | 产物 | 完成条件 |
| --- | --- | --- | --- |
| W0-01 | 固定 Nebula Graph 3.6 服务端源码、分支和 commit | `server-baseline.md` | 可在固定 commit 构建 graphd 和运行相关 gtest。 |
| W0-02 | 验证 nebula-java 3.8.4 与 Nebula Graph 3.6 的客户端兼容性 | `client-server-compatibility.md` | 覆盖 `NebulaPool`、Session nGQL、`MetaClient`、`StorageClient.scanVertex/scanEdge` 和 nGQL `INSERT`；失败时确定兼容 nebula-java 版本。 |
| W0-03 | 定版冻结外部契约 | API/配置契约 | 固定 `enable_graph_mutation`、`GET /migration_freeze_status` JSON、错误前缀 `MUTATION_FROZEN`、允许/拒绝语句集合。 |
| W0-04 | 定版工具新增静态参数 | `migration.properties.example` 草案 | 明确导出 retry、writer queue、import worker、最大 nGQL 字节数的默认值和范围。 |
| W0-05 | 确认测试集群与凭据注入方式 | `test-environment.md` | 源/目标各 3 graphd + 3 metad + 3 storaged 可供集成测试。 |

### 退出标准

1. 所有后续 graphd 实现均以已固定的 Nebula Graph 3.6 源码为修改对象。
2. nebula-java 与 Nebula Graph 3.6 的兼容性结果已归档；未通过时已切换到兼容客户端版本。
3. 接口、默认值和错误语义通过设计评审。

## 5. W1：graphd 数据静止能力

详细设计见 [03-precheck-data-freeze-software-design.md](model_design/03-precheck-data-freeze-software-design.md)。这是 Nebula Graph 服务端工作，不属于 nebula-java `migration` Maven 模块。

### 实现任务

| ID | 修改区域 | 主要工作 | 单元/集成验证 |
| --- | --- | --- | --- |
| W1-01 | GraphFlags、gflags 注册 | 增加 `enable_graph_mutation=true`，登记为 mutable；启动参数和运行时配置语义一致。 | gflag 注册、`UPDATE CONFIGS`、错误值拒绝。 |
| W1-02 | `MutationFreezeManager` | 维护 writable、epoch、active mutation count；冻结时先关闭入口再等待 in-flight drain。 | 并发 enter/freeze/release，无计数泄漏和竞态。 |
| W1-03 | `Validator::validate()` | 在 `validateImpl()` 后按 `Sentence::Kind` 调用 guard；不改 parser grammar，不依赖授权开关。 | DML、DDL、ACL、配置、Admin Job 分类表测试。 |
| W1-04 | `QueryContext/QueryInstance` | 保存并在全部完成/异常路径释放 mutation lease。 | 正常执行、validate 失败、executor 异常、取消/析构均归零。 |
| W1-05 | Admin Job 和配置例外 | 允许 SHOW/STOP JOB；拒绝 ADD/RECOVER；只允许冻结开关自身的配置变更。 | COMPACT、BALANCE、REBUILD、INGEST、RECOVER、SHOW、STOP 的组合测试。 |
| W1-06 | WebService | 新增只读 `/migration_freeze_status`，逐 graphd 返回开关、in-flight 数和状态。 | 三 graphd 中任一未冻结时状态不通过。 |
| W1-07 | 服务端回归测试 | 扩展 parser、validator、ACL、Admin Job、GraphFlags 测试。 | 既有非冻结行为不回归。 |

### 退出标准

1. `enable_graph_mutation=false` 后，新 graph 写语句返回 `MUTATION_FROZEN`。
2. 冻结状态只在 `activeMutationCount=0` 时显示 `FROZEN`。
3. 三 graphd 状态均为 `FROZEN` 才允许工具 precheck 通过。
4. 读取、`SHOW JOBS`、`STOP JOB` 不被误阻断。
5. 直接 storage 写入者若存在，能被运维清单识别并阻断生产迁移。

## 6. W2：迁移工具基础设施

详细设计见 [01](model_design/01-engineering-cli-config-logging-software-design.md)、[02](model_design/02-cluster-connector-protocol-adapter-software-design.md)、[05](model_design/05-file-format-integrity-software-design.md)、[07](model_design/07-manifest-checkpoint-report-software-design.md)。此阶段可以与 W1 并行。

### 实现顺序

| ID | 工作项 | 主要产物 | 退出标准 |
| --- | --- | --- | --- |
| W2-01 | 新增 `migration` Maven 模块 | 父 POM、`migration/pom.xml`、可执行 jar 打包方式 | Java 8 构建通过，未修改 client public API。 |
| W2-02 | CLI、Shell、配置、日志 | 五个命令、`.properties` loader、log4j、退出码、workspace lock | 无效配置不连接集群；同目录并发命令被锁阻断。 |
| W2-03 | graph/meta/storage 适配器 | `ClusterClients`、`GraphClient`、`MetaClientAdapter`、`StorageClientAdapter` | 多地址连接、认证、异常分类、资源关闭通过测试。 |
| W2-04 | 文件与 typed value 契约 | `MigrationRow`、CSV/JSON codec、canonical encoder、nGQL literal renderer | NULL/空字符串、VID、浮点、时间和复杂转义往返正确。 |
| W2-05 | 完整性与原子产物 | SHA-256、HMAC、tmp/rename、completion checker | 未签名/篡改文件绝不被视为完成。 |
| W2-06 | 任务状态与报告 | manifest、checkpoint、failure JSONL、三类 report、单写者 event queue | 中断恢复和 manifest backup 测试通过。 |

### 退出标准

1. `precheck/export/import/verify/retry-failed` 命令均可启动。
2. 工具可以无 Nebula 集群地完成配置、文件、状态、签名和报告单元测试。
3. 仅一个 `StorageClient` 的连接模型和每 worker 独占 graph Session 的模型被代码固定。

## 7. W3：Precheck、TTL 与元数据

详细设计见 [03](model_design/03-precheck-data-freeze-software-design.md)、[04](model_design/04-metadata-snapshot-rebuild-software-design.md)、[10](model_design/10-ttl-risk-handling-software-design.md)。W3 依赖 W1 的冻结 HTTP 接口和 W2 的连接/状态基础设施。

| ID | 工作项 | 产物 | 退出标准 |
| --- | --- | --- | --- |
| W3-01 | 源/目标连通与版本检查 | `ClusterProbe`、结构化 `CheckResult` | 版本非 3.6、连接失败、meta/storage 不可读均 FAIL。 |
| W3-02 | 冻结与后台 job 检查 | `FreezeStatusChecker`、`JobStatusChecker` | 任一 graphd 非 FROZEN 或变更 job 为 RUNNING/QUEUE 时阻断。 |
| W3-03 | 目标空集群检查 | `TargetClusterChecker` | 有业务 space 或非 root 用户时 import 阻断且不修改目标。 |
| W3-04 | TTL probe | `TtlSchemaProbe`、warning 模型 | 从 `SchemaProp` 识别 TTL，写 log4j/manifest/report，不阻断。 |
| W3-05 | 元数据快照 | `MetadataSnapshot`、`meta/*.json` | 完整保存 space/schema/native index/非 root 用户/space role；root 只审计。 |
| W3-06 | 元数据导入 | schema/user/role plan 与执行器 | 先 space、schema、index，后 user/role；失败退出且不自动清理。 |

### 退出标准

可对小规模三实例源/目标执行 `precheck` 和 metadata-only 流程；报告可解释 TTL、root、全文索引排除和扩展权限警告。

## 8. W4：默认导出闭环，CSV + label

详细设计见 [06-storage-data-export-software-design.md](model_design/06-storage-data-export-software-design.md)。这是第一个可交付数据链路。

### 实现任务

| ID | 工作项 | 关键约束 | 退出标准 |
| --- | --- | --- | --- |
| W4-01 | ExportPlanner | 按 space/kind/label/partition 稳定排序 | 每个 tag/edge 和 partition 均有计划项。 |
| W4-02 | partition scan task | 指定 partition 调用 scan；`allowPartSuccess=false`、`allowReadFromFollower=false` | 多 page cursor 被完整消费；任一 page 非全成功则失败。 |
| W4-03 | RowMapper | 使用 snapshot schema 列序，不遍历 property map | VID、edge rank、NULL、浮点、时间类型无变形。 |
| W4-04 | label writer | 多 partition worker + 有界队列 + 单 writer | 无无界内存增长；行顺序不作为校验依据。 |
| W4-05 | 文件完成与恢复 | `.tmp -> sha256 -> sig -> manifest COMPLETED` | 无签名 label 文件整体重导；已完成文件跳过。 |
| W4-06 | 导出统计 | per partition count/sample/可选 digest | report 维度满足 space/tag/edge/partition。 |

### 退出标准

小规模数据可导出 CSV label 文件、metadata、manifest、checksum、signature 与 export report；kill 导出后不会把半文件误判为完成。

## 9. W5：默认导入与失败恢复

详细设计见 [08-graph-data-import-retry-software-design.md](model_design/08-graph-data-import-retry-software-design.md)。

| ID | 工作项 | 关键约束 | 退出标准 |
| --- | --- | --- | --- |
| W5-01 | import 前完整性检查 | 全部 artifact checksum/signature/manifest 通过 | 篡改或缺失 sidecar 时禁止导入。 |
| W5-02 | metadata 重建编排 | 复用 W3 schema/user/role importer | schema/index 失败退出码 6，用户手动清理。 |
| W5-03 | CSV 流式 reader 与批次 assembler | logical record checkpoint，不依赖物理行号 | 带换行字符串可正确恢复。 |
| W5-04 | nGQL renderer | `INSERT VERTEX/EDGE`，完整标识符和值转义 | 两类 VID、edge rank、NULL/空字符串/浮点/时间正确。 |
| W5-05 | batch executor | 默认 500 行、3 次、1000ms | 连接错误与语义错误走不同策略。 |
| W5-06 | 单行降级与 failure record | 批次失败后逐行处理 | 成功行 checkpoint，最终失败行落盘且任务失败。 |
| W5-07 | resume/retry-failed | 幂等重放、失败记录重试 | checkpoint 落后不造成错误覆盖；历史失败保留。 |

### 退出标准

CSV label 导出物可导入空目标；中断可恢复；最终失败不会被跳过；目标不为空或 metadata 失败时不自动 DROP。

## 10. W6：默认校验闭环

详细设计见 [09-verification-engine-software-design.md](model_design/09-verification-engine-software-design.md)。

| ID | 工作项 | 关键约束 | 退出标准 |
| --- | --- | --- | --- |
| W6-01 | 目标 partition scanner | 用 storage scan，一次扫描同时计数和查样本 | 不额外全量缓存 partition。 |
| W6-02 | count verifier | source/target 在每个 partition 精确比较 | 任一差异有报告证据并 FAIL。 |
| W6-03 | deterministic sample | hash 抽样；每个非空 partition 至少一个样本 | count 相同、属性不同可 FAIL。 |
| W6-04 | verify report/checkpoint | 每个校验单位独立状态 | 未启用 full checksum 时固定写“未证明全量完全一致”。 |

### 退出标准

默认链路完成 `export -> import -> verify`；可检测 count 差异和 sample 属性差异，并生成按 space/tag/edge/partition 的报告。

## 11. W7：增强能力与上线门槛

| 子项 | 内容 | 开始条件 | 上线条件 |
| --- | --- | --- | --- |
| partition 布局 | 每个 partition 独立文件、签名和恢复 | W4/W5/W6 默认链路通过 | 中断时仅重导/重导入未完成 partition。 |
| JSON Lines | typed JSON codec 与配置切换 | CSV typed value 测试通过 | JSON 与 CSV 同一数据集的 canonical hash 一致。 |
| full checksum | canonical row stream digest | W6 通过 | 在真实 3.6 集群、不同 compaction 状态下 scan 顺序稳定；否则改为外部排序/Merkle 方案。 |
| retry-failed | 单独失败记录重试命令 | W5 failure record 完成 | 历史 failure 不丢失，重试结果可审计。 |

`segment` 布局明确不进入本期代码开发。

## 12. W8：集成、故障注入与性能验收

详细测试矩阵见 [11-test-acceptance-software-design.md](model_design/11-test-acceptance-software-design.md)。

### 分阶段验收

| 阶段 | 数据规模 | 必测内容 | 通过条件 |
| --- | --- | --- | --- |
| 单元/组件 | 内存与临时文件 | 编码、签名、状态机、nGQL、错误分类 | 每次构建通过。 |
| 小规模集成 | 多 space/tag/edge | 冻结、metadata、CSV-label、导入、count/sample | 默认闭环通过。 |
| 故障注入 | 小规模 | kill export/import、删 sig、文件篡改、graph/meta/storage 重启、schema 失败 | 可安全恢复或明确失败，不误报完成。 |
| 增强集成 | 小/中规模 | partition、JSON、full checksum、retry-failed、TTL 时序 | 所有报告和状态符合设计。 |
| 性能 | 约 5000 万点边 | 四种格式/布局组合、资源与恢复耗时 | 无 OOM，形成 CPU/内存/磁盘/网络/吞吐基线。 |

发布候选必须归档：冻结状态、precheck/export/import/verify 报告、故障注入记录、环境清单、测试数据 manifest 与性能报告。

## 13. 并行分工建议

| 工作流 | 可并行工作 | 等待条件 |
| --- | --- | --- |
| 服务端流 | W0-01/02 后的 W1 全部任务 | 需要 3.6 源码与服务端测试环境。 |
| 工具基础流 | W2-01 到 W2-06 | 可与 W1 并行，不依赖冻结接口实现。 |
| 集群控制流 | W3-01 到 W3-04 | 依赖 W1 status endpoint 和 W2 adapter。 |
| 元数据/导出流 | W3-05/06 与 W4 | 依赖 W3 precheck，导出集成测试依赖冻结通过。 |
| 导入/校验流 | W5、W6 | 依赖稳定导出 artifact 契约。 |
| 增强/验收流 | W7、W8 | 依赖默认闭环与小规模故障测试通过。 |

建议把 W1 与 W2 分配给不同开发者；其余任务按 artifact 契约串行推进，避免 CSV/manifest/canonical 编码在导出、导入和校验中出现多套实现。

## 14. 禁止跨越的门槛

1. 未固定 3.6 服务端源码前，不提交 graphd 冻结生产补丁。
2. 未完成 nebula-java 与 Nebula Graph 3.6 的兼容性冒烟验证前，不执行真实集群工具集成测试。
3. 未完成 W1 三 graphd FROZEN 验证前，不执行真实源集群 export。
4. 未完成 artifact 完成语义前，不实现“跳过已完成文件”或导入恢复。
5. 未完成 target 空集群 precheck 前，不执行 schema 或数据导入。
6. 未在真实 3.6 环境验证 scan 顺序稳定前，不宣称 full checksum 已提供全量一致性证明。
7. 任何失败路径均不得自动 `DROP SPACE`、`DROP USER`、强推 Git 历史或隐藏失败记录。

## 15. 第一批实际编码任务

评审通过后，第一批建议只启动以下任务：

1. W0-01 到 W0-04：固定 3.6 源码、完成客户端兼容性验证并定版冻结/配置契约。
2. W1-01 到 W1-03：gflag、manager、Validator guard 与对应 gtest 骨架。
3. W2-01 到 W2-03：`migration` Maven 模块、CLI/properties/log4j、cluster adapter。
4. W2-04 到 W2-06：typed value、文件完整性、manifest/checkpoint/report。

第一批结束时不要求可迁移生产数据，但必须具备两个可验证成果：graphd 可拒绝冻结后的 DML，以及迁移工具可在本地完成一个受签名保护的模拟 artifact 生命周期。之后再启动 W3 和真实集成环境。
