# Nebula Graph 跨集群搬迁开发任务拆分

本文基于 `migration-design.md` 拆分开发任务，用于后续排期、分工、代码开发和测试验收。

## 1. 拆分原则

1. 先交付可闭环的最小链路，再补齐格式、布局、恢复和增强校验。
2. 优先实现默认路径：CSV + label 布局 + 数量校验 + 抽样校验。
3. `partition` 布局、JSON、全量 checksum 作为增强能力进入后续里程碑。
4. `segment` 布局仅保留设计，不进入本期代码开发。
5. 不自动冻结源集群，不自动清理目标集群。
6. 不迁移 job、全文索引、配置、快照、日志、root 密码、root 权限变更。

## 2. 工程落地建议

推荐新增独立 Maven 模块：

```text
migration/
  pom.xml
  src/main/java/com/vesoft/nebula/migration/
  src/main/resources/log4j.properties
  src/main/bin/migration-precheck.sh
  src/main/bin/migration-export.sh
  src/main/bin/migration-import.sh
  src/main/bin/migration-verify.sh
  src/main/bin/migration-retry-failed.sh
  src/test/java/com/vesoft/nebula/migration/
```

建议模块依赖：

1. `migration` 依赖本仓库 `client` 模块。
2. 不新增运行时三方依赖，优先使用 JDK、现有 nebula-java 类型和现有日志体系。
3. 如必须引入打包插件，仅作为构建插件，不扩大运行时依赖范围。

建议包结构：

```text
com.vesoft.nebula.migration.cli
com.vesoft.nebula.migration.config
com.vesoft.nebula.migration.connect
com.vesoft.nebula.migration.meta
com.vesoft.nebula.migration.exporter
com.vesoft.nebula.migration.importer
com.vesoft.nebula.migration.verify
com.vesoft.nebula.migration.file
com.vesoft.nebula.migration.manifest
com.vesoft.nebula.migration.report
com.vesoft.nebula.migration.retry
com.vesoft.nebula.migration.model
```

## 3. 里程碑

| 里程碑 | 目标 | 主要产物 | 退出标准 |
| --- | --- | --- | --- |
| M0 工程骨架 | 建立可运行 CLI 和基础模块 | Maven 模块、Shell 命令、配置加载、日志 | `precheck/export/import/verify/retry-failed` 命令可启动并读取配置 |
| M1 基础设施 | 支撑任务状态、文件完成语义和报告 | manifest、checkpoint、report、checksum、signature | 单元测试覆盖状态流转、sha256、HMAC、报告写入 |
| M2 元数据与预检查 | 完成源/目标检查和元数据导出 | precheck、schema/user/role 导出、TTL warning | 可输出 `meta/*.json` 和 `export-report` 中的 TTL/root/权限告警 |
| M3 默认导出链路 | 完成 CSV + label 布局导出 | Storage scan、CSV writer、label resume | 可导出多 space/tag/edge，生成 `.sha256`、`.sig`、manifest |
| M4 默认导入链路 | 完成 schema/index/user/role/data 导入 | schema 重建、批量 INSERT、重试、失败落盘 | CSV label 导出的数据可导入空目标集群，失败记录可复现 |
| M5 默认校验闭环 | 完成数量校验和抽样校验 | verify count、deterministic sample | 迁移后可生成按 space/tag/edge/partition 的校验报告 |
| M6 增强能力 | 补齐 partition、JSON、全量 checksum | partition layout、JSON Lines、canonical checksum | 两种布局、两种格式、可选全量 checksum 均通过集成测试 |
| M7 商用化验证 | 完成可靠性、性能和文档 | 故障注入、性能报告、用户手册 | 5000 万级测试通过，恢复、失败重试和报告满足验收 |

## 4. 详细开发任务

### M0 工程骨架

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M0-T01 | 新增 `migration` Maven 模块并接入父 POM | 无 | `migration/pom.xml`、父 POM module 配置 | `mvn -pl migration -am test` 可执行 |
| M0-T02 | 实现 CLI 命令分发 | M0-T01 | `MigrationCli`、命令枚举、参数解析 | 支持 `precheck/export/import/verify/retry-failed -c <file>` |
| M0-T03 | 实现 Shell Launcher | M0-T02 | 5 个 `migration-*.sh` | Shell 能定位 jar、传递配置和 JVM 参数 |
| M0-T04 | 实现配置加载 | M0-T02 | `MigrationConfig`、`ConfigLoader` | 支持 Java `.properties`，默认值与设计文档一致 |
| M0-T05 | 接入 log4j 日志 | M0-T01 | `log4j.properties`、日志初始化 | TTL、失败重试、进度日志可按 job 输出 |

### M1 基础设施

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M1-T01 | 定义核心领域模型 | M0-T04 | `SpaceMeta`、`LabelMeta`、`IndexMeta`、`UserMeta`、`FileEntry`、`JobStatus` | 模型能覆盖 manifest/report/schema/user/role/file |
| M1-T02 | 实现 manifest 管理 | M1-T01 | `ManifestManager` | 支持创建、加载、原子更新、文件状态流转 |
| M1-T03 | 实现 checkpoint 管理 | M1-T02 | `ExportCheckpoint`、`ImportCheckpoint` | 支持 label 文件级、partition 文件级、import 行号/offset 记录 |
| M1-T04 | 实现 report writer | M1-T01 | `ExportReportWriter`、`ImportReportWriter`、`VerifyReportWriter` | 输出固定 JSON 报告文件，包含告警、统计和未全量证明标记 |
| M1-T05 | 实现 checksum/signature | M1-T02 | `Sha256Util`、`HmacSignatureUtil`、`FileCompletionMarker` | `.sha256`、`.sig` 校验通过后文件才视为完成 |
| M1-T06 | 实现失败记录格式 | M1-T04 | `FailureRecordWriter`、`FailureRecordReader` | 单行失败信息包含文件、行号、key、原始行、nGQL、错误码、错误消息、重试次数 |

### M2 连接、预检查与元数据导出

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M2-T01 | 实现 graph 连接管理 | M0-T04 | `GraphConnectionManager` | 支持源/目标 graph 地址、用户、密码、重试连接 |
| M2-T02 | 实现 storage 连接管理 | M0-T04 | `StorageConnectionManager` | 可初始化 `StorageClient` 并连接多台 storage |
| M2-T03 | 实现 meta 信息读取适配层 | M2-T01 | `MetadataReader` | 能读取 space、tag、edge、index、partition、user、role |
| M2-T04 | 实现源集群 precheck | M2-T01/M2-T03 | `SourcePrecheck` | 检查版本、space/schema/storage、后台 job、TTL、冻结确认提示 |
| M2-T05 | 实现目标集群 precheck | M2-T01/M2-T03 | `TargetPrecheck` | 目标必须无业务 space 且仅 root 用户，否则退出 |
| M2-T06 | 实现元数据导出 | M2-T03/M1-T04 | `MetadataExporter`、`meta/schema.json`、`meta/users.json`、`meta/roles.json` | root 只写报告，非 root 用户和 space 级角色可导出 |
| M2-T07 | 实现 TTL 识别和告警落盘 | M2-T03/M1-T04 | `TtlInspector` | TTL schema 触发 log4j warning，并写入 manifest/report |
| M2-T08 | 实现商业版扩展权限降级报告 | M2-T06 | 权限 warning/report 字段 | 无法强保证的扩展权限写入告警，不阻断任务 |

### M3 默认导出链路：CSV + label

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M3-T01 | 实现 Storage scan 任务计划 | M2-T03 | `ExportPlanBuilder` | 按 space/tag/edge/partition 生成 scan plan |
| M3-T02 | 实现 vertex scan worker | M2-T02/M3-T01 | `VertexScanWorker` | 支持 `scanVertex(space, part, tag, cols, limit)`，`allowPartSuccess=false` |
| M3-T03 | 实现 edge scan worker | M2-T02/M3-T01 | `EdgeScanWorker` | 支持 `scanEdge(space, part, edge, cols, limit)`，保留 `_src/_dst/_rank` |
| M3-T04 | 实现 Nebula value 到内部 row 模型转换 | M3-T02/M3-T03 | `RowMapper` | 支持 VID、NULL、空字符串、数值、浮点、布尔、日期时间、复杂转义字符 |
| M3-T05 | 实现 CSV writer/parser | M3-T04 | `CsvRowWriter`、`CsvRowReader` | 符合 RFC4180 风格，`\N` 表示 NULL，`""` 表示空字符串 |
| M3-T06 | 实现 label 布局导出调度 | M3-T02/M3-T03/M3-T05 | `LabelExportRunner` | 一个 tag/edge 一个文件，多 partition 并发，单 writer 写入 |
| M3-T07 | 接入 label 文件完成语义 | M3-T06/M1-T05 | `.tmp`、正式文件、`.sha256`、`.sig` | 无签名文件整体重导，已签名文件跳过 |
| M3-T08 | 实现导出进度统计 | M3-T06/M1-T04 | 进度日志、export-report 统计 | 按 space/tag/edge/partition 输出 row count 和耗时 |

### M4 默认导入链路

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M4-T01 | 实现导入前文件校验 | M1-T05/M1-T02 | `ImportFileValidator` | 所有数据文件必须 checksum/signature 通过 |
| M4-T02 | 实现 schema plan 生成 | M2-T06 | `SchemaPlanBuilder` | 输出 CREATE SPACE/TAG/EDGE/INDEX 执行计划 |
| M4-T03 | 实现 schema/index 创建 | M4-T02/M2-T01 | `SchemaImporter` | 按 space、tag/edge、index 顺序创建；失败立即退出 |
| M4-T04 | 实现非 root 用户导入 | M2-T06/M2-T01 | `UserImporter` | 非 root 用户以默认密码 `nebula` 创建，root 不修改 |
| M4-T05 | 实现非 root space 级角色导入 | M4-T04 | `RoleGrantImporter` | `GRANT ROLE ... ON <space>` 成功执行 |
| M4-T06 | 实现 nGQL 生成和转义 | M3-T04 | `NgqlBuilder` | INSERT VERTEX/EDGE 对所有支持类型正确转义 |
| M4-T07 | 实现批量导入执行器 | M4-T06/M2-T01 | `BatchInsertExecutor` | 默认 vertex/edge batch 500，成功后更新 checkpoint |
| M4-T08 | 实现重试和退避 | M4-T07 | `RetryManager` | 默认 3 次，退避 1000ms，错误记录重试次数 |
| M4-T09 | 实现批量失败后的单行降级 | M4-T08/M1-T06 | `SingleRowFallbackImporter` | 批失败后逐行重试，单行失败落盘 |
| M4-T10 | 实现导入恢复 | M4-T07/M1-T03 | import checkpoint | 已完成文件跳过，未完成文件从 checkpoint 继续 |

### M5 默认校验闭环

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M5-T01 | 实现导出侧数量统计读取 | M1-T02/M1-T04 | `ExportStatsReader` | 从 manifest/export-report 获取 space/tag/edge/partition 行数 |
| M5-T02 | 实现目标侧数量扫描 | M2-T02 | `TargetCountScanner` | 按 space/tag/edge/partition 扫描目标并统计 |
| M5-T03 | 实现数量一致校验 | M5-T01/M5-T02 | `CountVerifier` | 输出差异明细，报告维度满足 space/tag/edge/partition |
| M5-T04 | 实现 deterministic sampling | M3-T04 | `SampleSelector`、sample 文件或 manifest sample 字段 | 以 vertex/edge key hash 稳定抽样 |
| M5-T05 | 实现抽样数据读取和比较 | M5-T04/M2-T01 | `SampleVerifier` | 从目标读取 key，按 typed value 语义比较 |
| M5-T06 | 实现 verify-report | M5-T03/M5-T05/M1-T04 | `verify-report.json` | 默认不开 full checksum 时明确标记“未证明全量完全一致” |

### M6 增强能力

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M6-T01 | 实现 partition 布局导出 | M3-T02/M3-T03/M1-T05 | `PartitionExportRunner` | 每个 `space+label+partition` 一个文件，独立 `.sha256`/`.sig` |
| M6-T02 | 实现 partition 布局恢复 | M6-T01/M1-T03 | partition checkpoint | 已签名 partition 跳过，未签名 partition 整体重导 |
| M6-T03 | 实现 partition 布局导入 | M6-T01/M4-T07 | partition import reader | 可按 partition 文件导入并更新 checkpoint |
| M6-T04 | 实现 JSON Lines writer/parser | M3-T04 | `JsonRowWriter`、`JsonRowReader` | typed JSON 区分类型、NULL、空字符串和复杂转义 |
| M6-T05 | 接入 export.format 切换 | M3-T05/M6-T04 | format factory | `csv/json` 通过配置切换，默认 CSV |
| M6-T06 | 实现 canonical row 编码 | M3-T04 | `CanonicalRowEncoder` | 稳定包含 key、label、schema hash、属性名、类型和值 |
| M6-T07 | 实现全量 checksum 导出 | M6-T06 | full checksum manifest 字段 | 手动开启后按 space/tag/edge/partition 输出 checksum |
| M6-T08 | 实现全量 checksum 校验 | M6-T07/M5-T02 | `FullChecksumVerifier` | 目标扫描 checksum 与导出 checksum 一致时通过 |
| M6-T09 | 实现失败记录重试命令 | M1-T06/M4-T06/M4-T08 | `retry-failed` | 读取失败文件，重新执行失败行并输出 retry 报告 |

### M7 测试、性能与交付

| ID | 任务 | 依赖 | 交付物 | 验收标准 |
| --- | --- | --- | --- | --- |
| M7-T01 | 补齐单元测试 | M1-M6 | JUnit 测试 | 覆盖 CSV/JSON、canonical、checksum、manifest、nGQL、失败记录 |
| M7-T02 | 搭建集成测试环境 | M2 | docker-compose 或现有集群脚本 | 可启动源/目标 3.6 三实例测试环境 |
| M7-T03 | 构造多类型测试数据集 | M2/M3 | 数据准备脚本 | 覆盖多 space/tag/edge、index、TTL、权限、字符串 VID、整数 VID、复杂类型 |
| M7-T04 | 默认链路集成测试 | M3/M4/M5 | 集成测试报告 | CSV + label 完整导出、导入、校验通过 |
| M7-T05 | 增强链路集成测试 | M6 | 集成测试报告 | CSV/JSON、label/partition、full checksum 均通过 |
| M7-T06 | 故障注入测试 | M3/M4/M6 | 故障注入报告 | kill 导出/导入、删除 `.sig`、篡改文件、schema 失败、连接失败均符合设计 |
| M7-T07 | 5000 万级性能测试 | M6 | 性能测试报告 | 记录导出/导入吞吐、CPU、内存、磁盘、网络、恢复耗时 |
| M7-T08 | 用户文档和运维手册 | M6/M7-T06 | README、配置样例、操作手册 | 包含冻结前置条件、目标清理要求、失败恢复、报告解释 |

## 5. 优先级建议

P0 必须先做：

1. M0-T01 到 M0-T05：工程骨架、CLI、配置、日志。
2. M1-T01 到 M1-T06：manifest、report、checkpoint、checksum/signature、失败记录。
3. M2-T01 到 M2-T07：连接、precheck、元数据导出、TTL warning。
4. M3-T01 到 M3-T08：CSV + label 导出。
5. M4-T01 到 M4-T10：默认导入。
6. M5-T01 到 M5-T06：默认校验。

P1 完整商用能力：

1. M6-T01 到 M6-T03：partition 布局。
2. M6-T04 到 M6-T05：JSON 格式。
3. M6-T06 到 M6-T08：全量 checksum。
4. M6-T09：失败记录重试命令。
5. M7-T01 到 M7-T08：测试、性能和交付文档。

P2 后续扩展：

1. `segment` 布局代码实现。
2. 更细粒度导入进度和可视化进度。
3. 可配置 HMAC 密钥。
4. 自动冻结/解冻编排。
5. 商业版扩展权限强一致迁移。

## 6. 关键依赖关系

```mermaid
flowchart TD
    M0[M0 工程骨架] --> M1[M1 基础设施]
    M1 --> M2[M2 预检查与元数据]
    M2 --> M3[M3 CSV + label 导出]
    M3 --> M4[M4 默认导入]
    M4 --> M5[M5 默认校验]
    M3 --> M6[M6 partition/JSON/checksum]
    M5 --> M6
    M6 --> M7[M7 测试性能交付]
```

## 7. 风险任务

| 风险任务 | 风险点 | 建议前置验证 |
| --- | --- | --- |
| M2-T03 元数据读取适配层 | graph nGQL 与 generated MetaService 能力边界可能不一致 | 先做 spike，确认 index/user/role/partition 的稳定读取方式 |
| M3-T04 类型转换 | Nebula Value 类型复杂，VID、时间、NULL、字符串转义容易出错 | 单元测试先覆盖完整类型矩阵 |
| M4-T06 nGQL 生成 | INSERT 转义错误会导致导入失败或数据变形 | 用 golden file 校验生成语句 |
| M5-T05 抽样比较 | 查询目标 key 的方式需兼容 VID 类型和 edge rank | 先验证字符串 VID、整数 VID、rank edge |
| M6-T06 canonical 编码 | checksum 一致性依赖稳定编码 | 在导出和校验两侧复用同一编码实现 |
| M7-T07 性能测试 | 20 亿规模目标难以在开发环境完整验证 | 先用 5000 万级验证，再给出容量外推和资源建议 |

## 8. 建议验收顺序

1. 单元测试验收：文件格式、checksum、manifest、nGQL、失败记录。
2. 小规模功能验收：多 space、多 tag、多 edge、两类 VID、TTL warning、权限报告。
3. 默认链路验收：CSV + label 导出、导入、数量校验、抽样校验。
4. 恢复能力验收：导出/导入中断恢复、缺失签名重导、失败记录重试。
5. 增强链路验收：partition、JSON、full checksum。
6. 性能验收：5000 万级点边数据，记录吞吐和资源占用。

## 9. 第一批开发建议

第一批建议只覆盖 P0 的前半段，目标是尽快跑通“空命令到可导出文件”的链路：

1. 新建 `migration` 模块和 CLI/Shell。
2. 完成 properties 配置加载和默认参数。
3. 完成 manifest/report/checksum/signature 基础设施。
4. 完成 graph/storage/meta 连接管理。
5. 完成 precheck 和元数据导出。
6. 完成 CSV writer 和 label 布局导出最小实现。

该阶段结束后，应能对小规模源集群执行：

```bash
bin/migration-precheck.sh -c migration.properties
bin/migration-export.sh -c migration.properties
```

并在导出目录中得到：

```text
manifest.json
export-report.json
meta/schema.json
meta/users.json
meta/roles.json
data/<space>/vertices/<tag>.csv
data/<space>/vertices/<tag>.csv.sha256
data/<space>/vertices/<tag>.csv.sig
data/<space>/edges/<edge>.csv
data/<space>/edges/<edge>.csv.sha256
data/<space>/edges/<edge>.csv.sig
```
