# Migration Tool Implementation Validation Report

Date: 2026-07-10

## Scope

- Source and target: Nebula Graph 3.6.
- Topology: each cluster has 3 Meta, 3 Storage, and 3 Graph processes.
- Tool: Java migration tool using nebula-java StorageClient scan and graph nGQL INSERT.
- Server change: graphd mutation freeze guard with `enable_graph_mutation` and
  `/migration_freeze_status`.

## Final 50M Result

The local final benchmark passed with 49,999,998 total vertex and edge records.

| Item | Result |
| --- | --- |
| Dataset | 3 spaces, 99 partitions per space, INT64 VID, 24,999,999 vertices and 24,999,999 edges |
| Export | CSV, partition layout, 594 signed artifacts |
| Source freeze | 3 graphd endpoints reported `FROZEN` before export |
| Fixture load | 257 s |
| Precheck | 1 s |
| Export | 73 s |
| Import | 239 s |
| Verify | 920 s |
| Import concurrency | 8 artifact workers |
| Import batch size | 500 rows per multi-value INSERT |
| Checkpoint flush interval | 20 successful batches |
| Export scan limit | 10,000 |
| TTL | Not detected in this benchmark |
| Final result | PASS |

The final verify report checked all 594 artifacts. It passed count and deterministic sample
validation. Full checksum was intentionally disabled, so the report correctly states that full
consistency has not been proven.

## Additional Validation

- `mvn clean package`: unit tests passed.
- Functional E2E: CSV/label and JSON/partition paths passed on dual 3-Storage clusters.
- Freeze behavior: all source graphd instances rejected DML and DDL with `MUTATION_FROZEN`.
- Integrity recovery: incomplete artifacts and SHA-256 corruption were rejected.
- Import recovery: a forced import interruption resumed from persisted checkpoint.
- Failure recovery: `retry-failed` path passed.
- Full checksum path: covered by functional E2E.
- Strong pagination regression: 6,000 records with `export.scan.limit=2` and 8 partition workers
  passed, covering repeated edge pages.
- Medium benchmark: 600,000 records passed with export 8 s, import 6 s, and verify 12 s.

## Delivery Notes

- Production defaults remain CSV + label layout, scan limit 1,000, import batch 500, import
  artifact concurrency 8, and checkpoint flush interval 20.
- The performance benchmark uses partition layout and scan limit 10,000 as a startup-time tuning
  choice; it does not change production defaults.
- The fixed HMAC key marks artifact completion and is not a security secret.
- Direct Storage write clients are outside graphd mutation freeze and must be stopped operationally.
